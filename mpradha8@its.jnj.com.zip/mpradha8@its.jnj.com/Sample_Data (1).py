# Databricks notebook source
# MAGIC %md 
# MAGIC custom_timestamp format must be YYYY-MM-DD HH:MM:SS

# COMMAND ----------

dbutils.widgets.text('custom_timestamp', defaultValue = '')

# COMMAND ----------

spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

# COMMAND ----------

# MAGIC %run /Workspace/Shared/SQA/Packages/sqif_Framework

# COMMAND ----------

from datetime import datetime, timedelta

def convert_to_local_timezone(site, date_to_convert):
  site_upperCase = site.upper()
  if (not date_to_convert) or (date_to_convert == '0000000000'):
    return
  
  print('date_to_convert: {}'.format(date_to_convert))
  date_to_convert = datetime.strptime(date_to_convert[0:-4], '%Y%m%d%H%M%S%f')
  
  difference = 0
  if site_upperCase == 'APDC':
    difference = 3.5;
  elif site_upperCase == 'FUJI_FF':
    difference = 7
  elif site_upperCase == 'XIANNEW_FF':
    difference = 6
  elif site_upperCase == 'EBS_TELHASHOMER':
    difference = 1
  elif site_upperCase == 'CORK':
    difference = -1
  elif site_upperCase == 'CORK_API-L':
    difference = -1
  elif site_upperCase == 'SAO JOSE DOS CAMPOS':
    difference = -5
  elif site_upperCase == 'SAO JOSE - CONSUMER':
    difference = -5
  elif site_upperCase == 'SAO JOSE - MD':
    difference = -5
  elif site_upperCase == 'ATHENS':
    difference = -6
  elif site_upperCase == 'GURABO':
    difference = -6
  elif site_upperCase == 'GURABO ORTHO':
    difference = -6
  elif site_upperCase == 'RARITAN':
    difference = -6
  elif site_upperCase == 'RARITAN_API-L':
    difference = -6
  elif site_upperCase == 'RARITAN_CAR-T':
    difference = -6
  elif site_upperCase == 'TITUSVILLE':
    difference = -6
  elif site_upperCase == 'PUEBLA':
    difference = -7
  elif site_upperCase == 'MALVERN_API-L':
    difference = -9
  elif site_upperCase == 'VACAVILLE':
    difference = -9
  elif site_upperCase == 'MANATI':
    difference = -6
  elif site_upperCase == 'MANATI_API-L':
    difference = -6
  elif site_upperCase == 'HYANGNAM_FF':
    difference = 7
  elif site_upperCase == 'INCHEON_VACCINES':
    difference = 7
  converted_date = date_to_convert + timedelta(hours=difference)
  return converted_date.strftime('%m/%d/%Y %H:%M:%S')

spark.udf.register('convert_to_local_timezone', convert_to_local_timezone)

# COMMAND ----------

current_year = datetime.now().strftime('%Y')
custom_time = dbutils.widgets.get("custom_timestamp")  
elims_sample_data_config = ""
custom_date_set = False
if custom_time:
  try:
    custom_time = datetime.strptime(custom_time, '%Y-%m-%d %H:%M:%S')
    elims_sample_data_config = custom_time
    custom_date_set = True
  except Exception as e:
    elims_sample_data_config = (spark.sql("select * from SQA.ELIMS_SAMPLE_DATA where NAME = 'SAMPLE_DATA'").first()).LAST_TIMESTAMP
else:
  elims_sample_data_config = (spark.sql("select * from SQA.ELIMS_SAMPLE_DATA where NAME = 'SAMPLE_DATA'").first()).LAST_TIMESTAMP
  

# COMMAND ----------

query = """
select 
  case 
    when s.allocatedfordepartmentid = 'Schaffhausen Pharma' then 'Schaffhausen'
    when s.allocatedfordepartmentid = 'Cork_API-L' then 'Corkbio'
    when s.allocatedfordepartmentid = 'Leiden_API-L' then 'Leiden'
    when s.allocatedfordepartmentid = 'Malvern_API-L' then 'Malvern'
    when s.allocatedfordepartmentid = 'Gurabo Ortho' then 'Gurabo'
    when s.allocatedfordepartmentid = 'Sao Jose dos Campos' then 'Brazil'
    when s.allocatedfordepartmentid = 'XianNew_FF' then 'Xian'
    when s.allocatedfordepartmentid =  'Incheon_Vaccines' then 'Incheon'
  else s.allocatedfordepartmentid end as TENANT_ID,
  s.s_sampleid as SAMPLE_ID,
  l.batchno as MFG_LOT_NUMBER,
  s.productid as PRODUCT_ID,
  case 
    when p.u_materialtypeid = 'IG'  then 'Raw Material'
    when p.u_materialtypeid = 'IM'  then 'Packaging Material'
  else 'Release' end as SAMPLE_TYPE,
  '' as LIMS_ANALYSIS,
  concat({current_year}, s.s_sampleid) as LIMS_UNIQUE_ID,
  
  case
    when s.receiveddt = '0000000000'  then convert_to_local_timezone(s.allocatedfordepartmentid, s.createdt)
    when s.receiveddt is null then convert_to_local_timezone(s.allocatedfordepartmentid, s.createdt)
    when trim(s.receiveddt) = '' then convert_to_local_timezone(s.allocatedfordepartmentid, s.createdt)
    else convert_to_local_timezone(s.allocatedfordepartmentid, s.receiveddt) 
  end as ARRIVAL_DATE,
  '' as DUE_DATE,  
  '' AS PRIORITY,
  case 
    WHEN u_lab in ('B_IQA','B_QA','B_QA2') THEN 'QA Sample'
    WHEN u_lab IN ('B_EXC_ADD','B_PM_ADD') THEN 'Additional Sample'
    WHEN u_lab = 'B_SAMPLE MNGT' THEN 'Sampling Management'
    WHEN u_lab = 'B_PHAST' THEN 'PHAST Lab'
    WHEN s.sampletypeid = 'LabResult' THEN 'Take over results'
    WHEN s.sampletypeid = 'StabilityRequest' then 'Stability Request Sample'
    WHEN s.allocatedfordepartmentid in ('Leiden_API-L','Malvern_API-L') and s.sampletypeid = 'AutoComplete' then 'AutoComplete Sample'
    WHEN s.allocatedfordepartmentid in ('Cork','Geel','Schaffhausen Pharma','Latina','Leiden_API-L','Malvern_API-L') and s.sampletypeid = 'Additional' then 'Additional Sample'
    WHEN s.allocatedfordepartmentid = 'Geel' and s.sampletypeid not like '%Retain%' then s.u_qctype
  ELSE 'Retain Sample' end AS COMMENTS,
  '' as SAMPLER_INITIAL,
  if(s.samplestatus = 'Cancelled','CANCEL','NEW') as ACTIONS,
  '' as SAMPLE_INFORMATION, 
  s.allocatedfordepartmentid as CUSTOMER_ID,
  '' as START_END_TIME,
  '' as OPTIONAL_1,
  '' as OPTIONAL_2,
  '' as OPTIONAL_3,
  '' as OPTIONAL_4,
  '' as OPTIONAL_5,
  '' as OPTIONAL_6,
  '' as OPTIONAL_7,
  '' as OPTIONAL_8,
  p.productdesc AS OPTIONAL_9
  from cdl_prod_l0_elims.vnd_s_sample s
  inner join cdl_prod_l0_elims.vnd_u_lot l on s.u_lotid = l.u_lotid
  inner join cdl_prod_l0_elims.vnd_s_product p on s.productid = p.s_productid
  inner join cdl_prod_l0_elims.vnd_u_qcorder q on q.lotid = l.u_lotid and q.u_qcorderid = s.u_qc_orderid
  WHERE s.samplestatus not in ('Cancelled','Completed')
      and s.sampletypeid <> 'NoSample'
    AND ((s.sampletypeid in ('Additional','AutoComplete','Composite Additional','Composite Retain','CompositeMin5-Addit',
  'CompositeMin5-Retain','Reference','Retain','Retain Pack Flag','Retain-sealed','StabilityRequest','Subbatch Retain')
   AND s.allocatedfordepartmentid in ('Cork','Geel','Schaffhausen Pharma','Latina','Cork_API-L','Leiden_API-L','Malvern_API-L','Gurabo','Gurabo Ortho','Sao Jose dos Campos','XianNew_FF','Athens','Fuji_FF', 'Incheon_Vaccines','Puebla'))
OR (s.allocatedfordepartmentid = 'Beerse'
AND (s.u_lab IN ('B_IQA','B_QA','B_QA2','B_EXC_RET','B_HG-FG_RET','B_PM_RET','B_EXC_ADD','B_PM_ADD','B_HG-FG_RET_SEAL',
'B_HG-FG_STAB','B_SAMPLE MNGT','B_PHAST') or s.sampletypeid = 'LabResult'))
OR (s.allocatedfordepartmentid = 'Geel' and s.u_lab not like 'G_%' and s.u_lotid is not null))
""".format(current_year=current_year, last_time=elims_sample_data_config)

print(query)

# COMMAND ----------

df=spark.sql(query)
df.createOrReplaceTempView("query")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from query 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from query where SAMPLE_ID in ('240483095')

# COMMAND ----------

# #mount_point = dbutils.secrets.get('sqa', 'sqa_mount_point')
# sqif = Framework()
# #sqif.mount()

# COMMAND ----------

# if not custom_date_set:
#   sqif.update_processing_state('SAMPLE_DATA', 'SQA.ELIMS_SAMPLE_DATA')

# COMMAND ----------

# from pyspark.sql.functions import lit, to_timestamp, regexp_replace, col

# df = sqif.to_df(query)
# df = df.withColumn('OPTIONAL_9', regexp_replace('OPTIONAL_9', ',|"', ' '))

# COMMAND ----------

# df_results_count = df.count()
# print('Result Count: ', df_results_count)

# COMMAND ----------

# if df_results_count==0:
#   print('Zero results, updating config')
#   sqif.update_config(None,'SAMPLE_DATA', 'SQA.ELIMS_SAMPLE_DATA')
#   dbutils.notebook.exit('Zero results, exiting')

# COMMAND ----------

# print('converting to csv')
# filename = sqif.to_csv(df, 'elims_sample_data')
# print(filename)

# COMMAND ----------

# try:
#   print('sftping')
#   print(filename)
#   sftp_result = sqif.sftp(filename, 'upload')
# except:
#   dbutils.notebook.exit('Unable to SFTP, exiting')


# COMMAND ----------

# print('Moving the CSV to archive')
# sqif.move_csv_to_archive(filename, 'elims_sample_data')

# COMMAND ----------

# if not custom_date_set:
#   print('updating config')
#   sqif.update_config(filename, 'SAMPLE_DATA', 'SQA.ELIMS_SAMPLE_DATA')

# COMMAND ----------

# dbutils.notebook.exit(filename)

# COMMAND ----------

# query = """
# select 
#   case 
#     when s.allocatedfordepartmentid = 'Schaffhausen Pharma' then 'Schaffhausen'
#     when s.allocatedfordepartmentid = 'Cork_API-L' then 'Corkbio'
#     when s.allocatedfordepartmentid = 'Leiden_API-L' then 'Leiden'
#     when s.allocatedfordepartmentid = 'Malvern_API-L' then 'Malvern'
#     when s.allocatedfordepartmentid = 'Gurabo Ortho' then 'Gurabo'
#     when s.allocatedfordepartmentid = 'Sao Jose dos Campos' then 'Brazil'
#     when s.allocatedfordepartmentid = 'XianNew_FF' then 'Xian'
#     when s.allocatedfordepartmentid =  'Incheon_Vaccines' then 'Incheon'
#   else s.allocatedfordepartmentid end as TENANT_ID,
#   s.s_sampleid as SAMPLE_ID,
#   l.batchno as MFG_LOT_NUMBER,
#   s.productid as PRODUCT_ID,
#   case 
#     when p.u_materialtypeid = 'IG'  then 'Raw Material'
#     when p.u_materialtypeid = 'IM'  then 'Packaging Material'
#   else 'Release' end as SAMPLE_TYPE,
#   '' as LIMS_ANALYSIS,
#   concat({current_year}, s.s_sampleid) as LIMS_UNIQUE_ID,
  
#   case
#     when s.receiveddt = '0000000000'  then convert_to_local_timezone(s.allocatedfordepartmentid, s.createdt)
#     when s.receiveddt is null then convert_to_local_timezone(s.allocatedfordepartmentid, s.createdt)
#     when trim(s.receiveddt) = '' then convert_to_local_timezone(s.allocatedfordepartmentid, s.createdt)
#     else convert_to_local_timezone(s.allocatedfordepartmentid, s.receiveddt) 
#   end as ARRIVAL_DATE,
#   '' as DUE_DATE,  
#   '' AS PRIORITY,
#   case 
#     WHEN u_lab in ('B_IQA','B_QA','B_QA2') THEN 'QA Sample'
#     WHEN u_lab IN ('B_EXC_ADD','B_PM_ADD') THEN 'Additional Sample'
#     WHEN u_lab = 'B_SAMPLE MNGT' THEN 'Sampling Management'
#     WHEN u_lab = 'B_PHAST' THEN 'PHAST Lab'
#     WHEN s.sampletypeid = 'LabResult' THEN 'Take over results'
#     WHEN s.sampletypeid = 'StabilityRequest' then 'Stability Request Sample'
#     WHEN s.allocatedfordepartmentid in ('Leiden_API-L','Malvern_API-L') and s.sampletypeid = 'AutoComplete' then 'AutoComplete Sample'
#     WHEN s.allocatedfordepartmentid in ('Cork','Geel','Schaffhausen Pharma','Latina','Leiden_API-L','Malvern_API-L') and s.sampletypeid = 'Additional' then 'Additional Sample'
#     WHEN s.allocatedfordepartmentid = 'Geel' and s.sampletypeid not like '%Retain%' then s.u_qctype
#   ELSE 'Retain Sample' end AS COMMENTS,
#   '' as SAMPLER_INITIAL,
#   if(s.samplestatus = 'Cancelled','CANCEL','NEW') as ACTIONS,
#   '' as SAMPLE_INFORMATION, 
#   s.allocatedfordepartmentid as CUSTOMER_ID,
#   '' as START_END_TIME,
#   '' as OPTIONAL_1,
#   '' as OPTIONAL_2,
#   '' as OPTIONAL_3,
#   '' as OPTIONAL_4,
#   '' as OPTIONAL_5,
#   '' as OPTIONAL_6,
#   '' as OPTIONAL_7,
#   '' as OPTIONAL_8,
#   p.productdesc AS OPTIONAL_9
#   from cdl_prod_l0_elims.vnd_s_sample s
#   inner join cdl_prod_l0_elims.vnd_u_lot l on s.u_lotid = l.u_lotid
#   inner join cdl_prod_l0_elims.vnd_s_product p on s.productid = p.s_productid
#   inner join cdl_prod_l0_elims.vnd_u_qcorder q on q.lotid = l.u_lotid and q.u_qcorderid = s.u_qc_orderid
#   WHERE s.samplestatus not in ('Cancelled','Completed')
#       and s.sampletypeid <> 'NoSample'
#     AND ((s.sampletypeid in ('Additional','AutoComplete','Composite Additional','Composite Retain','CompositeMin5-Addit',
#   'CompositeMin5-Retain','Reference','Retain','Retain Pack Flag','Retain-sealed','StabilityRequest','Subbatch Retain')
#    AND s.allocatedfordepartmentid in ('Cork','Geel','Schaffhausen Pharma','Latina','Cork_API-L','Leiden_API-L','Malvern_API-L','Gurabo','Gurabo Ortho','Sao Jose dos Campos','XianNew_FF','Athens','Fuji_FF', 'Incheon_Vaccines','Puebla'))
# OR (s.allocatedfordepartmentid = 'Beerse'
# AND (s.u_lab IN ('B_IQA','B_QA','B_QA2','B_EXC_RET','B_HG-FG_RET','B_PM_RET','B_EXC_ADD','B_PM_ADD','B_HG-FG_RET_SEAL',
# 'B_HG-FG_STAB','B_SAMPLE MNGT','B_PHAST') or s.sampletypeid = 'LabResult'))
# OR (s.allocatedfordepartmentid = 'Geel' and s.u_lab not like 'G_%' and s.u_lotid is not null))
# AND (
#   to_timestamp(s.createdt, 'dd-MMM-yy') >= (to_timestamp('03/15/2024 00:00:00') - interval '40' minute)
#   or to_timestamp(s.createdt, 'yyyyMMddHHmmssSS') < (to_timestamp('03/19/2024 00:00:00') - interval '40' minute)
#   )
# """.format(current_year=current_year, last_time=elims_sample_data_config)

# print(query)