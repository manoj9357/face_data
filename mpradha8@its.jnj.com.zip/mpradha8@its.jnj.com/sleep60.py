# Databricks notebook source
import time
time.sleep(180)
print("complete")

# COMMAND ----------

# import requests
# import time

# # Databricks API endpoint and token
# DATABRICKS_URL = "https://adb-6803967472078692.12.azuredatabricks.net"
# DATABRICKS_TOKEN = "dapi19295810a681ca524ecf2d6202513f10-2"
# JOB_ID = "736606497765434"

# # Headers for the API requests
# headers = {
#     "Authorization": f"Bearer {DATABRICKS_TOKEN}",
#     "Content-Type": "application/json"
# }

# # Function to submit a job run
# def submit_job_run():
#     url = f"{DATABRICKS_URL}/api/2.0/jobs/runs/submit"
#     payload = {
#         "job_id": JOB_ID
#     }
#     response = requests.post(url, json=payload, headers=headers)
#     if response.status_code == 200:
#         run_id = response.json().get("run_id")
#         print(f"Job run started successfully. Run ID: {run_id}")
#         return run_id
#     else:
#         print(f"Failed to submit job run: {response.text}")
#         return None

# # Function to get the status of a job run
# def get_job_run_status(run_id):
#     url = f"{DATABRICKS_URL}/api/2.0/jobs/runs/get?run_id={run_id}"
#     response = requests.get(url, headers=headers)
#     if response.status_code == 200:
#         status = response.json().get("state", {}).get("life_cycle_state")
#         result_state = response.json().get("state", {}).get("result_state")
#         print(f"Run ID: {run_id} - Status: {status}, Result State: {result_state}")
#         return status, result_state
#     else:
#         print(f"Failed to get job run status: {response.text}")
#         return None, None

# # Main loop to keep submitting and checking the job status
# def run_job_with_retries():
#     retry_count = 0
#     max_retries = 10  # Maximum retries if the job fails
#     run_id = None

#     while retry_count < max_retries:
#         # If no run is started or completed, submit a new job
#         if run_id is None:
#             run_id = submit_job_run()

#         if run_id:
#             # Check the status of the job run
#             status, result_state = get_job_run_status(run_id)
            
#             if status == "TERMINATED":
#                 # If job is terminated, check the result state
#                 if result_state == "SUCCESS":
#                     print("Job completed successfully!")
#                     break  # Exit loop if job is successful
#                 elif result_state == "FAILED":
#                     print("Job failed. Retrying...")
#                     retry_count += 1
#                     run_id = None  # Reset the run ID to trigger a new job
#                     time.sleep(60)  # Wait before retrying (adjust the time as needed)
#             else:
#                 print("Job still running, waiting...")
#                 time.sleep(60)  # Wait before checking the status again

#     if retry_count == max_retries:
#         print("Max retries reached. Job failed to complete successfully.")

# # Run the job with retries
# run_job_with_retries()
