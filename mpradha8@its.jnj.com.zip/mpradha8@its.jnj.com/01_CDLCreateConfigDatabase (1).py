# Databricks notebook source
# MAGIC %md
# MAGIC #CDLCreateConfigDatabase#
# MAGIC **Description:** Creates the CDL configuration database CDL_CONFIG and tables to configure CDL storage accounts, schemas and views  
# MAGIC **Author:** Niall Moore  
# MAGIC **Date:** 05 Jan 2021

# COMMAND ----------

# MAGIC %md
# MAGIC ##CREATE DATABASE: CDL_CONFIG ##

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS CDL_CONFIG
# MAGIC COMMENT 'Application CDL Configuration Database'
# MAGIC LOCATION '/cdl_config';

# COMMAND ----------

# MAGIC %md
# MAGIC ##CREATE TABLE: CDL_STORAGE_ACCOUNTS##

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS CDL_CONFIG.CDL_STORAGE_ACCOUNTS (CONNECTION_TYPE STRING, STORAGE_ACCOUNT_NAME STRING, STORAGE_CONTAINER STRING, RAW_DATA_PATH STRING, LOCAL_MOUNT_POINT STRING, SECRET_SCOPE STRING , SECRET_CLIENT_KEY STRING, SECRET_ACCESS_TOKEN_KEY STRING, SECRET_EXPIRY_KEY STRING, CURRENT_MOUNT_EXPIRY STRING)
# MAGIC USING DELTA
# MAGIC LOCATION '/cdl_config/cdl_storage_accounts';
# MAGIC
# MAGIC ALTER TABLE CDL_CONFIG.CDL_STORAGE_ACCOUNTS  SET TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true);
# MAGIC ALTER TABLE CDL_CONFIG.CDL_STORAGE_ACCOUNTS  SET TBLPROPERTIES (delta.autoOptimize.autoCompact = true);

# COMMAND ----------

# MAGIC %md
# MAGIC ##CREATE TABLE: CDL_SCHEMAS##

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS CDL_CONFIG.CDL_SCHEMAS (CDL_SCHEMA_NAME STRING, STORAGE_ACCOUNT_NAME STRING, LOCAL_SCHEMA_NAME STRING, CREATE_ALL_TABLES BOOLEAN)
# MAGIC USING DELTA
# MAGIC LOCATION '/cdl_config/cdl_schemas';
# MAGIC
# MAGIC ALTER TABLE CDL_CONFIG.CDL_SCHEMAS  SET TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true);
# MAGIC ALTER TABLE CDL_CONFIG.CDL_SCHEMAS  SET TBLPROPERTIES (delta.autoOptimize.autoCompact = true);

# COMMAND ----------

# MAGIC %md
# MAGIC ##CREATE TABLE: CDL_TABLES##

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS CDL_CONFIG.CDL_TABLES (LOCAL_SCHEMA_NAME STRING, TABLE_NAME STRING)
# MAGIC USING DELTA
# MAGIC LOCATION '/cdl_config/cdl_tables';
# MAGIC
# MAGIC ALTER TABLE CDL_CONFIG.CDL_TABLES  SET TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true);
# MAGIC ALTER TABLE CDL_CONFIG.CDL_TABLES  SET TBLPROPERTIES (delta.autoOptimize.autoCompact = true);

# COMMAND ----------

# MAGIC %md
# MAGIC ##CREATE TABLE: CDL_VIEWS##

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS CDL_CONFIG.CDL_VIEWS (LOCAL_SCHEMA_NAME STRING, TABLE_NAME STRING, VIEW_NAME STRING, FILTER STRING)
# MAGIC USING DELTA
# MAGIC LOCATION '/cdl_config/cdl_views';
# MAGIC
# MAGIC ALTER TABLE CDL_CONFIG.CDL_VIEWS  SET TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true);
# MAGIC ALTER TABLE CDL_CONFIG.CDL_VIEWS  SET TBLPROPERTIES (delta.autoOptimize.autoCompact = true);

# COMMAND ----------

# MAGIC %md
# MAGIC ##Exit Notebook##

# COMMAND ----------

dbutils.notebook.exit('01_CDLCreateConfigDatabase')

# COMMAND ----------

# MAGIC %md
# MAGIC #Appendix#

# COMMAND ----------

# MAGIC %md
# MAGIC ##Drop tables##

# COMMAND ----------

sql =  'DROP TABLE CDL_CONFIG.CDL_STORAGE_ACCOUNTS';
spark.sql(sql);

dbutils.fs.ls('/cdl_config/cdl_storage_accounts');
dbutils.fs.rm('/cdl_config/cdl_storage_accounts', True);
dbutils.fs.ls('/cdl_config/cdl_storage_accounts');

# COMMAND ----------

sql =  'DROP TABLE CDL_CONFIG.CDL_SCHEMAS';
spark.sql(sql);

dbutils.fs.ls('/cdl_config/cdl_schemas');
dbutils.fs.rm('/cdl_config/cdl_schemas', True);
dbutils.fs.ls('/cdl_config/cdl_schemas');

# COMMAND ----------

sql =  'DROP TABLE CDL_CONFIG.CDL_TABLES';
spark.sql(sql);

dbutils.fs.ls('/cdl_config/cdl_config/cdl_tables');
dbutils.fs.rm('/cdl_config/cdl_config/cdl_tables', True);
dbutils.fs.ls('/cdl_config/cdl_config/cdl_tables');

# COMMAND ----------

sql =  'DROP TABLE CDL_CONFIG.CDL_VIEWS';
spark.sql(sql);

dbutils.fs.ls('/cdl_config/cdl_config/cdl_views');
dbutils.fs.rm('/cdl_config/cdl_config/cdl_views', True);
dbutils.fs.ls('/cdl_config/cdl_config/cdl_views');