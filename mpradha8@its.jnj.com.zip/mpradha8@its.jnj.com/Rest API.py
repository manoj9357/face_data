# Databricks notebook source
import requests
response = requests.get('https://adb-4933264770484963.3.azuredatabricks.net/?o=4933264770484963#notebook/1918788092459147/command/1918788092459149/api/2.1/job/get',1465825534)
response_j=response.json()
print(response_j)
# If response == “404” || “503” then
# {
# //run the pause and restart api
# }

# COMMAND ----------

import requests
import json
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, ArrayType, StringType, StructType
 
databricksURl = "https://adb-4933264770484963.3.azuredatabricks.net"
myToken = "dapi831b55c6d4663aa199d0204ce8636c44-2"
header = {'Authorization': 'Bearer {}'.format(myToken)}
endpoint = '/api/2.1/jobs/list'
payload = """{"limit": "1"}"""
 
resp = requests.get(
  databricksURl + endpoint,
  data=payload,
  headers=header
)
 
di = json.loads(resp.text)
di['jobs']

# COMMAND ----------



# COMMAND ----------

import requests
import json
from pyspark.sql import functions as F
from pyspark.sql.types import StructField, ArrayType, StringType, StructType
 
databricksURl = "https://adb-4933264770484963.3.azuredatabricks.net"
myToken = "dapi831b55c6d4663aa199d0204ce8636c44-2"
header = {'Authorization': 'Bearer {}'.format(myToken)}
endpoint = '/api/2.1/jobs/runs/get-output'
# payload = """{"run_id": "201242160"}"""
 

payload = {
    "run_id": "201242160"
}
payload_json = json.dumps(payload)

resp = requests.get(
  databricksURl + endpoint,
  params=payload_json,
  headers=header
)
 
# di = json.loads(resp.text)
# di['jobs']
print(resp)

# COMMAND ----------


import requests
import json

databricksURL = "https://adb-4933264770484963.3.azuredatabricks.net"
myToken = "dapi831b55c6d4663aa199d0204ce8636c44-2"


run_id = "201242160"


output_url = f"{databricksURL}/api/2.0/jobs/runs/get-output?run_id={run_id}"
headers = {"Authorization": f"Bearer {myToken}"}

try:
    resp = requests.get(output_url, headers=headers)
    output_data = resp.json()
    print(json.dumps(output_data, indent=2))


    import json
    from pyspark.sql import SparkSession


    formatted_json_string = json.dumps(output_data, indent=2)

    spark = SparkSession.builder.appName("JSON to DataFrame").getOrCreate()

    json_rdd = spark.sparkContext.parallelize([formatted_json_string])

    df = spark.read.json(json_rdd)

    df.show(truncate=False)
except requests.RequestException as e:
    print(f"Error fetching output: {e}")


# COMMAND ----------

result_state = df.select("metadata.state.result_state").first()[0]

print(f"Result state: {result_state}")

# COMMAND ----------

import requests

databricks_url = "https://adb-4933264770484963.3.azuredatabricks.net"
access_token = "dapi831b55c6d4663aa199d0204ce8636c44-2"
job_id = 6 


runs_url = f"{databricks_url}/api/2.0/jobs/runs/list"
headers = {"Authorization": f"Bearer {access_token}"}
params = {"job_id": job_id}

try:
    response = requests.get(runs_url, headers=headers, params=params)
    runs_data = response.json()

    
    latest_run_id_SQA_Atlas = runs_data["runs"][0]["run_id"]
    print(f"Latest run ID for job {job_id}: {latest_run_id_SQA_Atlas}")
except requests.RequestException as e:
    print(f"Error fetching job runs: {e}")


# COMMAND ----------

print(f"{latest_run_id_SQA_Atlas}")

# COMMAND ----------

import requests

databricks_url = "https://adb-4933264770484963.3.azuredatabricks.net"
access_token = "dapi831b55c6d4663aa199d0204ce8636c44-2"

job_ids = ["6", "10783018510026", "1023758072888821","632076920252296","3","2","7","397467377246001","782032968283137","811880","75579419111109"]

job_run_ids = {}

for job_id in job_ids:
    runs_url = f"{databricks_url}/api/2.0/jobs/runs/list"
    headers = {"Authorization": f"Bearer {access_token}"}
    params = {"job_id": job_id}

    try:
        response = requests.get(runs_url, headers=headers, params=params)
        runs_data = response.json()

       
        latest_run_id = runs_data["runs"][0]["run_id"]
        job_run_ids[job_id] = latest_run_id
    except requests.RequestException as e:
        print(f"Error fetching job runs for {job_id}: {e}")

print("Job run IDs:")
print(job_run_ids)


# COMMAND ----------

# import requests

# # Replace with your actual Databricks instance URL and access token
# databricks_url = "https://<your-databricks-instance>.azuredatabricks.net"
# access_token = "<your-access-token>"

# # Assume you have a dictionary 'job_run_ids' with job IDs as keys and latest run IDs as values
# job_run_ids = {
#     "Job1": "201242160",
#     "Job2": "201242161",
#     "Job3": "201242162",
#     # Add more jobs and their run IDs here
# }

failed_jobs = 0

for job_id, run_id in job_run_ids.items():
    # Make the API call to get the status of the latest run (run_id)
    runs_url = f"{databricks_url}/api/2.0/jobs/runs/get?run_id={run_id}"
    headers = {"Authorization": f"Bearer {access_token}"}

    try:
        response = requests.get(runs_url, headers=headers)
        run_data = response.json()
        status = run_data.get("state", {}).get("result_state", "")

        print(f"Job {job_id} - Latest Run ID: {run_id}, Status: {status}")

        # Check if the status is "FAILED"
        if status != "SUCCESS":
            failed_jobs += 1
    except requests.RequestException as e:
        print(f"Error fetching job run for {job_id}: {e}")

# If 3 or more jobs failed, restart the cluster
if failed_jobs >= 3:
    # Use Databricks REST API to restart the cluster
    # (You'll need the cluster ID for this)
    print("Restarting the cluster...")

else:
  print("not Restarting the cluster...")
    # Add your code to restart the cluster here


# COMMAND ----------

import requests


databricks_url = "https://adb-4933264770484963.3.azuredatabricks.net"
access_token = "dapi831b55c6d4663aa199d0204ce8636c44-2"
cluster_id = "1212-034401-claws171"


restart_url = f"{databricks_url}/api/2.0/clusters/restart"
headers = {"Authorization": f"Bearer {access_token}"}
data = {"cluster_id": cluster_id}

try:
    response = requests.post(restart_url, json=data, headers=headers)
    if response.status_code == 200:
        print(f"Cluster {cluster_id} restarted successfully.")
    else:
        print(f"Error restarting cluster {cluster_id}.")
except requests.RequestException as e:
    print(f"Error: {e}")


# COMMAND ----------

import requests

# # Replace with your actual Databricks instance URL and access token
databricks_url = "https://adb-4933264770484963.3.azuredatabricks.net"
access_token = "dapi831b55c6d4663aa199d0204ce8636c44-2"

# Assume you have a dictionary 'job_run_ids' with job IDs as keys
job_ids = ["6", "10783018510026", "1023758072888821","632076920252296","3","2","7","397467377246001","782032968283137","811880","75579419111109"]

for job_id in job_ids:
    # Make the API call to pause the job
    pause_url = f"{databricks_url}/api/2.0/jobs/update"
    headers = {"Authorization": f"Bearer {access_token}"}
    # data = {"job_id": job_id, "new_settings": {"schedule": {"pause_status": "PAUSED"},"trigger": {"pause_status": "PAUSED"},"continuous": {"pause_status": "PAUSED"}}}
    # data = {"job_id": job_id, "new_settings": {"schedule": {"pause_status": "PAUSED"}}}

    try:
        response = requests.post(pause_url, json=data, headers=headers)
        if response.status_code == 200:
            print(f"Job {job_id} paused successfully.")
        else:
            print(f"Error pausing job {job_id}.")
    except requests.RequestException as e:
        print(f"Error: {e}")


# COMMAND ----------

import requests

# # Replace with your actual Databricks instance URL and access token
databricks_url = "https://adb-4933264770484963.3.azuredatabricks.net"
access_token = "dapi831b55c6d4663aa199d0204ce8636c44-2"
                 b        
job_ids = ["6", "10783018510026", "1023758072888821","632076920252296","3","2","7","397467377246001","782032968283137","811880","75579419111109"]

for job_id in job_ids:
    # Make the API call to resume the job
    resume_url = f"{databricks_url}/api/2.0/jobs/reset"
    headers = {"Authorization": f"Bearer {access_token}"}
    data = {"job_id": job_id, "new_settings": {"schedule": {"quartz_cron_expression": "UNPAUSE"}}}

    try:
        response = requests.post(resume_url, json=data, headers=headers)
        if response.status_code == 200:
            print(f"Job {job_id} resumed successfully.")
        else:
            print(f"Error resuming job {job_id}.")
    except requests.RequestException as e:
        print(f"Error: {e}")

# COMMAND ----------

30 15 * * *

# COMMAND ----------

