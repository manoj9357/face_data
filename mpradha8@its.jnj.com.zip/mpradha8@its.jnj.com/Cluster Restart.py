# Databricks notebook source
# MAGIC %sh
# MAGIC curl \
# MAGIC   -X POST \
# MAGIC   -H 'Authorization: Bearer dapi0e3fb8104ddbfcd665c856e0e1781e23-2' \
# MAGIC   -d '{"cluster_id": "0626-122256-glcv580i"}' \
# MAGIC   https://adb-6803967472078692.12.azuredatabricks.net/api/2.0/clusters/restart

# COMMAND ----------

