# Databricks notebook source
# MAGIC %sql
# MAGIC select * from sqa.atlas_batch_genealogy

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.

# COMMAND ----------

# MAGIC %md
# MAGIC