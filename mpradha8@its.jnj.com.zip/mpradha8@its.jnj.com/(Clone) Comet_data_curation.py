# Databricks notebook source
# MAGIC %run /Workspace/Shared/SQA/Packages/sqif_Framework

# COMMAND ----------

from functools import reduce
from pyspark.sql import DataFrame
 
sqif = Framework()

# COMMAND ----------

418725-PJB1000
concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c) AS BATCH_NO,
CASE 
  WHEN capa_details.Name is not null then concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC) / ', capa_details.compliancequest__Record_Stage__c,'-',capa_details.compliancequest__Status__c, ' (CAPA)')
  ELSE concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC)') 
  END AS STATE

  from SQA.vw_comet_nc_details nc_details
  inner join SQA.vw_NC_ImpactedPartLotRecords nc_lot on nc_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
  inner join SQA.vw_NC_ImpactedPartLotRecords nc_lot on nc_lot.compliancequest__SQX_Nonconformance__c = nc_details.id

  left join SQA.vw_comet_capa_details capa_details on capa_details.compliancequest__SQX_Source_NC__c = nc_details.id

# COMMAND ----------

# MAGIC %sql
# MAGIC select*
# MAGIC from
# MAGIC  
# MAGIC sqa.comet_capa_details
# MAGIC -- #  where
# MAGIC -- # name = "CAPA-000184"
# MAGIC  
# MAGIC order by INSERTED_AT desc

# COMMAND ----------

open_query = """
select 
-- Start CSV fields --
-- Start additional sites Feb 2024
CASE 
WHEN hist_add_sites.PR_ID is null and nc_details.compliancequest__Status__c = 'Open' and nc_details.compliancequest__Record_Stage__c = 'Disposition_Investigate' 
     and history.J_J_SITE_NAME <> nc_additionalsites.CQ_JNJ_J_J_Site_Name__r_Name and nc_lot.compliancequest__Lot_Number__c <> 'NA'
     and nc_additionalsites.CQ_JNJ_J_J_Site_Name__r_Name <> 'N/A'
THEN nc_additionalsites.CQ_JNJ_J_J_Site_Name__r_Name
ELSE nc_details.compliancequest__Org_Site__c
END AS J_J_SITE_NAME
-- End additional sites Feb 2024
-- lot info
, concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c) AS BATCH_NO
, nc_lot.compliancequest__Lot_Number__c as BATCH_ID_LOT_NUMBER 
, nc_lot.CQ_JNJ_Material_Item__c as MATERIAL_ITEM
, CASE 
  WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
  ELSE nc_details.Name 
  END AS PR_ID
, CASE 
  WHEN capa_details.Name is not null then concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC) / ', capa_details.compliancequest__Record_Stage__c,'-',capa_details.compliancequest__Status__c, ' (CAPA)')
  ELSE concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC)') 
  END AS STATE
, nc_risk.compliancequest__Conclusion__c as PROJECT
, date_format(nc_details.CreatedDate, 'yyyy-MM-dd HH:mm:ss') as DATE_CREATED
, nc_details.CreatedBy_Name as ORIGINATOR
, CASE 
  WHEN capa_details.Owner_Name is not null then concat(nc_details.owner_name,' (NC) - ',capa_details.Owner_Name, ' (CAPA)')
  ELSE concat(nc_details.owner_name,' (NC)') 
  END AS ASSIGNED_TO
, CASE 
  WHEN capa_details.compliancequest__Due_Date_Investigation__c is not null then date_format(capa_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss')
  ELSE date_format(nc_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss') 
  END AS DUE_DATE
-- ACTION
, 'OPEN' as ACTION
, '' as COMMENT_TEXT
, nc_details.CQ_JNJ_Functional_Area_1__c as J_J_FUNCTIONAL_AREA_1
, nc_details.CQ_JNJ_Functional_Area_2__c as J_J_FUNCTIONAL_AREA_2
, nc_details.compliancequest__Org_Division__c as J_J_SEGMENT
, nc_details.compliancequest__Org_Business_Unit__c as J_J_BUSINESS_UNIT
, nc_additional.CQ_JNJ_SQX_Mfg_Category__c as MFG_CATEGORY
, nc_additional.CQ_JNJ_SQX_Mfg_Technology__c as MFG_TECHNOLOGY    
, '' as MFG_EQUIPMENT_LIST
, nc_risk.compliancequest__Conclusion__c as INVESTIGATION_LEVEL
, CASE 
  WHEN capa_response_app.compliancequest__SQX_User__r_name is not null then concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC) - ',capa_response_app.compliancequest__SQX_User__r_name, ' (CAPA)')
  ELSE concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC)') 
  END AS INVESTIGATION_APPROVED_BY
, CASE 
  WHEN capa_finding_response.compliancequest__Published_Date__c is not null then date_format(capa_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss')
  ELSE date_format(nc_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss') 
  END AS INVESTIGATION_APPROVED_ON
, date_format(nc_details.compliancequest__Aware_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_IDENTIFIED
, '' as IMPACT_ASSESSMENT_APPROVED_BY --not available in comet
, '' as IMPACT_ASSESSMENT_APPROVED_ON --not available in comet
, '' as ORIGINAL_DUE_DATE --not available in comet
, date_format(nc_details.compliancequest__Close_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_CLOSED
, '' as QUALITY_ISSUE_CLOSED_BY --not available in comet
, CASE 
  WHEN capa_details.compliancequest__Title__c is not null then concat(nc_details.compliancequest__NC_Title__c ,' (NC) - ',capa_details.compliancequest__Title__c, ' (CAPA)')
  ELSE concat(nc_details.compliancequest__NC_Title__c,' (NC)') 
  END AS TITLE
, nc_lot.CQ_JNJ_Release_from_Investigation__c as RELEASE_FROM_INVESTIGATION
, date_format(nc_investigation.compliancequest__Completed_On__c, 'yyyy-MM-dd HH:mm:ss') as DATE_INVESTIGATION_COMPLETE
, nc_lot.CQ_JNJ_Source_System__c as SOURCE_SYSTEM

from SQA.vw_comet_nc_details nc_details
inner join SQA.COMET_SITES sites on nc_details.compliancequest__Org_Site__c = sites.J_J_SITE_NAME
inner join SQA.vw_NC_ImpactedPartLotRecords nc_lot on nc_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
left join SQA.vw_comet_capa_details capa_details on capa_details.compliancequest__SQX_Source_NC__c = nc_details.id
left join SQA.vw_comet_capa_impactedpartlotrecords capa_lot on capa_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
left join SQA.vw_comet_nc_additionalinforecords nc_additional on nc_additional.CQ_JNJ_SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_nc_riskassessmentrecords nc_risk on nc_risk.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_capa_responseapprovalrecords capa_response_app on capa_response_app.compliancequest__SQX_CAPA__c = capa_details.Id
left join SQA.vw_comet_nc_responseapprovalrecords nc_response_app on nc_response_app.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_NC_FindingResponseRecords nc_finding_response on nc_finding_response.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_CAPA_FindingResponseRecords capa_finding_response on capa_finding_response.compliancequest__SQX_capa__c = capa_details.Id
left join SQA.vw_comet_nc_investigationrecords nc_investigation on nc_investigation.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_capa_investigationrecords capa_investigation on capa_investigation.compliancequest__SQX_CAPA__c = capa_details.Id
-- Start additional sites Feb 2024
left join SQA.vw_comet_NC_AdditionalSites nc_additionalsites on nc_details.id = nc_additionalsites.CQ_JNJ_Nonconformance__c 
-- End additional sites Feb 2024

left join (
  select J_J_SITE_NAME,
         BATCH_ID_LOT_NUMBER,
         PR_ID,
         BATCH_NO
  from sqa.comet_history 
  where ACTION = 'OPEN'
) history on history.J_J_SITE_NAME = nc_details.compliancequest__Org_Site__c
         and history.BATCH_ID_LOT_NUMBER = nc_lot.compliancequest__Lot_Number__c
         and (CASE 
              WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
              ELSE nc_details.Name 
              END) like concat(history.PR_ID, '%')
         and nvl(history.BATCH_NO, 'NA') = nvl(concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c), 'NA')

-- Start additional sites Feb 2024
-- check whether an OPEN record exists for the additional site in the history. 
left join (
  select J_J_SITE_NAME,
         BATCH_ID_LOT_NUMBER,
         PR_ID,
         BATCH_NO
  from sqa.comet_history hist
  where action = 'OPEN'
  ) hist_add_sites 
  on hist_add_sites.J_J_SITE_NAME = nc_additionalsites.CQ_JNJ_J_J_Site_Name__r_Name
         and hist_add_sites.BATCH_ID_LOT_NUMBER = nc_lot.compliancequest__Lot_Number__c
         and (CASE 
              WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
              ELSE nc_details.Name 
              END) like concat(hist_add_sites.PR_ID, '%')
         and nvl(hist_add_sites.BATCH_NO, 'NA') = nvl(concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c), 'NA')
-- End additional sites Feb 2024


where 
--Update Jan 17 2024
(
(nc_details.compliancequest__Status__c = 'Draft' and nc_details.compliancequest__Record_Stage__c = 'Triage' and nc_lot.compliancequest__Lot_Number__c <> 'NA') 
OR
(nc_details.compliancequest__Status__c = 'Open' and nc_details.compliancequest__Record_Stage__c = 'Disposition_Investigate' and history.PR_ID is null and nc_lot.compliancequest__Lot_Number__c <> 'NA')
OR
-- Start additional sites Feb 2024
(nc_details.compliancequest__Status__c = 'Open' and nc_details.compliancequest__Record_Stage__c = 'Disposition_Investigate' and history.J_J_SITE_NAME <> nc_additionalsites.CQ_JNJ_J_J_Site_Name__r_Name and nc_lot.compliancequest__Lot_Number__c <> 'NA' and nc_additionalsites.CQ_JNJ_J_J_Site_Name__r_Name <> 'N/A') 
)
-- End additional sites Feb 2024

order by nc_details.Name desc
"""

# COMMAND ----------

df = spark.sql(open_query)
df.createOrReplaceTempView('open_comet_dataset')
spark.catalog.cacheTable('open_comet_dataset')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where PR_ID like "%NC-023800%" and BATCH_NO like "418725-PJB1000"

# COMMAND ----------

# MAGIC %sql
# MAGIC select CreatedDate, LastModifiedDate, name, CQ_JNJ_Functional_Area_1__c, compliancequest__Org_Site__c, CQ_JNJ_Functional_Area__c, compliancequest__Status__c, compliancequest__Record_Stage__c, INSERTED_AT
# MAGIC from
# MAGIC  
# MAGIC sqa.comet_capa_details
# MAGIC  where
# MAGIC  --name = "CAPA-002600"
# MAGIC  --and
# MAGIC  CreatedDate < '2024-12-30T00:00:00.000+0000'
# MAGIC  and CreatedDate > '2024-10-08T00:00:00.000+0000'
# MAGIC  --and LastModifiedDate
# MAGIC  -- CQ_JNJ_Functional_Area_1__c like '%MSAT%'
# MAGIC  order by INSERTED_AT desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select CQ_JNJ_Functional_Area_1__c, compliancequest__Org_Site__c, CQ_JNJ_Functional_Area__c, name, compliancequest__Status__c, compliancequest__Record_Stage__c, INSERTED_AT
# MAGIC from
# MAGIC  
# MAGIC sqa.comet_capa_details
# MAGIC --  where
# MAGIC -- name = "CAPA-000184" 
# MAGIC  
# MAGIC  order by INSERTED_AT desc

# COMMAND ----------

close_query = """
select 
-- Start CSV fields --
  nc_details.compliancequest__Org_Site__c as J_J_SITE_NAME
-- lot info
, concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c) AS BATCH_NO
, nc_lot.compliancequest__Lot_Number__c as BATCH_ID_LOT_NUMBER 
, nc_lot.CQ_JNJ_Material_Item__c as MATERIAL_ITEM
--NC/CAPA name - if capa present, the capa id will be concatenated with the nc id
, CASE 
  WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
  ELSE nc_details.Name 
  END AS PR_ID
--NC/CAPA stage/state - if capa present, the capa stage/state will be concatenated with the nc stage/state
, CASE 
  WHEN capa_details.Name is not null then concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC) / ', capa_details.compliancequest__Record_Stage__c,'-',capa_details.compliancequest__Status__c, ' (CAPA)')
  ELSE concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC)') 
  END AS STATE
, nc_risk.compliancequest__Conclusion__c as PROJECT
, date_format(nc_details.CreatedDate, 'yyyy-MM-dd HH:mm:ss') as DATE_CREATED
, nc_details.CreatedBy_Name as ORIGINATOR
, CASE 
  WHEN capa_details.Owner_Name is not null then concat(nc_details.owner_name,' (NC) - ',capa_details.Owner_Name, ' (CAPA)')
  ELSE concat(nc_details.owner_name,' (NC)') 
  END AS ASSIGNED_TO
, CASE 
  WHEN capa_details.compliancequest__Due_Date_Investigation__c is not null then date_format(capa_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss')
  ELSE date_format(nc_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss') 
  END AS DUE_DATE
-- ACTION
, 'CLOSE' as ACTION
, '' as COMMENT_TEXT
, nc_details.CQ_JNJ_Functional_Area_1__c as J_J_FUNCTIONAL_AREA_1
, nc_details.CQ_JNJ_Functional_Area_2__c as J_J_FUNCTIONAL_AREA_2
, nc_details.compliancequest__Org_Division__c as J_J_SEGMENT
, nc_details.compliancequest__Org_Business_Unit__c as J_J_BUSINESS_UNIT
, nc_additional.CQ_JNJ_SQX_Mfg_Category__c as MFG_CATEGORY
, nc_additional.CQ_JNJ_SQX_Mfg_Technology__c as MFG_TECHNOLOGY  
-- not ingested to date - , nc_additional.CQ_JNJ_SQX_Equipment_List__c as MFG_EQUIPMENT_LIST  
, '' as MFG_EQUIPMENT_LIST
, nc_risk.compliancequest__Conclusion__c as INVESTIGATION_LEVEL
, CASE 
  WHEN capa_response_app.compliancequest__SQX_User__r_name is not null then concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC) - ',capa_response_app.compliancequest__SQX_User__r_name, ' (CAPA)')
  ELSE concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC)') 
  END AS INVESTIGATION_APPROVED_BY
, CASE 
  WHEN capa_finding_response.compliancequest__Published_Date__c is not null then date_format(capa_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss')
  ELSE date_format(nc_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss') 
  END AS INVESTIGATION_APPROVED_ON
, date_format(nc_details.compliancequest__Aware_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_IDENTIFIED
, '' as IMPACT_ASSESSMENT_APPROVED_BY --not available in comet
, '' as IMPACT_ASSESSMENT_APPROVED_ON --not available in comet
, '' as ORIGINAL_DUE_DATE --not available in comet
, date_format(nc_details.compliancequest__Close_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_CLOSED
, '' as QUALITY_ISSUE_CLOSED_BY --not available in comet
, CASE 
  WHEN capa_details.compliancequest__Title__c is not null then concat(nc_details.compliancequest__NC_Title__c ,' (NC) - ',capa_details.compliancequest__Title__c, ' (CAPA)')
  ELSE concat(nc_details.compliancequest__NC_Title__c,' (NC)') 
  END AS TITLE
, nc_lot.CQ_JNJ_Release_from_Investigation__c as RELEASE_FROM_INVESTIGATION
, date_format(nc_investigation.compliancequest__Completed_On__c, 'yyyy-MM-dd HH:mm:ss') as DATE_INVESTIGATION_COMPLETE
, nc_lot.CQ_JNJ_Source_System__c as SOURCE_SYSTEM

from SQA.vw_comet_nc_details nc_details
inner join SQA.COMET_SITES sites on nc_details.compliancequest__Org_Site__c = sites.J_J_SITE_NAME
inner join SQA.vw_NC_ImpactedPartLotRecords nc_lot on nc_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
left join SQA.vw_comet_capa_details capa_details on capa_details.compliancequest__SQX_Source_NC__c = nc_details.id
left join SQA.vw_comet_capa_impactedpartlotrecords capa_lot on capa_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
left join SQA.vw_comet_nc_additionalinforecords nc_additional on nc_additional.CQ_JNJ_SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_nc_riskassessmentrecords nc_risk on nc_risk.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_capa_responseapprovalrecords capa_response_app on capa_response_app.compliancequest__SQX_CAPA__c = capa_details.Id
left join SQA.vw_comet_nc_responseapprovalrecords nc_response_app on nc_response_app.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_NC_FindingResponseRecords nc_finding_response on nc_finding_response.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_CAPA_FindingResponseRecords capa_finding_response on capa_finding_response.compliancequest__SQX_capa__c = capa_details.Id
left join SQA.vw_comet_nc_investigationrecords nc_investigation on nc_investigation.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_capa_investigationrecords capa_investigation on capa_investigation.compliancequest__SQX_CAPA__c = capa_details.Id
left join (
  select J_J_SITE_NAME,
         BATCH_ID_LOT_NUMBER,
         PR_ID,
         BATCH_NO
  from sqa.comet_history 
  where ACTION = 'OPEN'
) history on history.J_J_SITE_NAME = nc_details.compliancequest__Org_Site__c
         and history.BATCH_ID_LOT_NUMBER = nc_lot.compliancequest__Lot_Number__c
         and (CASE 
              WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
              ELSE nc_details.Name 
              END) like concat(history.PR_ID, '%')
         and nvl(history.BATCH_NO, 'NA') = nvl(concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c), 'NA')

where 
--For a NC record in status ‘VOID’ -- case1
((nc_details.compliancequest__Status__c = 'Void') OR 
-- NC Flow : For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND no CAPA record AND Product impact = Product grid is filled with Product and lot number -- case2
(nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.Name is null)  OR
-- NC Flow : For a NC record with an existing site/material/batch, at NC ‘CLOSED’ stage ; NC ‘CLOSED’ status AND Product impact = Product grid is filled with Product and lot number -- case3
(nc_details.compliancequest__Record_Stage__c = 'Closed' and nc_details.compliancequest__Status__c = 'Closed') OR
-- NC flow: For a NC record from which a product/lot has been removed from the grid = released from investigation flag = yes -- case4
(nc_details.compliancequest__Status__c = 'Open' and  nc_details.compliancequest__Record_Stage__c = 'Disposition_Investigate' and nc_lot.CQ_JNJ_Release_from_Investigation__c = 'Yes') OR
-- NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND a CAPA record at CAPA ‘IMPLEMENT’ stage ; CAPA ‘OPEN’ status Product impact = Product grid is filled with Product and lot number -- case5
(nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Implement' and capa_details.compliancequest__Status__c = 'Open') OR 
--NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND a CAPA record at CAPA ‘VERIFICATION’ stage ; CAPA ‘COMPLETE’ status Product impact = Product grid is filled with Product and lot number -- -- case6
(nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Verfication' and capa_details.compliancequest__Status__c = 'Complete') OR 
-- NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND a CAPA record at CAPA ‘Closed’ stage ; CAPA ‘Closed’ status Product impact = Product grid is filled with Product and lot number -- case7
(nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Closed' and capa_details.compliancequest__Status__c = 'Closed') OR 
--NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘VERIFICATION’ stage ; NC ‘COMPLETE’ status AND a CAPA record at ‘IMPLEMENT’ stage ; CAPA ‘OPEN’ status Product impact = Product grid is filled with Product and lot number -- case 8
(nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Implement' and capa_details.compliancequest__Status__c = 'Open') OR
--NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘VERIFICATION’ stage ; NC ‘COMPLETE’ status AND a CAPA record at CAPA ‘VERIFICATION’ stage ; CAPA ‘COMPLETE’ status Product impact = Product grid is filled with Product and lot number -- case 9
(nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Verification' and capa_details.compliancequest__Status__c = 'Complete') OR
--NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘VERIFICATION’ stage ; NC ‘COMPLETE’ status AND a CAPA record at CAPA ‘CLOSED’ stage ; CAPA ‘CLOSED’ status Product impact = Product grid is filled with Product and lot number -- case 10
(nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Closed' and capa_details.compliancequest__Status__c = 'Closed') OR
--NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘CLOSED’ stage ; NC ‘CLOSED’ status AND a CAPA record at CAPA ‘CLOSED’ stage ; CAPA ‘CLOSED’ status Product impact = Product grid is filled with Product and lot number -- case 11
(nc_details.compliancequest__Record_Stage__c = 'Closed' and nc_details.compliancequest__Status__c = 'Closed' and capa_details.compliancequest__Record_Stage__c = 'Closed' and capa_details.compliancequest__Status__c = 'Closed')

)
and history.PR_ID is not null
order by nc_details.Name desc
"""

# COMMAND ----------

df = spark.sql(close_query)
df.createOrReplaceTempView('close_comet_dataset')
spark.catalog.cacheTable('close_comet_dataset')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from close_comet_dataset where BATCH_NO like "%PJB1000%"

# COMMAND ----------

update_query = """
select 
-- Start CSV fields --
  nc_details.compliancequest__Org_Site__c as J_J_SITE_NAME
-- lot info
, concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c) AS BATCH_NO
, nc_lot.compliancequest__Lot_Number__c as BATCH_ID_LOT_NUMBER 
, nc_lot.CQ_JNJ_Material_Item__c as MATERIAL_ITEM
--NC/CAPA name - if capa present, the capa id will be concatenated with the nc id
, CASE 
  WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
  ELSE nc_details.Name 
  END AS PR_ID
--NC/CAPA stage/state - if capa present, the capa stage/state will be concatenated with the nc stage/state
, CASE 
  WHEN capa_details.Name is not null then concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC) / ', capa_details.compliancequest__Record_Stage__c,'-',capa_details.compliancequest__Status__c, ' (CAPA)')
  ELSE concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC)') 
  END AS STATE
, nc_risk.compliancequest__Conclusion__c as PROJECT
, date_format(nc_details.CreatedDate, 'yyyy-MM-dd HH:mm:ss') as DATE_CREATED
, nc_details.CreatedBy_Name as ORIGINATOR
, CASE 
  WHEN capa_details.Owner_Name is not null then concat(nc_details.owner_name,' (NC) - ',capa_details.Owner_Name, ' (CAPA)')
  ELSE concat(nc_details.owner_name,' (NC)') 
  END AS ASSIGNED_TO
, CASE 
  WHEN capa_details.compliancequest__Due_Date_Investigation__c is not null then date_format(capa_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss')
  ELSE date_format(nc_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss') 
  END AS DUE_DATE
-- ACTION
, 'UPDATE' as ACTION
, '' as COMMENT_TEXT
, nc_details.CQ_JNJ_Functional_Area_1__c as J_J_FUNCTIONAL_AREA_1
, nc_details.CQ_JNJ_Functional_Area_2__c as J_J_FUNCTIONAL_AREA_2
, nc_details.compliancequest__Org_Division__c as J_J_SEGMENT
, nc_details.compliancequest__Org_Business_Unit__c as J_J_BUSINESS_UNIT
, nc_additional.CQ_JNJ_SQX_Mfg_Category__c as MFG_CATEGORY
, nc_additional.CQ_JNJ_SQX_Mfg_Technology__c as MFG_TECHNOLOGY  
-- not ingested to date - , nc_additional.CQ_JNJ_SQX_Equipment_List__c as MFG_EQUIPMENT_LIST  
, '' as MFG_EQUIPMENT_LIST
, nc_risk.compliancequest__Conclusion__c as INVESTIGATION_LEVEL
, CASE 
  WHEN capa_response_app.compliancequest__SQX_User__r_name is not null then concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC) - ',capa_response_app.compliancequest__SQX_User__r_name, ' (CAPA)')
  ELSE concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC)') 
  END AS INVESTIGATION_APPROVED_BY
, CASE 
  WHEN capa_finding_response.compliancequest__Published_Date__c is not null then date_format(capa_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss')
  ELSE date_format(nc_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss') 
  END AS INVESTIGATION_APPROVED_ON
, date_format(nc_details.compliancequest__Aware_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_IDENTIFIED
, '' as IMPACT_ASSESSMENT_APPROVED_BY --not available in comet
, '' as IMPACT_ASSESSMENT_APPROVED_ON --not available in comet
, '' as ORIGINAL_DUE_DATE --not available in comet
, date_format(nc_details.compliancequest__Close_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_CLOSED 
, '' as QUALITY_ISSUE_CLOSED_BY --not available in comet
, CASE 
  WHEN capa_details.compliancequest__Title__c is not null then concat(nc_details.compliancequest__NC_Title__c ,' (NC) - ',capa_details.compliancequest__Title__c, ' (CAPA)')
  ELSE concat(nc_details.compliancequest__NC_Title__c,' (NC)') 
  END AS TITLE
, nc_lot.CQ_JNJ_Release_from_Investigation__c as RELEASE_FROM_INVESTIGATION
, date_format(nc_investigation.compliancequest__Completed_On__c, 'yyyy-MM-dd HH:mm:ss') as DATE_INVESTIGATION_COMPLETE
, nc_lot.CQ_JNJ_Source_System__c as SOURCE_SYSTEM

from SQA.vw_comet_nc_details nc_details
inner join SQA.COMET_SITES sites on nc_details.compliancequest__Org_Site__c = sites.J_J_SITE_NAME
inner join SQA.vw_NC_ImpactedPartLotRecords nc_lot on nc_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
left join SQA.vw_comet_capa_details capa_details on capa_details.compliancequest__SQX_Source_NC__c = nc_details.id
left join SQA.vw_comet_capa_impactedpartlotrecords capa_lot on capa_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
left join SQA.vw_comet_nc_additionalinforecords nc_additional on nc_additional.CQ_JNJ_SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_nc_riskassessmentrecords nc_risk on nc_risk.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_capa_responseapprovalrecords capa_response_app on capa_response_app.compliancequest__SQX_CAPA__c = capa_details.Id
left join SQA.vw_comet_nc_responseapprovalrecords nc_response_app on nc_response_app.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_NC_FindingResponseRecords nc_finding_response on nc_finding_response.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_CAPA_FindingResponseRecords capa_finding_response on capa_finding_response.compliancequest__SQX_capa__c = capa_details.Id
left join SQA.vw_comet_nc_investigationrecords nc_investigation on nc_investigation.compliancequest__SQX_Nonconformance__c = nc_details.Id
left join SQA.vw_comet_capa_investigationrecords capa_investigation on capa_investigation.compliancequest__SQX_CAPA__c = capa_details.Id

where 
(
-- 1. NC flow: NC Stage 'Disposition/Investigate' / Status 'Open' ; CAPA: N/A
(nc_details.compliancequest__Record_Stage__c = 'Disposition_Investigate' and nc_details.compliancequest__Status__c = 'Open') OR
-- 2. NC + CAPA flow: NC Stage 'Implement / Status = 'Open' ; CAPA Stage 'Investigate’ / Status = 'Open'
(nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Investigate' and capa_details.compliancequest__Status__c = 'Open') OR
-- 3. NC + CAPA flow: NC Stage 'Verification’ / Status = 'Complete' ; CAPA Stage 'Investigate’ / Status = 'Open'
(nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Investigate' and capa_details.compliancequest__Status__c = 'Open')
)

order by nc_details.Name desc
"""

# COMMAND ----------

df = spark.sql(update_query)
df.createOrReplaceTempView('update_comet_dataset')
spark.catalog.cacheTable('update_comet_dataset')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from update_comet_dataset where BATCH_NO like "%PJB1000%"

# COMMAND ----------

update_sql = """
SELECT distinct
    ins.J_J_SITE_NAME
  , ins.BATCH_NO 
  , ins.BATCH_ID_LOT_NUMBER 
  , ins.MATERIAL_ITEM 
  , ins.PR_ID
  , ins.STATE 
  , ins.PROJECT
  , ins.DATE_CREATED 
  , ins.ORIGINATOR
  , ins.ASSIGNED_TO
  , ins.DUE_DATE
  , ins.ACTION
  , ins.COMMENT_TEXT
  , ins.J_J_FUNCTIONAL_AREA_1
  , ins.J_J_FUNCTIONAL_AREA_2
  , ins.J_J_SEGMENT
  , ins.J_J_BUSINESS_UNIT
  , ins.MFG_CATEGORY 
  , ins.MFG_TECHNOLOGY 
  , ins.MFG_EQUIPMENT_LIST
  , ins.INVESTIGATION_LEVEL
  , ins.INVESTIGATION_APPROVED_BY
  , ins.INVESTIGATION_APPROVED_ON 
  , ins.DATE_IDENTIFIED
  , ins.IMPACT_ASSESSMENT_APPROVED_BY
  , ins.IMPACT_ASSESSMENT_APPROVED_ON
  , ins.ORIGINAL_DUE_DATE
  , ins.DATE_CLOSED
  , ins.QUALITY_ISSUE_CLOSED_BY
  , ins.TITLE
  , ins.RELEASE_FROM_INVESTIGATION
  , ins.DATE_INVESTIGATION_COMPLETE
  , ins.SOURCE_SYSTEM
from update_comet_dataset ins
inner join SQA.vw_comet_history hist on ins.J_J_SITE_NAME = hist.J_J_SITE_NAME
                                and ins.BATCH_ID_LOT_NUMBER = hist.BATCH_ID_LOT_NUMBER
                                and ins.PR_ID like concat(hist.PR_ID,'%')
                                and nvl(ins.BATCH_NO,'NA') = nvl(hist.BATCH_NO,'NA')
where (ins.STATE <> hist.STATE
or ins.ASSIGNED_TO <> hist.ASSIGNED_TO
or ins.DUE_DATE <> hist.DUE_DATE
or ins.J_J_FUNCTIONAL_AREA_1 <> hist.J_J_FUNCTIONAL_AREA_1
or ins.J_J_FUNCTIONAL_AREA_2 <> hist.J_J_FUNCTIONAL_AREA_2
or ins.J_J_SEGMENT <> hist.J_J_SEGMENT
or ins.J_J_BUSINESS_UNIT <> hist.J_J_BUSINESS_UNIT
or ins.MFG_CATEGORY <> hist.MFG_CATEGORY
or ins.MFG_TECHNOLOGY <> hist.MFG_TECHNOLOGY
or ins.INVESTIGATION_LEVEL <> hist.INVESTIGATION_LEVEL
or ins.INVESTIGATION_APPROVED_BY <> hist.INVESTIGATION_APPROVED_BY
or ins.INVESTIGATION_APPROVED_ON <> hist.INVESTIGATION_APPROVED_ON
or ins.DATE_CLOSED <> hist.DATE_CLOSED
or ins.RELEASE_FROM_INVESTIGATION <> hist.RELEASE_FROM_INVESTIGATION
or ins.DATE_INVESTIGATION_COMPLETE <> hist.DATE_INVESTIGATION_COMPLETE)
"""

# COMMAND ----------

actions_sql ="""
SELECT actions.*
FROM (

    SELECT distinct
        ins.J_J_SITE_NAME
      , ins.BATCH_NO 
      , ins.BATCH_ID_LOT_NUMBER 
      , ins.MATERIAL_ITEM 
      , ins.PR_ID
      , ins.STATE 
      , ins.PROJECT
      , ins.DATE_CREATED 
      , ins.ORIGINATOR
      , ins.ASSIGNED_TO
      , ins.DUE_DATE
      , ins.ACTION
      , ins.COMMENT_TEXT
      , ins.J_J_FUNCTIONAL_AREA_1
      , ins.J_J_FUNCTIONAL_AREA_2
      , ins.J_J_SEGMENT
      , ins.J_J_BUSINESS_UNIT
      , ins.MFG_CATEGORY 
      , ins.MFG_TECHNOLOGY 
      , ins.MFG_EQUIPMENT_LIST
      , ins.INVESTIGATION_LEVEL
      , ins.INVESTIGATION_APPROVED_BY
      , ins.INVESTIGATION_APPROVED_ON 
      , ins.DATE_IDENTIFIED
      , ins.IMPACT_ASSESSMENT_APPROVED_BY
      , ins.IMPACT_ASSESSMENT_APPROVED_ON
      , ins.ORIGINAL_DUE_DATE
      , ins.DATE_CLOSED
      , ins.QUALITY_ISSUE_CLOSED_BY
      , ins.TITLE
      , ins.RELEASE_FROM_INVESTIGATION
      , ins.DATE_INVESTIGATION_COMPLETE
      , ins.SOURCE_SYSTEM
    FROM open_comet_dataset ins

    UNION ALL

    SELECT distinct
        ins.J_J_SITE_NAME
      , ins.BATCH_NO 
      , ins.BATCH_ID_LOT_NUMBER 
      , ins.MATERIAL_ITEM 
      , ins.PR_ID
      , ins.STATE 
      , ins.PROJECT
      , ins.DATE_CREATED 
      , ins.ORIGINATOR
      , ins.ASSIGNED_TO
      , ins.DUE_DATE
      , ins.ACTION
      , ins.COMMENT_TEXT
      , ins.J_J_FUNCTIONAL_AREA_1
      , ins.J_J_FUNCTIONAL_AREA_2
      , ins.J_J_SEGMENT
      , ins.J_J_BUSINESS_UNIT
      , ins.MFG_CATEGORY 
      , ins.MFG_TECHNOLOGY 
      , ins.MFG_EQUIPMENT_LIST
      , ins.INVESTIGATION_LEVEL
      , ins.INVESTIGATION_APPROVED_BY
      , ins.INVESTIGATION_APPROVED_ON 
      , ins.DATE_IDENTIFIED
      , ins.IMPACT_ASSESSMENT_APPROVED_BY
      , ins.IMPACT_ASSESSMENT_APPROVED_ON
      , ins.ORIGINAL_DUE_DATE
      , ins.DATE_CLOSED
      , ins.QUALITY_ISSUE_CLOSED_BY
      , ins.TITLE
      , ins.RELEASE_FROM_INVESTIGATION
      , ins.DATE_INVESTIGATION_COMPLETE
      , ins.SOURCE_SYSTEM
    FROM close_comet_dataset ins
    
) actions

LEFT JOIN SQA.COMET_HISTORY his ON actions.J_J_SITE_NAME = his.J_J_SITE_NAME 
                               AND actions.BATCH_ID_LOT_NUMBER = his.BATCH_ID_LOT_NUMBER 
                               AND actions.PR_ID like concat(his.PR_ID,'%')
                               AND nvl(actions.BATCH_NO, 'NA') = nvl(his.BATCH_NO, 'NA')
                               AND actions.ACTION = his.ACTION
WHERE his.PR_ID IS NULL """

# COMMAND ----------

dbutils.notebook.exit("exit")

# COMMAND ----------

etl_id = sqif.get_etl_id()
print('etl_id: ', etl_id)
df_actions = spark.sql(actions_sql)
df_updates = spark.sql(update_sql)
all_results_df = df_actions.union(df_updates)

# COMMAND ----------

all_results_df.createOrReplaceTempView('all_results_table')
spark.catalog.cacheTable('all_results_table')

# COMMAND ----------

all_results_df = all_results_df.withColumn('ETL_ID', lit(etl_id))  
all_results_df = all_results_df.withColumn("INSERTED_AT", current_timestamp())

# COMMAND ----------

all_results_df.write.format("delta").mode("overwrite").saveAsTable('SQA.COMET_NEW_RECORDS')

# COMMAND ----------

sql = "Select * from SQA.COMET_NEW_RECORDS"
all_results_new_df = spark.sql(sql)
all_results_new_df.cache()
all_results_count = all_results_new_df.count()
print('all_results_count: ', all_results_count)

# COMMAND ----------

print('get mandatory fields')
trimmed_results_df = all_results_new_df.select(
  col('J_J_SITE_NAME'),
  col('BATCH_NO'),
  col('BATCH_ID_LOT_NUMBER'),
  col('MATERIAL_ITEM'),
  col('PR_ID'),
  col('STATE'),
  col('PROJECT'),
  col('DATE_CREATED'),
  col('ORIGINATOR'),
  col('ASSIGNED_TO'),
  col('DUE_DATE'),
  col('ACTION'),
  col('COMMENT_TEXT'),
  col('J_J_FUNCTIONAL_AREA_1'),
  col('J_J_FUNCTIONAL_AREA_2'),
  col('J_J_SEGMENT'),
  col('J_J_BUSINESS_UNIT'),
  col('MFG_CATEGORY'),
  col('MFG_TECHNOLOGY'),
  col('MFG_EQUIPMENT_LIST'),
  col('INVESTIGATION_LEVEL'),
  col('INVESTIGATION_APPROVED_BY'),
  col('INVESTIGATION_APPROVED_ON'),
  col('DATE_IDENTIFIED'),
  col('IMPACT_ASSESSMENT_APPROVED_BY'),
  col('IMPACT_ASSESSMENT_APPROVED_ON'),
  col('ORIGINAL_DUE_DATE'),
  col('DATE_CLOSED'),
  col('QUALITY_ISSUE_CLOSED_BY'),
  col('TITLE'),
  col('RELEASE_FROM_INVESTIGATION'),
  col('DATE_INVESTIGATION_COMPLETE'),
  col('SOURCE_SYSTEM')
)

trimmed_results_df.cache()
print('Getting result count')
trimmed_results_count = trimmed_results_df.count()
print('Result Count: ', trimmed_results_count)

# COMMAND ----------

if trimmed_results_count != all_results_count:
  raise Exception("Result counts do not match (trimmed_results_count:{0}, all_results_count:{1})".format(trimmed_results_count, all_results_count))

# COMMAND ----------

if trimmed_results_count==0:
  print('Zero results, updating config')
  sqlContext.clearCache()
  dbutils.notebook.exit('Zero results, exiting')

# COMMAND ----------

print('converting to csv')
filename = sqif.to_csv(trimmed_results_df.orderBy(
  ['BATCH_ID_LOT_NUMBER', 'PR_ID'] 
), 'comet_nc_capa_csv_file')
print('csv file created: ', filename)

# COMMAND ----------

try:
  print('sftping')
  sftp_result = sqif.sftp(filename, 'uploadtw')
  print('sftp successful')
except:
  dbutils.notebook.exit('Unable to SFTP, exiting')
  raise Exception("SFTP failed")

# COMMAND ----------

print('Moving file from processing to archive')
sqif.move_csv_to_archive(filename, 'comet_csv_file')

# COMMAND ----------

print('saving results to history')
sqif.save(all_results_new_df, 'SQA.COMET_HISTORY') 
print('saving results to history complete')

# COMMAND ----------

print('exit')
sqlContext.clearCache()
dbutils.notebook.exit(filename)