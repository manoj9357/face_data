# Databricks notebook source
# MAGIC %sh
# MAGIC nc -zv ajdpdeltaadlsn1.blob.core.windows.net 443

# COMMAND ----------

# MAGIC %sh
# MAGIC nc -zv ajlpdeltamdh.blob.core.windows.net 443

# COMMAND ----------

# MAGIC %sh
# MAGIC nc -zv hszpdeltamdh.dfs.core.windows.net 443

# COMMAND ----------

# MAGIC %sh
# MAGIC nslookup ajdpdeltaadlsn1.blob.core.windows.net

# COMMAND ----------

# MAGIC %sh
# MAGIC nslookup ajdpdeltaadlsn1.dfs.core.windows.net

# COMMAND ----------

# MAGIC %sh
# MAGIC nslookup ajlpdeltamdh.privatelink.dfs.core.windows.net

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM cdl_make_prod_pasx.activity LIMIT 10

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM cdl_prod_l1_batch_genealogy.l1_genealogy LIMIT 10

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM cdl_prod_l0_atlas.vnd_mcha LIMIT 10

# COMMAND ----------

# MAGIC %sh
# MAGIC nslookup ajlpdeltamdh.blob.core.windows.net

# COMMAND ----------

# MAGIC %sh
# MAGIC nslookup ajlpdeltamdh.dfs.core.windows.net

# COMMAND ----------

