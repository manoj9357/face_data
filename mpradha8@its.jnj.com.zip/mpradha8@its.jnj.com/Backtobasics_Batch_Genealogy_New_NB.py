# Databricks notebook source
# MAGIC %run ../Packages/sqif_Framework

# COMMAND ----------

import datetime
import time
import re
from pyspark.sql.functions import *
from datetime import datetime as dt
from functools import reduce
from pyspark.sql import DataFrame
import pandas as pd

sqif = Framework()

# COMMAND ----------

# sql_new_batches = """
#   SELECT ub_his.TENANT_ID, ub_his.MFG_LOT_NUMBER, ub_his.PRODUCT_ID
#   FROM SQA.BACKTOBASICS_UPCOMING_BATCHES_HISTORY ub_his --Upcoming batches history
#   LEFT JOIN SQA.BACKTOBASICS_BATCH_GENEALOGY_HISTORY gen_his --Batch genealogy history
#             ON ub_his.TENANT_ID = gen_his.TENANT_ID 
#             AND ub_his.MFG_LOT_NUMBER = gen_his.MFG_LOT_NUMBER 
#             AND ub_his.PRODUCT_ID = gen_his.PRODUCT_ID
#   WHERE ub_his.action = 'END-BRR' -- END-BRR was sent before
#   AND gen_his.MFG_LOT_NUMBER is null -- batch gen has not been sent before
# """


# COMMAND ----------

sql_new_batches = """
  SELECT ub_his.TENANT_ID, ub_his.MFG_LOT_NUMBER, ub_his.PRODUCT_ID
  FROM SQA.BACKTOBASICS_UPCOMING_BATCHES_HISTORY ub_his --Upcoming batches history
  LEFT JOIN SQA.BATCH_GENEALOGY_HISTORY gen_his --Batch genealogy history
            ON ub_his.TENANT_ID = gen_his.TENANT_ID
            AND 
            (ub_his.BATCH_NO = gen_his.PARENT_NO OR ub_his.BATCH_NO = gen_his.SUBLOT_NO)
  WHERE ub_his.action = 'END-BRR' -- END-BRR was sent before
  AND gen_his.PARENT_NO is null -- batch gen has not been sent before
  AND gen_his.SUBLOT_NO is null -- batch gen has not been sent before
  AND ub_his.INSERTED_AT > '2024-01-01T00:00:00.00+00:00'
"""

# COMMAND ----------

sql_batch_genealogy = """
 SELECT  
         gen.INP_PLNT_NUM AS TENANT_ID
       , CONCAT(INP_MATL_NUM, '-', gen.INP_BTCH_NUM) AS PARENT_NO
       , CONCAT(gen.OUTP_MATL_NUM, '-', gen.OUTP_BTCH_NUM) AS SUBLOT_NO
 FROM backtobasics_new_batches batches
 INNER JOIN cdl_prod_l1_batch_genealogy.l1_genealogy gen ON batches.TENANT_ID = gen.INP_PLNT_NUM 
                                   AND batches.MFG_LOT_NUMBER = gen.INP_BTCH_NUM 
                                   AND batches.PRODUCT_ID = gen.INP_MATL_NUM 
 WHERE gen.OUTP_BTCH_NUM IS NOT NULL 
   AND gen.OUTP_BTCH_NUM <> ''
   AND gen.SRC_SYS_CD = 'bbl'
UNION 

 SELECT 
          gen.INP_PLNT_NUM AS TENANT_ID
        , CONCAT(gen.INP_MATL_NUM, '-', gen.INP_BTCH_NUM) AS PARENT_NO
        , CONCAT(gen.OUTP_MATL_NUM, '-', gen.OUTP_BTCH_NUM) AS SUBLOT_NO
 FROM backtobasics_new_batches batches
 INNER JOIN cdl_prod_l1_batch_genealogy.l1_genealogy gen ON batches.TENANT_ID = gen.OUTP_PLNT_NUM 
                                   AND batches.MFG_LOT_NUMBER = gen.OUTP_BTCH_NUM 
                                   AND batches.PRODUCT_ID = gen.OUTP_MATL_NUM
  WHERE gen.SRC_SYS_CD = 'bbl'                                   
"""
     

# COMMAND ----------

sqif.update_processing_state('BACKTOBASICS_BATCHES_GENEALOGY', 'SQA.BACKTOBASICS_BATCH_GENEALOGY') 

etl_id = sqif.get_etl_id()
print('etl_id: ', etl_id)

print('Getting backtobasics_genealogy_batches')
new_batches_df = spark.sql(sql_new_batches)
new_batches_df.createOrReplaceTempView('backtobasics_new_batches')
spark.catalog.cacheTable('backtobasics_new_batches')

print('Getting all_batch_genealogy_df')
all_batch_genealogy_df = spark.sql(sql_batch_genealogy)  

print('data retrieval complete')

# COMMAND ----------

print('Getting result count')
all_batch_genealogy_count = all_batch_genealogy_df.count()
print('Batch Genealogy Count: ', all_batch_genealogy_count)

# COMMAND ----------

if all_batch_genealogy_count==0:
  print('Zero results, updating config')
  sqif.update_config(None, 'BACKTOBASICS_BATCHES_GENEALOGY', 'SQA.BACKTOBASICS_BATCH_GENEALOGY')
  sqlContext.clearCache()
  dbutils.notebook.exit('Zero results, exiting')

# COMMAND ----------

print('converting to csv')
filename = sqif.to_csv(all_batch_genealogy_df, 'backtobasics_batches_genealogy_csv_file')
print('csv file created: ', filename)

# COMMAND ----------

try:
  print('sftping')
  sftp_result = sqif.sftp(filename, 'uploadlg')
except:
  dbutils.notebook.exit('Unable to SFTP, exiting')

print('sftp successful')

# COMMAND ----------

print('Moving file from processing to archive')
sqif.move_csv_to_archive(filename, 'backtobasics_batches_genealogy')

# COMMAND ----------

print('saving results to all batch genealogy history')
all_batch_genealogy_history_df = all_batch_genealogy_df.withColumn("SOURCE", lit("bbl")).withColumn("INSERTED_AT", current_timestamp()).withColumn("ETL_ID", lit(etl_id))
sqif.save(all_batch_genealogy_history_df, 'SQA.BATCH_GENEALOGY_HISTORY') 
print('saving results to all batch genealogy history complete')

# COMMAND ----------

print('saving results to history')
new_batches_history_df = new_batches_df.withColumn("INSERTED_AT", current_timestamp()).withColumn("ETL_ID", lit(etl_id))
sqif.save(new_batches_history_df, 'SQA.BACKTOBASICS_BATCH_GENEALOGY_HISTORY') 
print('saving results to history complete')

# COMMAND ----------

print('updating config')
sqif.update_config(filename, 'BACKTOBASICS_BATCHES_GENEALOGY', 'SQA.BACKTOBASICS_BATCH_GENEALOGY') 
print('config updated')

# COMMAND ----------

print('exit')
sqlContext.clearCache()
dbutils.notebook.exit(filename)