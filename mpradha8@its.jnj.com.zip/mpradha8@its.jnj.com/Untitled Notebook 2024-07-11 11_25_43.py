# Databricks notebook source
# MAGIC %pip install pysftp

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list("mdhdevsqascope")

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC select * from sqa.mes_ebrreview_time where Batch_Number in ('PFJ71')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.pandas_upcoming_batches_history where BATCH_NO in('030001B-PFJ71')

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.atlas_batch_genealogy;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.atlas_batch_genealogy_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.atlas_upcoming_batches;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.atlas_upcoming_batches_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.atlas_upcoming_batches_history_copy;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.atlas_upcoming_batches_run;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.backtobasics_batch_genealogy;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.backtobasics_batch_genealogy_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.backtobasics_upcoming_batches;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.backtobasics_upcoming_batches_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.backtobasics_upcoming_batches_run;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.batch_genealogy_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_capa_details;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_capa_findingresponserecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_capa_impactedpartlotrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_capa_investigationrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_capa_responseapprovalrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_csv_audit;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_additionalinforecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_additionalsites;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_details;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_findingresponserecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_impactedpartlotrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_investigationrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_responseapprovalrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_nc_riskassessmentrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_new_records;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.comet_sites;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.config_atlas_products;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.config_backtobasics_products;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.config_europe2_end_qa_brr_groups;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.config_europe2_products;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.config_pandas_products;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.config_sustain_products;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.elims_approval_data;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.elims_sample_data;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_batch_genealogy;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_batch_genealogy_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_mfg_plants;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_resource_plants;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_upcoming_batches;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_upcoming_batches_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_upcoming_batches_run;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.europe2_user_stats;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.mes_ebrreview_time;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.pandas_batch_genealogy;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.pandas_batch_genealogy_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.pandas_upcoming_batches;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.pandas_upcoming_batches_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.pandas_upcoming_batches_run;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.sustain_batch_genealogy;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.sustain_batch_genealogy_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.sustain_production_units;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.sustain_sites;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.sustain_upcoming_batches;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.sustain_upcoming_batches_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_capa_details;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_capa_findingresponserecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_capa_impactedpartlotrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_capa_investigationrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_capa_responseapprovalrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_nc_additionalinforecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_nc_additionalsites;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_nc_details;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_nc_findingresponserecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_nc_investigationrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_nc_responseapprovalrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_comet_nc_riskassessmentrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from sqa.vw_nc_impactedpartlotrecords;

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC   run_id,
# MAGIC   run_name,
# MAGIC   job_id,
# MAGIC   original_attempt_run_id,
# MAGIC   attempt_number,
# MAGIC   creator_user_name,
# MAGIC   run_duration as run_duration_ms,
# MAGIC   account_id
# MAGIC from
# MAGIC   databricks_job_run;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cdl_make_prod_pasx.activity order by ETL_CREATEDATE desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cdl_make_prod_pasx.activity order by ETL_CREATEDATE desc

# COMMAND ----------

import random
print("\u25CF \u250C \u2500 \u2510 \u2502 \u2514 \u2518")

# COMMAND ----------

dice_art={
    1:("┌─────────┐",
       "│         │",
       "│    ●    │",
       "│         │",
       "└─────────┘"),
    2:("┌─────────┐",
       "│ ●       │",
       "│         │",
       "│       ● │",
       "└─────────┘"),
    3:("┌─────────┐",
       "│ ●       │",
       "│    ●    │",
       "│       ● │",
       "└─────────┘"),
    4:("┌─────────┐",
       "│ ●     ● │",
       "│         │",
       "│ ●     ● │",
       "└─────────┘"),
    5:("┌─────────┐",
       "│ ●     ● │",
       "│    ●    │",
       "│ ●     ● │",
       "└─────────┘"),
    6:("┌─────────┐",
       "│ ●     ● │",
       "│ ●     ● │",
       "│ ●     ● │",
       "└─────────┘")
}

dice=[]
total=0
num_of_dice=int(input("How many Dice?: "))

for die in range(num_of_dice):
   dice.append(random.randint(1,6))
Print(dice)

# COMMAND ----------

