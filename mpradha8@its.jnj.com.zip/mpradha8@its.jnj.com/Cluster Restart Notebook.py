# Databricks notebook source
import requests 
# databricks_url=dbutils.widgets.get("Databricks_url") 
# # access_token = dbutils.widgets.get("Access") 
# cluster_id = dbutils.widgets.get("Cluster_id") 
databricks_url = "https://adb-4933264770484963.3.azuredatabricks.net"
access_token = "dapi831b55c6d4663aa199d0204ce8636c44-2"
cluster_id = "1212-034401-claws171"


restart_url = f"{databricks_url}/api/2.0/clusters/restart"
headers = {"Authorization": f"Bearer {access_token}"}
data = {"cluster_id": cluster_id}

try:
    response = requests.post(restart_url, json=data, headers=headers)
    if response.status_code == 200:
        print(f"Cluster {cluster_id} restarted successfully.")
    else:
        print(f"Error restarting cluster {cluster_id}.")
except requests.RequestException as e:
    print(f"Error: {e}")

# COMMAND ----------

# import requests 
# # databricks_url=dbutils.widgets.get("Databricks_url") 
# # # access_token = dbutils.widgets.get("Access") 
# # cluster_id = dbutils.widgets.get("Cluster_id") 
# databricks_url = "https://adb-4933264770484963.3.azuredatabricks.net"
# access_token = "dapi831b55c6d4663aa199d0204ce8636c44-2"
# cluster_id = "1212-034401-claws171"


# restart_url = f"{databricks_url}/api/2.0/clusters/restart"
# headers = {"Authorization": f"Bearer {access_token}"}
# data = {"cluster_id": cluster_id}

# try:
#     response = requests.post(restart_url, json=data, headers=headers)
#     if response.status_code == 200:
#         print(f"Cluster {cluster_id} restarted successfully.")
#     else:
#         print(f"Error restarting cluster {cluster_id}.")
# except requests.RequestException as e:
#     print(f"Error: {e}")
