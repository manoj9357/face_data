# Databricks notebook source
class FailureException(Exception):
    pass
        

# COMMAND ----------

atlas_upcoming_batches_status = False
atlas_upcoming_batches_error = None
try:
  dbutils.notebook.run("/Shared/SQA/Atlas/Atlas_Upcoming_Batches",2400,{})
  atlas_upcoming_batches_status = True
except Exception as e:
  print('Exception: ', e)
  atlas_upcoming_batches_error = e
  atlas_upcoming_batches_status = False
print("Error in Atlas_Upcoming_Batches" if not atlas_upcoming_batches_status else '')

# COMMAND ----------

atlas_batch_genealogy_status = False
atlas_batch_genealogy_error = None
try:
  dbutils.notebook.run("/Shared/SQA/Atlas/Atlas_Batch_Genealogy",2400,{})
  atlas_batch_genealogy_status = True
except Exception as e:
  print('Exception: ', e)
  atlas_batch_genealogy_error = e
  atlas_batch_genealogy_status = False
print("Error in Atlas_Batch_Genealogy" if not atlas_batch_genealogy_status else '')

# COMMAND ----------

if not atlas_upcoming_batches_status or not atlas_batch_genealogy_status:
  err_msg = 'atlas batch genealogy error: ' + str(atlas_batch_genealogy_error) if not atlas_batch_genealogy_status else ''
  err_msg = err_msg + "\r\n" 'atlas upcoming batches error: ' + str(atlas_upcoming_batches_error) if not atlas_upcoming_batches_status else ''
  raise FailureException(err_msg)

# COMMAND ----------

print(atlas_batch_genealogy_status)

# COMMAND ----------

print(atlas_upcoming_batches_status)