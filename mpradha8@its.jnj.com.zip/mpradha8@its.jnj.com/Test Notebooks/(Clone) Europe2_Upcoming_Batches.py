# Databricks notebook source
# MAGIC %run ../Packages/sqif_Framework

# COMMAND ----------

from functools import reduce
from pyspark.sql import DataFrame
 
sqif = Framework()

# COMMAND ----------

# sqif.update_processing_state('EUROPE2_UPCOMING_BATCHES', 'SQA.EUROPE2_UPCOMING_BATCHES')

# COMMAND ----------

df=spark.sql("SELECT * FROM SQA.EUROPE2_UPCOMING_BATCHES where NAME = 'EUROPE2_UPCOMING_BATCHES'")#.first()
display(df)

# COMMAND ----------

path = dbutils.secrets.get('sqa', 'sqa_processing_location')
print(path[0:2])
print(path[2:1000])

# COMMAND ----------

# List all mount points in DBFS
mounts = dbutils.fs.mounts()

# Print the mount points
for mount in mounts:
    print(f"Mount Point: {mount.mountPoint}, Source: {mount.source}")
    
    # Check if the mount point matches the location you're looking for
    if "/mnt/your-mount-point" in mount.mountPoint:
        print(f"Found mount at {mount.mountPoint} pointing to {mount.source}")

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

base_query_mfg = """
SELECT 
    qals.mandant
  , qals.werk
  , qals.matnr
  , qals.charg
  , qals.prueflos
  , mcha.ersda
  , CASE
    WHEN qals.aufnr is null and qals.ebeln is null and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN qals.aufnr = ' ' and qals.ebeln = ' ' and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN mcha.lwedt = '00000000' then mcha.ersda
    ELSE mcha.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , qals.aufnr
  , qals.ebeln
  , qals.paendterm
  , mara.mtart
  , mcha.cuobj_bm
  , '' as yqualf 
  , CASE 
      WHEN marc.webaz IS NULL THEN ''
      WHEN marc.webaz = '0' THEN ''
      ELSE marc.webaz
    END AS grpt
  , qals.aenderdat
  , qals.aenderzeit
  , mcha.ERSDA_TZ_SYS

FROM cdl_prod_l0_europe2.vnd_qals qals 

LEFT JOIN SQA.EUROPE2_MFG_PLANTS mfg on qals.werk = mfg.reswk

INNER JOIN cdl_prod_l0_europe2.vnd_mara mara ON qals.mandant = mara.mandt 
                              AND qals.matnr = mara.matnr 
                                                           
INNER JOIN cdl_prod_l0_europe2.vnd_mcha mcha ON qals.mandant = mcha.mandt 
                              AND qals.werk = mcha.werks 
                              AND qals.charg = mcha.charg 
                              AND qals.matnr = mcha.matnr
  
LEFT JOIN cdl_prod_l0_europe2.vnd_marc marc  ON qals.mandant = marc.mandt 
                              AND qals.werk = marc.werks 
                              AND qals.matnr = marc.matnr

LEFT JOIN SQA.CONFIG_EUROPE2_PRODUCTS pI ON pI.plant = qals.werk 
                                       AND pI.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd') 
                                       AND pI.product_type = mara.mtart
LEFT JOIN (SELECT Plant as Plant, INCLUDED_EXCLUDED_MATL, MAX(created_date) AS created_date
          FROM SQA.CONFIG_EUROPE2_PRODUCTS 
          WHERE INCLUDED_EXCLUDED_MATL = 'E'
          GROUP BY Plant, INCLUDED_EXCLUDED_MATL) pE ON pE.plant = qals.werk 
                                       AND pE.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd')
LEFT JOIN cdl_prod_l0_europe2.mkpf mkpf on qals.MBLNR=mkpf.MBLNR                                                                 
WHERE  ( pI.INCLUDED_EXCLUDED_MATL = 'I' 
        OR  (pI.INCLUDED_EXCLUDED_MATL IS NULL AND pE.INCLUDED_EXCLUDED_MATL = 'E')
      )
  AND qals.charg <> ' '
  AND qals.herkunft <> '03' 
  AND qals.sprache = 'E'
"""

# COMMAND ----------

base_query_non_mfg = """
SELECT 
    qals.mandant
  , qals.werk
  , qals.matnr
  , qals.charg
  , qals.prueflos
  , mcha.ersda
  , CASE
    WHEN qals.aufnr is null and qals.ebeln is null and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN qals.aufnr = ' ' and qals.ebeln = ' ' and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN mcha.lwedt = '00000000' then mcha.ersda
    ELSE mcha.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , qals.aufnr 
  , ypm1.aufnr as ebeln 
  , qals.paendterm
  , mara.mtart
  , mcha.cuobj_bm
  , ysls.yqualf 
  , '' as grpt
  , qals.aenderdat
  , qals.aenderzeit
  , mcha.ERSDA_TZ_SYS

FROM cdl_prod_l0_europe2.vnd_qals qals 

LEFT JOIN SQA.EUROPE2_MFG_PLANTS mfg on qals.werk = mfg.reswk

INNER JOIN cdl_prod_l0_europe2.vnd_mara mara ON qals.mandant = mara.mandt 
                              AND qals.matnr = mara.matnr 
                              
INNER JOIN cdl_prod_l0_europe2.vnd_mcha mcha ON qals.mandant = mcha.mandt 
                              AND qals.werk = mcha.werks 
                              AND qals.charg = mcha.charg 
                              AND qals.matnr = mcha.matnr
 
INNER JOIN 
    ( SELECT distinct matnr, eu_dc_batch_id, yqualf
     FROM cdl_prod_l0_europe2.vnd_YSLSGRC
     ) ysls ON qals.matnr = ysls.matnr and qals.charg = ysls.eu_dc_batch_id 
INNER JOIN cdl_prod_l0_europe2.vnd_cawn cawn on ysls.yqualf = cawn.atwrt
INNER JOIN cdl_prod_l0_europe2.vnd_cabn cabn on cawn.atinn = cabn.atinn and cawn.adzhl = cabn.adzhl  

INNER JOIN cdl_prod_l0_europe2.vnd_YPM00001 ypm1 on qals.mandant = ypm1.mandt and qals.werk = ypm1.werks and qals.charg = ypm1.charg and qals.matnr = ypm1.matnr  

LEFT JOIN SQA.CONFIG_EUROPE2_PRODUCTS pI ON pI.plant = qals.werk 
                                       AND pI.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd') 
                                       AND pI.product_type = mara.mtart
LEFT JOIN (SELECT Plant as Plant, INCLUDED_EXCLUDED_MATL, MAX(created_date) AS created_date
          FROM SQA.CONFIG_EUROPE2_PRODUCTS 
          WHERE INCLUDED_EXCLUDED_MATL = 'E'
          GROUP BY Plant, INCLUDED_EXCLUDED_MATL) pE ON pE.plant = qals.werk 
                                       AND pE.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd')
LEFT JOIN cdl_prod_l0_europe2.mkpf mkpf on qals.MBLNR=mkpf.MBLNR                                                                    
WHERE  ( pI.INCLUDED_EXCLUDED_MATL = 'I' 
        OR  (pI.INCLUDED_EXCLUDED_MATL IS NULL AND pE.INCLUDED_EXCLUDED_MATL = 'E')
      )
  AND qals.charg <> ' '
  AND qals.herkunft <> '03' 
  AND qals.sprache = 'E'
  AND mfg.reswk is null -- Only include non-mfg plants
  AND cabn.atnam = 'C_RELEASE_QP' 
  
"""

# COMMAND ----------

df_base_query_mfg = spark.sql(base_query_mfg)
df_base_query_non_mfg = spark.sql(base_query_non_mfg)
df_base_query_all = df_base_query_mfg.union(df_base_query_non_mfg)

df_base_query_all.createOrReplaceTempView('base_e2_dataset')
spark.catalog.cacheTable('base_e2_dataset')

# COMMAND ----------

base_filter_query = """
SELECT 
    base.mandant
  , base.werk
  , base.matnr
  , base.charg
  , base.prueflos
  , base.ersda
  , base.lwedt 
  , base.enstehdat
  , base.entstezeit
  , base.objnr
  , base.aufnr
  , base.ebeln
  , base.paendterm
  , base.mtart
  , base.cuobj_bm
  , base.yqualf
  , base.grpt
  , base.aenderdat
  , base.aenderzeit
  , base.ERSDA_TZ_SYS

FROM base_e2_dataset base 

-- Only keep IL with latest date
INNER JOIN 
    (
       SELECT mandant, werk, charg, matnr, max(enstehdat) AS max_il_creation_date
       FROM base_e2_dataset
       GROUP BY mandant, werk, charg, matnr
     ) max_date ON base.mandant = max_date.mandant 
               AND base.werk = max_date.werk 
               AND base.charg = max_date.charg 
               AND base.matnr = max_date.matnr 
               AND base.enstehdat = max_date.max_il_creation_date
       
-- And only keep IL with latest time (for the latest date)
INNER JOIN 
    (
      SELECT mandant, werk, charg, matnr, enstehdat, max(entstezeit) AS max_il_creation_time
      FROM base_e2_dataset
      GROUP BY mandant, werk, charg, matnr, enstehdat
     ) max_time ON base.mandant = max_time.mandant 
               AND base.werk = max_time.werk 
               AND base.charg = max_time.charg 
               AND base.matnr = max_time.matnr 
               AND base.enstehdat = max_time.enstehdat 
               AND base.entstezeit = max_time.max_il_creation_time
               
"""

# COMMAND ----------

df_base_filter_query = spark.sql(base_filter_query)
df_base_filter_query.createOrReplaceTempView('filtered_e2_dataset')
spark.catalog.cacheTable('filtered_e2_dataset')

# COMMAND ----------

enhanced_base_query ="""
SELECT 
    base.werk AS TENANT_ID
  , concat(regexp_replace(base.matnr, '^[0]*', ''), '-', base.charg) AS BATCH_NO
  , regexp_replace(base.matnr, '^[0]*', '') AS PRODUCT_ID  
  , nvl(makt.maktx, '') AS PRODUCT_DESCRIPTION 
  , base.charg AS MFG_LOT_NUMBER
  , base.ersda AS ARRIVAL_DATE 
  , 'DEFAULT' AS TRANSACTION_NO
  , base.lwedt AS DATE_RECEIVED 
  , '' AS CSV_COMMENT 
  , nvl(dynamic_mod.mic_ind, '') AS OPTIONAL_1
  , case when (qn_yp.has_open_qn = 'Y' or qn_yv.has_open_qn = 'Y' or qn_ib.has_open_qn = 'Y') then 'X'
  --, case when (qn_yp.has_open_qn = 'Y' or qn_yv.has_open_qn = 'Y') then 'X' 
    else ''
    end as OPTIONAL_2
  , nvl(bat_class.text_restriction, '') as OPTIONAL_3
  , nvl(bat_class.available_for, '') as OPTIONAL_4
  , nvl(bat_class.not_available_for, '') as OPTIONAL_5
  , nvl(bat_class.available_for_customer, '') as OPTIONAL_6
  , nvl(bat_class.not_available_for_customer, '') as OPTIONAL_7
  , '' as OPTIONAL_8
  , trim(base.aufnr) AS OPTIONAL_9
  , trim(base.ebeln) AS OPTIONAL_10
  , nvl(po_status.txt04, '') AS OPTIONAL_11
  , concat_ws(" ", il_status.user_stats) AS OPTIONAL_12
  , nvl(bat_class.batch_status, '') AS OPTIONAL_13
  , t001w.name1 AS OPTIONAL_14 
  , nvl(bat_class.batch_name, '') AS OPTIONAL_15
  , base.mtart AS OPTIONAL_16
  , nvl(mat_class.brandname, '') AS OPTIONAL_17
  , base.grpt AS OPTIONAL_18
  , base.yqualf AS OPTIONAL_19
  , base.paendterm AS OPTIONAL_20 
  , nvl(resource.resource_num, '') AS OPTIONAL_21 
  , '' AS OPTIONAL_22
  , '' AS OPTIONAL_23
  , base.aenderdat AS OPTIONAL_24
  , base.aenderzeit AS OPTIONAL_25
  , base.ERSDA_TZ_SYS AS OPTIONAL_26
  , '' AS OPTIONAL_27
  , '' AS OPTIONAL_28
  , '' AS OPTIONAL_29
  , '' AS OPTIONAL_30
  , base.mandant
  , base.prueflos
  , base.aufnr
  , base.objnr
  , base.cuobj_bm
  , base.matnr
  , po_status.udate as end_brr_date
  , po_status.utime as end_brr_hour 
  , il_status.udate as end_qa_brr_date
  , il_status.utime as end_qa_brr_hour
  , brr_status.erstelldat as end_qa_brr2_date
  , brr_status.zeiterstl as end_qa_brr2_hour
  , nvl(il_status.user_stats, array()) as il_status 
  
  -- UPDATE_1: END-QA-BRR data
  , nvl(ebr_status.dbewertg, '') AS ebr_status
  , nvl(ebr_status.username, '') As ebr_username
  , nvl(brr_status.dbewertg, '') AS brr_status
  , nvl(brr_status.username, '') As brr_username
 -- END UPDATE_1
 
 --** USERNAME UPDATE 1 of 5 **
  , nvl(po_status.usnam, '') As teco_username
  , nvl(il_status.avjd_usnam, '') As avjd_username
 --**
 
FROM filtered_e2_dataset base

-- Get plant name
INNER JOIN cdl_prod_l0_europe2.vnd_t001w t001w ON base.mandant = t001w.mandt 
                                AND base.werk = t001w.werks
                                
-- Get material description (if available)                              
LEFT JOIN cdl_prod_l0_europe2.vnd_makt makt ON base.mandant = makt.mandt 
                              AND base.matnr = makt.matnr                                 
                                
-- Get MIC IND
LEFT JOIN ( 
    SELECT distinct mandant, prueflos, 'X' AS mic_ind
    FROM cdl_prod_l0_europe2.vnd_qamr 
    WHERE DBEWERTG = 'R' ) dynamic_mod ON base.mandant = dynamic_mod.mandant 
                                      AND base.prueflos = dynamic_mod.prueflos

                                   
LEFT JOIN (
    SELECT afpo.aufnr, mkal.werks, mkal.matnr, left(trim(mkal.text1), 5) as resource_num
    FROM cdl_prod_l0_europe2.vnd_afpo afpo
    INNER JOIN cdl_prod_l0_europe2.vnd_mkal mkal on afpo.verid = mkal.verid
                                                and afpo.matnr = mkal.matnr
                                                and afpo.dwerk = mkal.werks
    INNER JOIN SQA.EUROPE2_RESOURCE_PLANTS resp on mkal.werks = resp.werks
    WHERE left(trim(mkal.text1), 1) = 'A'
) resource on base.aufnr = resource.aufnr and base.matnr = resource.matnr and base.werk = resource.werks

--*******START OF QN UPDATES ********

-- Open Quality notifications for PO
LEFT JOIN (
  SELECT distinct qmel.fertaufnr, 'Y' as has_open_qn
  FROM cdl_prod_l0_europe2.vnd_qmel qmel
  INNER JOIN cdl_prod_l0_europe2.vnd_jest jest on qmel.objnr = jest.objnr
  
    LEFT JOIN (
    select distinct objnr
    from cdl_prod_l0_europe2.vnd_jest 
    where stat = 'I0072' 
    and inact <> 'X') jest_noco on qmel.objnr = jest_noco.objnr
    
  WHERE qmel.qmart = 'YP'
  AND qmel.fertaufnr <> ' '
  AND jest.inact <> 'X'
  AND jest.stat <> 'I0072' 
  AND jest_noco.objnr is null -- *********
  
) qn_yp on base.aufnr = qn_yp.fertaufnr

-- Open Quality notifications for PO Master Recipe
LEFT JOIN (
  SELECT DISTINCT afko.aufnr, 'Y' as has_open_qn
  FROM cdl_prod_l0_europe2.vnd_afko afko
  INNER JOIN cdl_prod_l0_europe2.vnd_qmel qmel 
    ON qmel.yytib_plnty = afko.plnty
    AND qmel.yytib_plnnr = afko.plnnr
    AND qmel.yytib_plnal = afko.plnal
  INNER JOIN cdl_prod_l0_europe2.vnd_jest jest on qmel.objnr = jest.objnr
  
    LEFT JOIN (
    select distinct objnr
    from cdl_prod_l0_europe2.vnd_jest 
    where stat = 'I0072' 
    and inact <> 'X') jest_noco on qmel.objnr = jest_noco.objnr
    
  WHERE afko.plnty = '2'
  AND qmel.qmart = 'YV'
  AND jest.inact <> 'X'
  AND jest.stat <> 'I0072' 
  AND jest_noco.objnr is null -- *********
) qn_yv on base.aufnr = qn_yv.aufnr

-- Open Quality notifications for Impacted Batches
LEFT JOIN (
SELECT DISTINCT ytibq.matnr, ytibq.charg, 'Y' as has_open_qn 
FROM cdl_prod_l0_europe2.vnd_ytibq00001 ytibq
INNER JOIN cdl_prod_l0_europe2.vnd_qmel qmel on ytibq.qmnum = qmel.qmnum
INNER JOIN cdl_prod_l0_europe2.vnd_jest jest on qmel.objnr = jest.objnr

  LEFT JOIN (
    select distinct objnr
    from cdl_prod_l0_europe2.vnd_jest 
    where stat = 'I0072' 
    and inact <> 'X') jest_noco on qmel.objnr = jest_noco.objnr
    
WHERE ytibq.loekz = ' ' 
AND jest.inact <> 'X'
AND jest.stat <> 'I0072' 
AND jest_noco.objnr is null -- *********
) qn_ib on base.matnr = qn_ib.matnr and base.charg = qn_ib.charg

--*******END OF QN UPDATES ********

-- Get TECO Status (PO only)
LEFT JOIN (
      SELECT aufk.mandt, 
             aufk.aufnr, 
             tj02t.txt04, 
             jcds.usnam,
             jcds.udate,
             jcds.utime
      FROM cdl_prod_l0_europe2.vnd_aufk aufk 
      INNER JOIN cdl_prod_l0_europe2.vnd_jest jest ON aufk.mandt = jest.mandt 
                                   AND aufk.objnr = jest.objnr
      INNER JOIN cdl_prod_l0_europe2.vnd_tj02t tj02t ON jest.stat = tj02t.istat
      LEFT JOIN cdl_prod_l0_europe2.vnd_jcds jcds ON jest.mandt = jcds.mandt 
                                                 and jest.stat = jcds.stat 
                                                 and jest.objnr = jcds.objnr 
                                                 and jest.chgnr = jcds.chgnr 
      WHERE jest.inact <> 'X'
      AND tj02t.spras = 'E'
      AND tj02t.txt04 = 'TECO'
      ) po_status  ON base.mandant = po_status.mandt 
                   AND base.aufnr = po_status.aufnr

-- Get IL User Statuses 
LEFT JOIN
  (
    SELECT distinct
           jest.mandt, 
           jest.objnr
    -- ** USERNAME UPDATE 4 of 5 **
    , max(
      case when user_stat.txt04 = 'AVJD' then jcds.usnam
      else ''
      end
      ) over (partition by jest.mandt, jest.objnr) as avjd_usnam 
    -- ** 
    , collect_set(user_stat.txt04) over (partition by jest.mandt, jest.objnr) as user_stats
    , jcds.udate
    , jcds.utime
    FROM cdl_prod_l0_europe2.vnd_jest jest
    INNER JOIN cdl_prod_l0_europe2.vnd_tj30t user_stat ON jest.mandt = user_stat.mandt 
                                       AND jest.stat = user_stat.estat
    -- Only check for configured stats                                   
    INNER JOIN SQA.EUROPE2_USER_STATS stats ON stats.stsma = user_stat.stsma and stats.estat = user_stat.estat 
    LEFT JOIN cdl_prod_l0_europe2.vnd_jcds jcds ON jest.mandt = jcds.mandt and jest.stat = jcds.stat and jest.objnr = jcds.objnr and jest.chgnr = jcds.chgnr 
    WHERE jest.inact <> 'X'
    AND user_stat.spras = 'E'
  ) il_status ON base.mandant = il_status.mandt 
                AND base.objnr = il_status.objnr
                
-- UPDATE_2: Get END-QA-BRR characteristics               

LEFT JOIN
  (
   SELECT qamr.mandant, qamr.prueflos, qamr.dbewertg, 
     case when qamr.aenderer <> ' ' then qamr.aenderer
     else qamr.pruefer
     end as username
   FROM cdl_prod_l0_europe2.vnd_qamr qamr
   INNER JOIN cdl_prod_l0_europe2.vnd_qamv qamv 
   ON qamr.mandant = qamv.mandant AND qamr.prueflos = qamv.prueflos AND qamr.vorglfnr = qamv.vorglfnr AND qamr.merknr = qamv.merknr
   WHERE qamv.verwmerkm = 'XX-EBR' AND qamv.ltextspr = 'E'  
  ) ebr_status ON base.mandant = ebr_status.mandant and base.prueflos = ebr_status.prueflos

-- Latina
LEFT JOIN
  (
   SELECT qamr.mandant, 
          qamr.prueflos, 
          qamr.dbewertg, 
          case when qamr.aenderer <> ' ' then qamr.aenderer
          else qamr.pruefer
          end as username,
          qamr.erstelldat,
          qamr.zeiterstl
   FROM cdl_prod_l0_europe2.vnd_qamr qamr
   INNER JOIN cdl_prod_l0_europe2.vnd_qamv qamv 
   ON qamr.mandant = qamv.mandant AND qamr.prueflos = qamv.prueflos AND qamr.vorglfnr = qamv.vorglfnr AND qamr.merknr = qamv.merknr
   WHERE qamv.verwmerkm = 'BD-200' AND qamv.ltextspr = 'E'  
  ) brr_status ON base.mandant = brr_status.mandant and base.prueflos = brr_status.prueflos

-- END UPDATE_2


-- Get Material Classification for Brand Name                             
LEFT JOIN (
    SELECT inob.objek, ausp.atwrt as brandname 
    FROM cdl_prod_l0_europe2.vnd_inob inob 
    INNER JOIN cdl_prod_l0_europe2.vnd_ausp ausp on inob.cuobj = ausp.objek and inob.klart = ausp.klart
    INNER JOIN cdl_prod_l0_europe2.vnd_cabn cabn on ausp.atinn = cabn.atinn and ausp.adzhl = cabn.adzhl
    WHERE inob.klart = '001'
    AND inob.obtab = 'MARA'
    AND cabn.ATNAM = 'BRANDNAME'
    ) mat_class on base.matnr = mat_class.objek

-- Get Batch Classification Characteristics
-- Use PIVOT to create column for each characteristic
LEFT JOIN (

 SELECT objek
 , batch_status
 , batch_name
 , text_restriction
 , available_for
 , not_available_for
 , available_for_customer
 , not_available_for_customer
 
 FROM (
    SELECT ausp.objek as objek, cabn.atnam as atnam 
    , CASE 
    WHEN cabn.atnam = 'BATCH_NAME' THEN ausp.atwrt
    WHEN cabn.atnam = 'BATCH_STATUS' THEN cawnt_values.atwtb
    ELSE 'X'
  END AS char_value
    FROM cdl_prod_l0_europe2.vnd_ausp ausp
    INNER JOIN cdl_prod_l0_europe2.vnd_cabn cabn on ausp.atinn = cabn.atinn and ausp.adzhl = cabn.adzhl
    
    -- TODO Replace SQA.EUROPE2_CAWNT with cdl_prod_l0_europe2.vnd_CAWNT when table available in CDL
    LEFT JOIN (
      SELECT cawn.atinn, cawn.adzhl, cawn.atwrt, cawnt.atwtb
      FROM cdl_prod_l0_europe2.vnd_cawn cawn
      INNER JOIN cdl_prod_l0_europe2.vnd_cawnt cawnt on cawn.atinn = cawnt.atinn and cawn.adzhl = cawnt.adzhl and cawn.atzhl = cawnt.atzhl
      WHERE cawnt.spras = 'E'
    ) cawnt_values ON ausp.atinn = cawnt_values.atinn and ausp.adzhl = cawnt_values.adzhl and ausp.atwrt = cawnt_values.atwrt
     
    WHERE ausp.klart = '022'
    AND cabn.atnam in ('TEXT_RESTRICTION', 'AVAILABLE_FOR', 'NOT_AVAILABLE_FOR', 'AVAILABLE_FOR_CUSTOMER', 'NOT_AVAILABLE_FOR_CUSTOMER', 'BATCH_NAME', 'BATCH_STATUS')
    AND nvl(ausp.atwrt, '') <> '' 
    AND ausp.atwrt <> '?'
    
    )    
    PIVOT 
    (
    max(char_value) for atnam in ('TEXT_RESTRICTION', 'AVAILABLE_FOR', 'NOT_AVAILABLE_FOR', 'AVAILABLE_FOR_CUSTOMER', 'NOT_AVAILABLE_FOR_CUSTOMER', 'BATCH_NAME', 'BATCH_STATUS')
    )
 ) bat_class on base.cuobj_bm = bat_class.objek

 WHERE (makt.matnr is null or makt.spras = 'E')

"""

# COMMAND ----------

df = spark.sql(enhanced_base_query)
df.createOrReplaceTempView('enhanced_base_e2_dataset')
spark.catalog.cacheTable('enhanced_base_e2_dataset')

# COMMAND ----------

all_inserts_query = """
SELECT base.*
  -- AATE-20549, AATE-20548, AATE-20693, AATE-20755
  , case when base.OPTIONAL_13 in ('APPROVED', 'RESTRICTED USE', 'REPROCESS', 'REJECT', 'REWORK') then 'TRUE'
         when base.OPTIONAL_13 = 'REANALYSIS' and coalesce(pass_user.vcode,'') = 'I' and g.GROUP_ID = 2 then 'TRUE'
         when g.GROUP_ID = 2 and (coalesce(purchase_order.txt04,'') = 'LTCA' or coalesce(process_order.txt04,'') = 'LTCA') then 'TRUE'
         when (array_contains(base.il_status, 'AVJD') AND base.OPTIONAL_13 = 'PRE-APPROVED' and g.tenant_id in ('CHP1', 'CHP2')) OR (coalesce(pass_user.vcode,'') = 'P' AND array_contains(base.il_status, 'AVJD') and g.tenant_id in ('CHP1', 'CHP2')) then 'TRUE'
         when (array_contains(base.il_status, 'APG2') AND base.OPTIONAL_13 <> 'SPECIAL') then 'TRUE'
         when (array_contains(base.il_status, 'APG2') AND base.OPTIONAL_13 = 'SPECIAL' and g.tenant_id in ('CHP1', 'CHP2')) then 'TRUE'
         else 'FALSE'
    end AS pass_action
  , nvl(pass_user.username, '') AS pass_username
  
  , case when base.OPTIONAL_11 = 'TECO' then 'TRUE' 
         else 'FALSE' 
    end AS end_brr_action
  , base.teco_username as end_brr_username 
  -- UPDATE_3: END-QA-BRR criteria
  -- AATE-20556, AATE-20549
  , case when (g.GROUP_ID = 1 and array_contains(base.il_status, 'AVJD') and g.tenant_id not in ('CHP1', 'CHP2')) then 'TRUE' 
        when (g.GROUP_ID = 1  and array_contains(base.il_status, 'APG2') AND base.OPTIONAL_13 = 'SPECIAL' and g.tenant_id not in ('CHP1', 'CHP2')) then 'TRUE' 
        when (g.GROUP_ID = 2 and base.ebr_status in ('A', 'R')) then 'TRUE'
        when (g.GROUP_ID = 3 and base.brr_status in ('A', 'R')) then 'TRUE' 
        else 'FALSE'
    end AS end_qa_brr_action
    
  , case when g.GROUP_ID = 2 then base.ebr_username
         when g.GROUP_ID = 3 then base.brr_username
      --  when <Group1> then --To be added later  
         when g.GROUP_ID = 1 then base.avjd_username 
          else ''
    end AS end_qa_brr_username  
  -- END UPDATE_3
  -- END-QA-BRR2
  -- AATE-20653
  , case
    when (g.GROUP_ID = 3 and array_contains(base.il_status, 'AVJD') and array_contains(base.il_status, 'O') and array_contains(base.il_status, 'R')) THEN 'FALSE'
    when (g.GROUP_ID = 3 and array_contains(base.il_status, 'AVJD') and array_contains(base.il_status, 'A')) OR
         (g.GROUP_ID = 3 and array_contains(base.il_status, 'AVJD') and array_contains(base.il_status, 'B')) OR 
         (g.GROUP_ID = 3 and array_contains(base.il_status, 'AVJD') and array_contains(base.il_status, 'R')) OR 
         (g.GROUP_ID = 3 and array_contains(base.il_status, 'AVJD') and array_contains(base.il_status, 'W')) THEN 'TRUE'
    else 'FALSE'
    end as end_qa_brr2_action
  --AATE-20560
  , case
    when base.OPTIONAL_13 = 'PRE-APPROVED' and g.tenant_id in ('IEP1', 'BEP7') and coalesce(pass_user.vcode,'') = 'P' then 'TRUE'
    else 'FALSE'
    end as pre_pass_action
  , pass_user.vdatum as pre_pass_date
  , pass_user.vezeiterf as pre_pass_hour
  , pass_user.vaedatum as pass_date
  , pass_user.vezeitaen as pass_hour
  
  
FROM enhanced_base_e2_dataset base
INNER JOIN SQA.CONFIG_EUROPE2_END_QA_BRR_GROUPS g ON g.TENANT_ID = base.TENANT_ID
-- CHECK if Plant/Batch/Material previously INSERTED
LEFT JOIN (
     SELECT mandant, TENANT_ID, MFG_LOT_NUMBER, PRODUCT_ID
     FROM sqa.europe2_upcoming_batches_history
     WHERE action = 'INSERT'
   ) hist_insert  ON base.mandant = hist_insert.mandant 
             AND base.TENANT_ID = hist_insert.TENANT_ID 
             AND base.MFG_LOT_NUMBER = hist_insert.MFG_LOT_NUMBER 
             AND base.PRODUCT_ID = hist_insert.PRODUCT_ID
             
-- CHECK if Plant/Batch/Material previously PASSED
LEFT JOIN (
     SELECT mandant, TENANT_ID, MFG_LOT_NUMBER, PRODUCT_ID
     FROM sqa.europe2_upcoming_batches_history
     WHERE action = 'PASS'
   ) hist_pass  ON base.mandant = hist_pass.mandant 
             AND base.TENANT_ID = hist_pass.TENANT_ID 
             AND base.MFG_LOT_NUMBER = hist_pass.MFG_LOT_NUMBER 
             AND base.PRODUCT_ID = hist_pass.PRODUCT_ID             

-- GET PASS username (if it exists) 
LEFT JOIN (
  -- UPDATE_4: pass_username
     -- SELECT mandant, prueflos, nvl(vaename, vname) as username 
      SELECT mandant, prueflos, 
      case when vaename <> ' ' then vaename
      else vname
      end as username,
      vcode,
      vdatum,
      vezeiterf,
      vaedatum,
      vezeitaen
  -- END UPDATE_4
      FROM cdl_prod_l0_europe2.vnd_qave qave 
      WHERE qave.kzart = 'L'
   ) pass_user ON base.mandant = pass_user.mandant 
           AND base.prueflos = pass_user.prueflos

-- AATE-20755  GET Cancelled purchase order lots
LEFT JOIN (
    select distinct qals.charg, 
                    qals.mandant,
                    qals.werk,
                    qals.matnr,
                    tj02t.txt04
    from cdl_prod_l0_europe2.vnd_qals qals
    inner join cdl_prod_l0_europe2.vnd_YPM00001 ypm1 on qals.mandant = ypm1.mandt 
                                                     and qals.werk = ypm1.werks 
                                                     and qals.charg = ypm1.charg 
                                                     and qals.matnr = ypm1.matnr
    inner join cdl_prod_l0_europe2.vnd_jest jest on qals.mandant = qals.mandant 
                                                 and qals.objnr = jest.objnr
    inner join cdl_prod_l0_europe2.vnd_tj02t tj02t on jest.stat = tj02t.istat
    where jest.inact <> 'X'
    and tj02t.spras = 'E'
    and Tj02t.txt04 = 'LTCA'
) purchase_order on base.mandant = purchase_order.mandant
                and base.TENANT_ID = purchase_order.werk
                and base.MFG_LOT_NUMBER = purchase_order.charg
                and base.matnr = purchase_order.matnr

--AATE-20755 GET Cancelled process order lots
LEFT JOIN (
    select distinct qals.charg, 
                    qals.mandant,
                    qals.werk,
                    qals.matnr,
                    tj02t.txt04
    from cdl_prod_l0_europe2.vnd_qals qals
    inner join cdl_prod_l0_europe2.vnd_aufk aufk on qals.mandant = aufk.mandt 
                                                 and qals.aufnr = aufk.aufnr
    inner join cdl_prod_l0_europe2.vnd_jest jest on aufk.mandt = jest.mandt 
                                                 and aufk.objnr = jest.objnr
    inner join cdl_prod_l0_europe2.vnd_tj02t tj02t on jest.stat = tj02t.istat
    where jest.inact <> 'X'
    and tj02t.spras = 'E'
    and tj02t.txt04 = 'LTCA'
) process_order on base.mandant = process_order.mandant
                and base.TENANT_ID = process_order.werk
                and base.MFG_LOT_NUMBER = process_order.charg
                and base.matnr = process_order.matnr

-- CHECK IF MEETS CRITERIA FOR SENDING TO SMARTQA
WHERE 

   -- Open batches - Previously inserted but not previously passed. Any duplicate actions will be removed/filtered after the dataset is complete.
      (hist_insert.MFG_LOT_NUMBER IS NOT NULL AND hist_pass.MFG_LOT_NUMBER IS NULL ) 
   
    OR (
      -- New batches - Not previously inserted and not currently passed
      hist_insert.MFG_LOT_NUMBER IS NULL
      AND base.OPTIONAL_13 NOT in ('APPROVED', 'RESTRICTED USE', 'REPROCESS', 'REJECT', 'REWORK')
      AND NOT (array_contains(base.il_status, 'APG2') AND base.OPTIONAL_13 <> 'SPECIAL')
      AND NOT (base.OPTIONAL_13 = 'REANALYSIS' and coalesce(pass_user.vcode,'') = 'I' and g.GROUP_ID = 2)
      AND NOT (g.GROUP_ID = 2 and (coalesce(purchase_order.txt04,'') = 'LTCA' or coalesce(process_order.txt04,'') = 'LTCA'))
      AND NOT ((array_contains(base.il_status, 'AVJD') AND base.OPTIONAL_13 = 'PRE-APPROVED' and g.tenant_id in ('CHP1', 'CHP2')) OR (coalesce(pass_user.vcode,'') = 'P' AND array_contains(base.il_status, 'AVJD') and g.tenant_id in ('CHP1', 'CHP2')))
      AND NOT (array_contains(base.il_status, 'APG2') AND base.OPTIONAL_13 = 'SPECIAL' and g.tenant_id in ('CHP1', 'CHP2'))
          
    )  

"""

# COMMAND ----------

df = spark.sql(all_inserts_query)
df.createOrReplaceTempView('e2_all_inserts')
spark.catalog.cacheTable('e2_all_inserts')

# COMMAND ----------

updates_query = """
SELECT distinct
    ins.TENANT_ID
  , ins.BATCH_NO 
  , ins.PRODUCT_ID 
  , ins.PRODUCT_DESCRIPTION 
  , ins.MFG_LOT_NUMBER
  , ins.ARRIVAL_DATE 
  , ins.TRANSACTION_NO
  , ins.DATE_RECEIVED 
  , 'UPDATE' AS ACTION
  , 1 AS action_number
  , ins.CSV_COMMENT
  , ins.OPTIONAL_1
  , ins.OPTIONAL_2
  , ins.OPTIONAL_3
  , ins.OPTIONAL_4
  , ins.OPTIONAL_5
  , ins.OPTIONAL_6
  , ins.OPTIONAL_7
  , ins.OPTIONAL_8
  , ins.OPTIONAL_9 
  , ins.OPTIONAL_10 
  , ins.OPTIONAL_11
  , ins.OPTIONAL_12
  , ins.OPTIONAL_13
  , ins.OPTIONAL_14 
  , ins.OPTIONAL_15
  , ins.OPTIONAL_16
  , ins.OPTIONAL_17
  , ins.OPTIONAL_18
  , ins.OPTIONAL_19
  , ins.OPTIONAL_20
  , ins.OPTIONAL_21
  , ins.OPTIONAL_22
  , ins.OPTIONAL_23
  , ins.OPTIONAL_24
  , ins.OPTIONAL_25
  , ins.OPTIONAL_26
  , ins.OPTIONAL_27
  , ins.OPTIONAL_28
  , ins.OPTIONAL_29
  , ins.OPTIONAL_30
  , ins.mandant
  , ins.prueflos
  , ins.aufnr
  , ins.objnr
  , ins.cuobj_bm
  , ins.matnr
  
FROM e2_all_inserts ins

INNER JOIN sqa.europe2_upcoming_batches_history his 
  ON ins.TENANT_ID = his.TENANT_ID 
  AND ins.MFG_LOT_NUMBER = his.MFG_LOT_NUMBER 
  AND ins.PRODUCT_ID = his.PRODUCT_ID 
  
  
INNER JOIN (
              SELECT TENANT_ID, MFG_LOT_NUMBER, PRODUCT_ID, inserted_at, max(action_number) AS max_action_number
              FROM sqa.europe2_upcoming_batches_history
              GROUP BY TENANT_ID, MFG_LOT_NUMBER, PRODUCT_ID, inserted_at
            ) max_actions  ON his.TENANT_ID = max_actions.TENANT_ID
                          AND his.MFG_LOT_NUMBER = max_actions.MFG_LOT_NUMBER
                          AND his.PRODUCT_ID = max_actions.PRODUCT_ID
                          AND his.inserted_at = max_actions.inserted_at
                          AND his.action_number = max_actions.max_action_number

INNER JOIN (
              SELECT TENANT_ID, MFG_LOT_NUMBER, PRODUCT_ID, max(INSERTED_AT) AS last_update_date
              FROM sqa.europe2_upcoming_batches_history
              GROUP BY TENANT_ID, MFG_LOT_NUMBER, PRODUCT_ID
            ) latest_updates ON his.TENANT_ID = latest_updates.TENANT_ID
                            AND his.MFG_LOT_NUMBER = latest_updates.MFG_LOT_NUMBER
                            AND his.PRODUCT_ID = latest_updates.PRODUCT_ID
                            AND his.inserted_at = latest_updates.last_update_date
      
WHERE ins.DATE_RECEIVED <> his.DATE_RECEIVED
  OR ins.OPTIONAL_1 <> his.OPTIONAL_1
  OR ins.OPTIONAL_2 <> his.OPTIONAL_2
  OR ins.OPTIONAL_3 <> his.OPTIONAL_3
  OR ins.OPTIONAL_4 <> his.OPTIONAL_4
  OR ins.OPTIONAL_5 <> his.OPTIONAL_5
  OR ins.OPTIONAL_6 <> his.OPTIONAL_6
  OR ins.OPTIONAL_7 <> his.OPTIONAL_7
  OR ins.OPTIONAL_18 <> his.OPTIONAL_18
  OR ins.OPTIONAL_20 <> his.OPTIONAL_20
  
"""            

# COMMAND ----------

df_updates = spark.sql(updates_query)
df_updates.createOrReplaceTempView('e2_updates')
spark.catalog.cacheTable('e2_updates')

# COMMAND ----------

actions_query = """
SELECT actions.*
FROM (

    SELECT
        ins.TENANT_ID
      , ins.BATCH_NO 
      , ins.PRODUCT_ID 
      , ins.PRODUCT_DESCRIPTION 
      , ins.MFG_LOT_NUMBER
      , ins.ARRIVAL_DATE 
      , ins.TRANSACTION_NO
      , ins.DATE_RECEIVED 
      , 'INSERT' AS ACTION
      , 2 AS ACTION_NUMBER
      , ins.CSV_COMMENT
      , ins.OPTIONAL_1
      , ins.OPTIONAL_2
      , ins.OPTIONAL_3
      , ins.OPTIONAL_4
      , ins.OPTIONAL_5
      , ins.OPTIONAL_6
      , ins.OPTIONAL_7
      , ins.OPTIONAL_8
      , ins.OPTIONAL_9 
      , ins.OPTIONAL_10 
      , ins.OPTIONAL_11
      , ins.OPTIONAL_12
      , ins.OPTIONAL_13
      , ins.OPTIONAL_14 
      , ins.OPTIONAL_15
      , ins.OPTIONAL_16
      , ins.OPTIONAL_17
      , ins.OPTIONAL_18
      , ins.OPTIONAL_19
      , ins.OPTIONAL_20
      , ins.OPTIONAL_21
      , ins.OPTIONAL_22
      , ins.OPTIONAL_23
      , ins.OPTIONAL_24
      , ins.OPTIONAL_25
      , ins.OPTIONAL_26
      , ins.OPTIONAL_27
      , ins.OPTIONAL_28
      , ins.OPTIONAL_29
      , ins.OPTIONAL_30
      , ins.mandant
      , ins.prueflos
      , ins.aufnr
      , ins.objnr
      , ins.cuobj_bm
      , ins.matnr
      
      
    FROM e2_all_inserts ins

  UNION ALL
  
    SELECT
        ins.TENANT_ID
      , ins.BATCH_NO 
      , ins.PRODUCT_ID 
      , ins.PRODUCT_DESCRIPTION 
      , ins.MFG_LOT_NUMBER
      , ins.ARRIVAL_DATE 
      , ins.TRANSACTION_NO
      , ins.DATE_RECEIVED 
      , 'END-BRR' AS ACTION
      , 3 AS ACTION_NUMBER
      , ins.CSV_COMMENT
      , ins.OPTIONAL_1
      , ins.OPTIONAL_2
      , ins.OPTIONAL_3
      , ins.OPTIONAL_4
      , ins.OPTIONAL_5
      , ins.OPTIONAL_6
      , ins.OPTIONAL_7
      , ins.end_brr_username as OPTIONAL_8 
      , ins.OPTIONAL_9 
      , ins.OPTIONAL_10 
      , ins.OPTIONAL_11
      , ins.OPTIONAL_12
      , ins.OPTIONAL_13
      , ins.OPTIONAL_14 
      , ins.OPTIONAL_15
      , ins.OPTIONAL_16
      , ins.OPTIONAL_17
      , ins.OPTIONAL_18
      , ins.OPTIONAL_19
      , ins.OPTIONAL_20
      , ins.OPTIONAL_21
      , ins.OPTIONAL_22
      , ins.OPTIONAL_23
      , ins.end_brr_date as OPTIONAL_24
      , ins.end_brr_hour as OPTIONAL_25
      , ins.OPTIONAL_26
      , ins.OPTIONAL_27
      , ins.OPTIONAL_28
      , ins.OPTIONAL_29
      , ins.OPTIONAL_30
      , ins.mandant
      , ins.prueflos
      , ins.aufnr
      , ins.objnr
      , ins.cuobj_bm
      , ins.matnr
      
    FROM e2_all_inserts ins
    
    WHERE ins.end_brr_action = 'TRUE'
    AND ins.aufnr <> ' ' 

  UNION ALL
  
    SELECT
        ins.TENANT_ID
      , ins.BATCH_NO 
      , ins.PRODUCT_ID 
      , ins.PRODUCT_DESCRIPTION 
      , ins.MFG_LOT_NUMBER
      , ins.ARRIVAL_DATE 
      , ins.TRANSACTION_NO
      , ins.DATE_RECEIVED 
      , 'END-QA-BRR' AS ACTION
      , 4 AS ACTION_NUMBER
      , ins.CSV_COMMENT
      , ins.OPTIONAL_1
      , ins.OPTIONAL_2
      , ins.OPTIONAL_3
      , ins.OPTIONAL_4
      , ins.OPTIONAL_5
      , ins.OPTIONAL_6
      , ins.OPTIONAL_7
      , ins.end_qa_brr_username as OPTIONAL_8 
      , ins.OPTIONAL_9 
      , ins.OPTIONAL_10 
      , ins.OPTIONAL_11
      , ins.OPTIONAL_12
      , ins.OPTIONAL_13
      , ins.OPTIONAL_14 
      , ins.OPTIONAL_15
      , ins.OPTIONAL_16
      , ins.OPTIONAL_17
      , ins.OPTIONAL_18
      , ins.OPTIONAL_19
      , ins.OPTIONAL_20
      , ins.OPTIONAL_21
      , ins.OPTIONAL_22
      , ins.OPTIONAL_23
      , ins.end_qa_brr_date as OPTIONAL_24
      , ins.end_qa_brr_hour as OPTIONAL_25
      , ins.OPTIONAL_26
      , ins.OPTIONAL_27
      , ins.OPTIONAL_28
      , ins.OPTIONAL_29
      , ins.OPTIONAL_30
      , ins.mandant
      , ins.prueflos
      , ins.aufnr
      , ins.objnr
      
      , ins.cuobj_bm
      , ins.matnr
      
    FROM e2_all_inserts ins
    WHERE ins.end_qa_brr_action = 'TRUE'
    AND ins.aufnr <> ' '
    
  UNION ALL
  
    SELECT
        ins.TENANT_ID
      , ins.BATCH_NO 
      , ins.PRODUCT_ID 
      , ins.PRODUCT_DESCRIPTION 
      , ins.MFG_LOT_NUMBER
      , ins.ARRIVAL_DATE 
      , ins.TRANSACTION_NO
      , ins.DATE_RECEIVED 
      , 'END-QA-BRR2' AS ACTION
      , 5 AS ACTION_NUMBER
      , ins.CSV_COMMENT
      , ins.OPTIONAL_1
      , ins.OPTIONAL_2
      , ins.OPTIONAL_3
      , ins.OPTIONAL_4
      , ins.OPTIONAL_5
      , ins.OPTIONAL_6
      , ins.OPTIONAL_7
      , ins.end_qa_brr_username as OPTIONAL_8 
      , ins.OPTIONAL_9 
      , ins.OPTIONAL_10 
      , ins.OPTIONAL_11
      , ins.OPTIONAL_12
      , ins.OPTIONAL_13
      , ins.OPTIONAL_14 
      , ins.OPTIONAL_15
      , ins.OPTIONAL_16
      , ins.OPTIONAL_17
      , ins.OPTIONAL_18
      , ins.OPTIONAL_19
      , ins.OPTIONAL_20
      , ins.OPTIONAL_21
      , ins.OPTIONAL_22
      , ins.OPTIONAL_23
      , ins.end_qa_brr2_date as OPTIONAL_24
      , ins.end_qa_brr2_hour as OPTIONAL_25
      , ins.OPTIONAL_26
      , ins.OPTIONAL_27
      , ins.OPTIONAL_28
      , ins.OPTIONAL_29
      , ins.OPTIONAL_30
      , ins.mandant
      , ins.prueflos
      , ins.aufnr
      , ins.objnr
      
      , ins.cuobj_bm
      , ins.matnr
      
    FROM e2_all_inserts ins
    WHERE ins.end_qa_brr2_action = 'TRUE'
    AND ins.aufnr <> ' '

  UNION ALL
  
    SELECT
      ins.TENANT_ID
    , ins.BATCH_NO 
    , ins.PRODUCT_ID 
    , ins.PRODUCT_DESCRIPTION 
    , ins.MFG_LOT_NUMBER
    , ins.ARRIVAL_DATE 
    , ins.TRANSACTION_NO
    , ins.DATE_RECEIVED 
    , 'PASS' AS ACTION
    , 7 AS ACTION_NUMBER
    , ins.CSV_COMMENT
    , ins.OPTIONAL_1
    , ins.OPTIONAL_2
    , ins.OPTIONAL_3
    , ins.OPTIONAL_4
    , ins.OPTIONAL_5
    , ins.OPTIONAL_6
    , ins.OPTIONAL_7
    , ins.pass_username AS OPTIONAL_8
    , ins.OPTIONAL_9 
    , ins.OPTIONAL_10 
    , ins.OPTIONAL_11
    , ins.OPTIONAL_12
    , ins.OPTIONAL_13
    , ins.OPTIONAL_14 
    , ins.OPTIONAL_15
    , ins.OPTIONAL_16
    , ins.OPTIONAL_17
    , ins.OPTIONAL_18
    , ins.OPTIONAL_19
    , ins.OPTIONAL_20
    , ins.OPTIONAL_21
    , ins.OPTIONAL_22
    , ins.OPTIONAL_23
    , CASE
      WHEN ins.pre_pass_action = 'TRUE' THEN ins.pass_date
      ELSE ins.pre_pass_date
      END as OPTIONAL_24
    , CASE
      WHEN ins.pre_pass_action = 'TRUE' THEN ins.pass_hour
      ELSE ins.pre_pass_hour
      END as OPTIONAL_25
    , ins.OPTIONAL_26
    , ins.OPTIONAL_27
    , ins.OPTIONAL_28
    , ins.OPTIONAL_29
    , ins.OPTIONAL_30
    , ins.mandant
    , ins.prueflos
    , ins.aufnr
    , ins.objnr
    , ins.cuobj_bm
    , ins.matnr

    FROM e2_all_inserts ins
    WHERE ins.pass_action = 'TRUE'
    
    UNION ALL
  
    SELECT
        ins.TENANT_ID
      , ins.BATCH_NO 
      , ins.PRODUCT_ID 
      , ins.PRODUCT_DESCRIPTION 
      , ins.MFG_LOT_NUMBER
      , ins.ARRIVAL_DATE 
      , ins.TRANSACTION_NO
      , ins.DATE_RECEIVED 
      , 'PRE-PASS' AS ACTION
      , 6 AS ACTION_NUMBER
      , ins.CSV_COMMENT
      , ins.OPTIONAL_1
      , ins.OPTIONAL_2
      , ins.OPTIONAL_3
      , ins.OPTIONAL_4
      , ins.OPTIONAL_5
      , ins.OPTIONAL_6
      , ins.OPTIONAL_7
      , ins.pass_username as OPTIONAL_8 
      , ins.OPTIONAL_9 
      , ins.OPTIONAL_10 
      , ins.OPTIONAL_11
      , ins.OPTIONAL_12
      , ins.OPTIONAL_13
      , ins.OPTIONAL_14 
      , ins.OPTIONAL_15
      , ins.OPTIONAL_16
      , ins.OPTIONAL_17
      , ins.OPTIONAL_18
      , ins.OPTIONAL_19
      , ins.OPTIONAL_20
      , ins.OPTIONAL_21
      , ins.OPTIONAL_22
      , ins.OPTIONAL_23
      , ins.pre_pass_date as OPTIONAL_24
      , ins.pre_pass_hour as OPTIONAL_25
      , ins.OPTIONAL_26
      , ins.OPTIONAL_27
      , ins.OPTIONAL_28
      , ins.OPTIONAL_29
      , ins.OPTIONAL_30
      , ins.mandant
      , ins.prueflos
      , ins.aufnr
      , ins.objnr
      , ins.cuobj_bm
      , ins.matnr
      
    FROM e2_all_inserts ins
    
    WHERE ins.pre_pass_action = 'TRUE'
    AND ins.aufnr <> ' '
    
) actions


LEFT JOIN sqa.europe2_upcoming_batches_history his
ON actions.TENANT_ID = his.TENANT_ID AND actions.MFG_LOT_NUMBER = his.MFG_LOT_NUMBER 
                                     AND actions.PRODUCT_ID = his.PRODUCT_ID 
                                     AND actions.ACTION = his.ACTION
WHERE his.MFG_LOT_NUMBER IS NULL  

"""


# COMMAND ----------

df_actions = spark.sql(actions_query)
df_actions.createOrReplaceTempView('e2_actions')
spark.catalog.cacheTable('e2_actions')

# COMMAND ----------

union_all_query = """
Select * FROM e2_actions 
UNION ALL
Select * FROM e2_updates
"""
all_results_df = spark.sql(union_all_query)

# COMMAND ----------

dbutils.notebook.exit("exit")