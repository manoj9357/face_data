# Databricks notebook source
import requests
import smtplib
import pandas as pd
from datetime import datetime, timedelta
import time

# Databricks domain, token
databricks_instance = "https://<databricks-instance>"
token = "<your-token>"

# Get current time and time 8 hours ago
now = datetime.now()
eight_hours_ago = now - timedelta(hours=8)

# Get all job runs from Databricks Jobs API
response = requests.get(
    f"{databricks_instance}/api/2.0/jobs/runs/list",
    headers={'Authorization': f'Bearer {token}'}
)
all_runs = response.json()["runs"]

# Filter runs to get only those started in the last 8 hours
recent_runs = [run for run in all_runs if datetime.fromtimestamp(run["start_time"]/1000) > eight_hours_ago]

# Create a new Excel writer object
writer = pd.ExcelWriter('databricks_report.xlsx', engine='openpyxl')

# Loop through the recent runs
for run in recent_runs:
    # Get detailed information about the run
    while True:
        response = requests.get(
            f"{databricks_instance}/api/2.0/jobs/runs/get?run_id={run['run_id']}",
            headers={'Authorization': f'Bearer {token}'}
        )
        if response.status_code == 429:  # Rate limit exceeded
            time.sleep(10)  # Wait for 10 seconds before retrying
            continue
        else:
            run_details = response.json()
            break

    # Create a DataFrame with the run details
    df = pd.DataFrame({
        'Job ID': [run_details['job_id']],
        'Run ID': [run_details['run_id']],
        'Status': [run_details['state']['life_cycle_state']],
        'Start Time': [datetime.fromtimestamp(run_details['start_time']/1000)],
        'End Time': [datetime.fromtimestamp(run_details['end_time']/1000)],
        'Output': [run_details['state']['result_state']],
        'Error': [run_details['state']['state_message']]
    })

    # Write the DataFrame to a new sheet in the Excel file
    df.to_excel(writer, sheet_name=f"Job {run_details['job_id']} Run {run_details['run_id']}", index=False)

# Save the Excel file
writer.save()


# COMMAND ----------

import requests
import smtplib
import pandas as pd
from datetime import datetime, timedelta
import time
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

# Databricks domain, token
databricks_instance = "https://<databricks-instance>"
token = "<your-token>"

# Get current time and time 8 hours ago
now = datetime.now()
eight_hours_ago = now - timedelta(hours=8)

# Get all job runs from Databricks Jobs API
response = requests.get(
    f"{databricks_instance}/api/2.0/jobs/runs/list",
    headers={'Authorization': f'Bearer {token}'}
)
all_runs = response.json()["runs"]

# Filter runs to get only those started in the last 8 hours
recent_runs = [run for run in all_runs if datetime.fromtimestamp(run["start_time"]/1000) > eight_hours_ago]

# Create a new Excel writer object
filename = f"databricks_report_{eight_hours_ago.strftime('%Y%m%d%H%M%S')}_{now.strftime('%Y%m%d%H%M%S')}.xlsx"
writer = pd.ExcelWriter(filename, engine='openpyxl')

# Loop through the recent runs
for run in recent_runs:
    # Get detailed information about the run
    while True:
        response = requests.get(
            f"{databricks_instance}/api/2.0/jobs/runs/get?run_id={run['run_id']}",
            headers={'Authorization': f'Bearer {token}'}
        )
        if response.status_code == 429:  # Rate limit exceeded
            time.sleep(10)  # Wait for 10 seconds before retrying
            continue
        else:
            run_details = response.json()
            break

    # Create a DataFrame with the run details
    df = pd.DataFrame({
        'Job ID': [run_details['job_id']],
        'Run ID': [run_details['run_id']],
        'Status': [run_details['state']['life_cycle_state']],
        'Start Time': [datetime.fromtimestamp(run_details['start_time']/1000)],
        'End Time': [datetime.fromtimestamp(run_details['end_time']/1000)],
        'Output': [run_details['state']['result_state']],
        'Error': [run_details['state']['state_message']]
    })

    # Write the DataFrame to a new sheet in the Excel file
    df.to_excel(writer, sheet_name=f"Job {run_details['job_id']} Run {run_details['run_id']}", index=False)

# Save the Excel file
writer.save()

# Set up email parameters
smtp_server = "smtp.gmail.com"
smtp_port = 587
from_email = "<your-gmail-address>"
to_email = "<recipient-email-address>"
password = "<your-gmail-password>"

# Create email message
msg = MIMEMultipart()
msg["From"] = from_email
msg["To"] = to_email
msg["Subject"] = "Databricks Job Status Update"

# Attach the Excel file
part = MIMEBase('application', "octet-stream")
part.set_payload(open(filename, "rb").read())
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment', filename=filename)  # use your custom filename
msg.attach(part)

# Send the email
server = smtplib.SMTP(smtp_server, smtp_port)
server.starttls()
server.login(from_email, password)
text = msg.as_string()
server.sendmail(from_email, to_email, text)
server.quit()


# COMMAND ----------

SMTP Server Name: smtp.office365.com
SMTP Port Number: 587
SMTP Encryption Method: STARTTLS123
Please replace <your-outlook-email> with your Outlook email address and <your-outlook-password> with your Outlook password in the script.