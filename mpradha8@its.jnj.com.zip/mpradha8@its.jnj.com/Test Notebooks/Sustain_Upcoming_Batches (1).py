# Databricks notebook source
# MAGIC %run /Workspace/Shared/SQA/Packages/sqif_Framework

# COMMAND ----------

# UPDATED WITH NEW QUERY AND WORKS

pasx_inserts_query = """
SELECT DISTINCT 
              right(mseg.matnr, 6) AS PRODUCT_ID
            , mseg.werks AS TENANT_ID
            , mseg.charg AS MFG_LOT_NUMBER
            , CONCAT(right(mseg.matnr, 6), '-', mseg.charg) AS BATCH_NO
            , mch.ersda as ARRIVAL_DATE
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 THEN date_format(mo.actual_start_ts, 'yyyyMMdd')
              ELSE mch.lwedt 
              END as DATE_RECEIVED
            , 'DEFAULT' AS TRANSACTION_NO
            , '' AS CSV_COMMENT
            , makt.maktx as PRODUCT_DESCRIPTION
            , mseg.matnr AS MATERIAL_ID
            , mseg.aufnr AS PROCESS_ORDER
            , mara.mtart as PRODUCT_TYPE
            , right(mseg.aufnr, 6) AS TRIMMED_PROCESS_ORDER
            , site.tenant_sid AS TENANT_SID
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt = 'Started' and mseg.bwart not in ('261', '262') THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt <> 'Started' THEN 'DONT INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 3 and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart <> 101 THEN 'DONT INSERT'
              WHEN mseg.bwart = 101 THEN 'INSERT'
              ELSE 'DONT INSERT' 
              END AS ACTION
            , 2 AS ACTION_NUMBER
            , current_timestamp() AS INSERTED_AT
            , '' AS OPTIONAL_1
            , '' AS OPTIONAL_2
            , '' AS OPTIONAL_3
            , '' AS OPTIONAL_4
            , '' AS OPTIONAL_5
            , '' AS OPTIONAL_6
            , '' AS OPTIONAL_7
            , '' AS OPTIONAL_8
            , right(mseg.aufnr, 6) AS OPTIONAL_9
            , '' AS OPTIONAL_10
            , '' AS OPTIONAL_11
            , '' AS OPTIONAL_12
            , '' AS OPTIONAL_13
            , t001w.name1 AS OPTIONAL_14 
            , mseg.charg AS OPTIONAL_15 
            , mara.mtart AS OPTIONAL_16 
            , '' AS OPTIONAL_17
            , CASE 
                WHEN marc.webaz = '0' THEN ''
                ELSE marc.webaz
              END AS OPTIONAL_18
            , '' AS OPTIONAL_19
            , '' AS OPTIONAL_20
            , '' AS OPTIONAL_21
            , CASE
               WHEN mo.id is null THEN ''
               WHEN mes_status.aufnr is null THEN ''
               ELSE mo.id 
              END AS OPTIONAL_22
            , '' AS OPTIONAL_23
            , mkpf.cpudt AS OPTIONAL_24
            , mkpf.cputm AS OPTIONAL_25
            , 'CET' AS OPTIONAL_26
            , '' AS OPTIONAL_27
            , '' AS OPTIONAL_28
            , '' AS OPTIONAL_29
            , '' AS OPTIONAL_30
FROM cdl_prod_l0_sustain.mseg mseg
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON mseg.matnr = mch.matnr AND mseg.charg = mch.charg 
INNER JOIN cdl_prod_l0_sustain.vnd_mara mara ON mara.matnr = mseg.matnr
INNER JOIN cdl_prod_l0_sustain.vnd_makt makt ON mseg.matnr = makt.matnr 
INNER JOIN sqa.sustain_sites site ON mseg.werks = site.plant  
INNER JOIN cdl_prod_l0_sustain.vnd_t001w t001w ON mseg.werks = t001w.werks
INNER JOIN cdl_prod_l0_sustain.vnd_marc marc ON mseg.werks = marc.werks AND mseg.matnr = marc.matnr
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo ON mo.id = right(mseg.aufnr, 6) AND mo.tenant_sid = site.tenant_sid --** LEFT JOIN
LEFT JOIN (
    SELECT distinct 
           flo.order_id, 
           flo.production_unit_id,
           pu.group_id
    FROM cdl_make_prod_pasx.shop_floor_order flo
    INNER JOIN SQA.SUSTAIN_PRODUCTION_UNITS pu on flo.production_unit_id = pu.production_unit_id
    ) so on mo.id = so.order_id
INNER JOIN sqa.config_sustain_products products  ON mara.mtart = products.product_type 
                                      AND mseg.werks = products.plant 
                                      AND (to_timestamp(mch.ersda, 'yyyyMMdd') >= to_timestamp(products.created_date))
  
LEFT JOIN (
            SELECT mseg1.werks, mseg1.charg, mseg1.matnr, mseg1.aufnr, mseg1.ebeln 
            FROM cdl_prod_l0_sustain.mseg mseg1
            WHERE mseg1.bwart in (321, 350)
          ) released on mseg.charg = released.charg 
                    and mseg.werks = released.werks 
                    and mseg.matnr = released.matnr 
                    and mseg.aufnr = released.aufnr
            
-- ONLY GET THOSE WITH a MES% STATUS
INNER JOIN (
            SELECT distinct aufk.aufnr
            FROM cdl_prod_l0_sustain.vnd_aufk aufk
            INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
            INNER JOIN cdl_prod_l0_sustain.vnd_tj30t user_stat on jest.stat = user_stat.estat
            WHERE jest.inact <> 'X'
            AND user_stat.spras = 'E'
            AND user_stat.txt04 LIKE 'MES%' 
) mes_status ON mes_status.aufnr = mseg.aufnr

-- Add transactional datetime
LEFT JOIN cdl_prod_l0_sustain.mkpf mkpf ON mkpf.MBLNR = mseg.MBLNR

WHERE makt.spras = 'E' 
AND released.charg IS NULL
--** ONLY GET THOSE WITH a MES% STATUS OR PASX MO
AND (mo.id is not null OR mes_status.aufnr is not null)
"""

# COMMAND ----------

df=spark.sql(pasx_inserts_query)
df.createOrReplaceTempView("pasx_inserts_query")
df.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pasx_inserts_query where PRODUCT_ID like('%307956%') and BATCH_NO like '%386579%'

# COMMAND ----------



# COMMAND ----------

# UPDATED WITH NEW QUERY AND WORKS

pasx_inserts_query = """
SELECT DISTINCT 
              right(mseg.matnr, 6) AS PRODUCT_ID
            , mseg.werks AS TENANT_ID
            , mseg.charg AS MFG_LOT_NUMBER
            , CONCAT(right(mseg.matnr, 6), '-', mseg.charg) AS BATCH_NO
            , mch.ersda as ARRIVAL_DATE
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 THEN date_format(mo.actual_start_ts, 'yyyyMMdd')
              ELSE mch.lwedt 
              END as DATE_RECEIVED
            , 'DEFAULT' AS TRANSACTION_NO
            , '' AS CSV_COMMENT
            , makt.maktx as PRODUCT_DESCRIPTION
            , mseg.matnr AS MATERIAL_ID
            , mseg.aufnr AS PROCESS_ORDER
            , mara.mtart as PRODUCT_TYPE
            , right(mseg.aufnr, 6) AS TRIMMED_PROCESS_ORDER
            , site.tenant_sid AS TENANT_SID
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt = 'Started' and mseg.bwart not in ('261', '262') THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt <> 'Started' THEN 'DONT INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 3 and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart <> 101 THEN 'DONT INSERT'
              WHEN mseg.bwart = 101 THEN 'INSERT'
              ELSE 'DONT INSERT' 
              END AS ACTION
            , 2 AS ACTION_NUMBER
            , current_timestamp() AS INSERTED_AT
            , '' AS OPTIONAL_1
            , '' AS OPTIONAL_2
            , '' AS OPTIONAL_3
            , '' AS OPTIONAL_4
            , '' AS OPTIONAL_5
            , '' AS OPTIONAL_6
            , '' AS OPTIONAL_7
            , '' AS OPTIONAL_8
            , right(mseg.aufnr, 6) AS OPTIONAL_9
            , '' AS OPTIONAL_10
            , '' AS OPTIONAL_11
            , '' AS OPTIONAL_12
            , '' AS OPTIONAL_13
            , t001w.name1 AS OPTIONAL_14 
            , mseg.charg AS OPTIONAL_15 
            , mara.mtart AS OPTIONAL_16 
            , '' AS OPTIONAL_17
            , CASE 
                WHEN marc.webaz = '0' THEN ''
                ELSE marc.webaz
              END AS OPTIONAL_18
            , '' AS OPTIONAL_19
            , '' AS OPTIONAL_20
            , '' AS OPTIONAL_21
            , CASE
               WHEN mo.id is null THEN ''
               WHEN mes_status.aufnr is null THEN ''
               ELSE mo.id 
              END AS OPTIONAL_22
            , '' AS OPTIONAL_23
            , mkpf.cpudt AS OPTIONAL_24
            , mkpf.cputm AS OPTIONAL_25
            , 'CET' AS OPTIONAL_26
            , '' AS OPTIONAL_27
            , '' AS OPTIONAL_28
            , '' AS OPTIONAL_29
            , '' AS OPTIONAL_30
FROM cdl_prod_l0_sustain.mseg mseg
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON mseg.matnr = mch.matnr AND mseg.charg = mch.charg 
INNER JOIN cdl_prod_l0_sustain.vnd_mara mara ON mara.matnr = mseg.matnr
INNER JOIN cdl_prod_l0_sustain.vnd_makt makt ON mseg.matnr = makt.matnr 
INNER JOIN sqa.sustain_sites site ON mseg.werks = site.plant  
INNER JOIN cdl_prod_l0_sustain.vnd_t001w t001w ON mseg.werks = t001w.werks
INNER JOIN cdl_prod_l0_sustain.vnd_marc marc ON mseg.werks = marc.werks AND mseg.matnr = marc.matnr
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo ON mo.id = right(mseg.aufnr, 6) AND mo.tenant_sid = site.tenant_sid --** LEFT JOIN
LEFT JOIN (
    SELECT distinct 
           flo.order_id, 
           flo.production_unit_id,
           pu.group_id
    FROM cdl_make_prod_pasx.shop_floor_order flo
    INNER JOIN SQA.SUSTAIN_PRODUCTION_UNITS pu on flo.production_unit_id = pu.production_unit_id
    ) so on mo.id = so.order_id
INNER JOIN sqa.config_sustain_products products  ON mara.mtart = products.product_type 
                                      AND mseg.werks = products.plant 
                                      AND (to_timestamp(mch.ersda, 'yyyyMMdd') >= to_timestamp(products.created_date))
  
LEFT JOIN (
            SELECT mseg1.werks, mseg1.charg, mseg1.matnr, mseg1.aufnr, mseg1.ebeln 
            FROM cdl_prod_l0_sustain.mseg mseg1
            WHERE mseg1.bwart in (321, 350)
          ) released on mseg.charg = released.charg 
                    and mseg.werks = released.werks 
                    and mseg.matnr = released.matnr 
                    and mseg.aufnr = released.aufnr
            
-- ONLY GET THOSE WITH a MES% STATUS
INNER JOIN (
            SELECT distinct aufk.aufnr
            FROM cdl_prod_l0_sustain.vnd_aufk aufk
            INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
            INNER JOIN cdl_prod_l0_sustain.vnd_tj30t user_stat on jest.stat = user_stat.estat
            WHERE jest.inact <> 'X'
            AND user_stat.spras = 'E'
            AND user_stat.txt04 LIKE 'MES%' 
) mes_status ON mes_status.aufnr = mseg.aufnr

-- Add transactional datetime
LEFT JOIN cdl_prod_l0_sustain.mkpf mkpf ON mkpf.MBLNR = mseg.MBLNR

WHERE makt.spras = 'E' 
AND released.charg IS NULL
--** ONLY GET THOSE WITH a MES% STATUS OR PASX MO
AND (mo.id is not null OR mes_status.aufnr is not null)
"""

# COMMAND ----------

df=

# COMMAND ----------

pasx_end_brr_query = """
SELECT DISTINCT rs.PRODUCT_ID
              , rs.TENANT_ID
              , rs.MFG_LOT_NUMBER
              , rs.BATCH_NO
              , rs.ARRIVAL_DATE
              , mch.lwedt as DATE_RECEIVED
              , rs.TRANSACTION_NO
              , rs.CSV_COMMENT
              , rs.PRODUCT_DESCRIPTION
              , rs.MATERIAL_ID
              , rs.PROCESS_ORDER
              , rs.PRODUCT_TYPE
              , rs.TRIMMED_PROCESS_ORDER
              , rs.TENANT_SID
              , CASE
                WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is not null) THEN 'END-BRR'
                WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is null) THEN 'NOT END-BRR'
                ELSE 'END-BRR' 
                END AS ACTION
              , 3 AS ACTION_NUMBER
              , current_timestamp() AS INSERTED_AT 
              , '' AS OPTIONAL_1
              , '' AS OPTIONAL_2
              , '' AS OPTIONAL_3
              , '' AS OPTIONAL_4
              , '' AS OPTIONAL_5
              , '' AS OPTIONAL_6
              , '' AS OPTIONAL_7
              , '' AS OPTIONAL_8
              , rs.OPTIONAL_9 AS OPTIONAL_9
              , '' AS OPTIONAL_10
              , nvl(sig.type_id, '') AS OPTIONAL_11
              , '' AS OPTIONAL_12
              , '' AS OPTIONAL_13
              , rs.OPTIONAL_14 AS OPTIONAL_14 
              , rs.OPTIONAL_15 AS OPTIONAL_15 
              , rs.OPTIONAL_16 AS OPTIONAL_16 
              , '' AS OPTIONAL_17
              , rs.OPTIONAL_18 AS OPTIONAL_18 
              , '' AS OPTIONAL_19
              , '' AS OPTIONAL_20
              , '' AS OPTIONAL_21
              , rs.OPTIONAL_22 AS OPTIONAL_22
              , min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id) AS OPTIONAL_23
              , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'yyyyMMdd') as OPTIONAL_24
              , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'HHmmss') AS OPTIONAL_25
              , rs.OPTIONAL_26 AS OPTIONAL_26
              , '' AS OPTIONAL_27
              , '' AS OPTIONAL_28
              , '' AS OPTIONAL_29
              , '' AS OPTIONAL_30 
FROM ALL_INSERTS rs
INNER JOIN cdl_make_prod_pasx.brr brr ON rs.TRIMMED_PROCESS_ORDER = brr.order_id 
                           and rs.tenant_sid = brr.tenant_sid
INNER JOIN cdl_make_prod_pasx.brr_signature sig ON brr.brr_sid = sig.brr_sid 
                                     and brr.tenant_sid = sig.tenant_sid
LEFT JOIN (
    SELECT distinct order_id, 
           production_unit_id
    FROM cdl_make_prod_pasx.shop_floor_order
    WHERE production_unit_id in (select production_unit_id 
                                 from SQA.SUSTAIN_PRODUCTION_UNITS)
    ) so on rs.TRIMMED_PROCESS_ORDER = so.order_id
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch on rs.MATERIAL_ID = mch.matnr 
                               and rs.MFG_LOT_NUMBER = mch.charg 
where sig.type_id in ('BrrManufacturingApproval', 'BrrProductionApproval')
"""

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ALL_INSERTS where BATCH_NO like "%381510C%"

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select * from 
# MAGIC (select rs.TRIMMED_PROCESS_ORDER,so.production_unit_id from ALL_INSERTS rs left join (SELECT distinct order_id, 
# MAGIC            production_unit_id
# MAGIC     FROM cdl_make_prod_pasx.shop_floor_order a
# MAGIC     WHERE production_unit_id in (--'DISPENSE','BUFSPREP'
# MAGIC       select production_unit_id 
# MAGIC                                  from SQA.SUSTAIN_PRODUCTION_UNITS
# MAGIC                                  ) )so on rs.TRIMMED_PROCESS_ORDER = so.order_id) --a where  TRIMMED_PROCESS_ORDER='381510'
# MAGIC     

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT distinct order_id, 
# MAGIC            production_unit_id
# MAGIC     FROM cdl_make_prod_pasx.shop_floor_order where  production_unit_id in(select production_unit_id 
# MAGIC                                  from SQA.SUSTAIN_PRODUCTION_UNITS) --and order_id='381510'
# MAGIC                                  --is null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC                                  from SQA.SUSTAIN_PRODUCTION_UNITS where 

# COMMAND ----------

df=spark.sql(pasx_end_brr_query) #.filter(BATCH_NO=='38151a0C'))
display(df.filter(df["BATCH_NO"].like("%381510C%")))

# COMMAND ----------

pasx_end_qa_brr_query = """ 
SELECT DISTINCT rs.PRODUCT_ID
              , rs.TENANT_ID
              , rs.MFG_LOT_NUMBER
              , rs.BATCH_NO
              , rs.ARRIVAL_DATE
              , mch.lwedt as DATE_RECEIVED
              , rs.TRANSACTION_NO
              , rs.CSV_COMMENT
              , rs.PRODUCT_DESCRIPTION
              , rs.MATERIAL_ID
              , rs.PROCESS_ORDER
              , rs.PRODUCT_TYPE
              , rs.TRIMMED_PROCESS_ORDER
              , rs.TENANT_SID
              , CASE
                WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is not null) THEN 'END-QA-BRR'
                WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is null) THEN 'NOT END-QA-BRR'
                ELSE 'END-QA-BRR' 
                END AS ACTION
              , 4 AS ACTION_NUMBER
              , current_timestamp() AS INSERTED_AT 
              , '' AS OPTIONAL_1
              , '' AS OPTIONAL_2
              , '' AS OPTIONAL_3
              , '' AS OPTIONAL_4
              , '' AS OPTIONAL_5
              , '' AS OPTIONAL_6
              , '' AS OPTIONAL_7
              , '' AS OPTIONAL_8
              , rs.OPTIONAL_9 AS OPTIONAL_9
              , '' AS OPTIONAL_10
              , nvl(pasxbrr.OPTIONAL_11, '') AS OPTIONAL_11
              , nvl(sig.type_id, '') AS OPTIONAL_12
              , '' AS OPTIONAL_13
              , rs.OPTIONAL_14 AS OPTIONAL_14 
              , rs.OPTIONAL_15 AS OPTIONAL_15 
              , rs.OPTIONAL_16 AS OPTIONAL_16 
              , '' AS OPTIONAL_17
              , rs.OPTIONAL_18 AS OPTIONAL_18 
              , '' AS OPTIONAL_19
              , '' AS OPTIONAL_20
              , '' AS OPTIONAL_21
              , rs.OPTIONAL_22 AS OPTIONAL_22
              , min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id) AS OPTIONAL_23
              , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'yyyyMMdd') as OPTIONAL_24
              , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'HHmmss') AS OPTIONAL_25
              , rs.OPTIONAL_26 AS OPTIONAL_26
              , '' AS OPTIONAL_27
              , '' AS OPTIONAL_28
              , '' AS OPTIONAL_29
              , '' AS OPTIONAL_30
FROM ALL_INSERTS rs
LEFT JOIN PASX_END_BRR pasxbrr on rs.MFG_LOT_NUMBER = pasxbrr.MFG_LOT_NUMBER
INNER JOIN cdl_make_prod_pasx.brr brr ON rs.TRIMMED_PROCESS_ORDER = brr.order_id 
                           AND rs.tenant_sid = brr.tenant_sid 
INNER JOIN cdl_make_prod_pasx.brr_signature sig ON brr.brr_sid = sig.brr_sid 
                                     AND brr.tenant_sid = sig.tenant_sid 
LEFT JOIN (
    SELECT distinct order_id, 
           production_unit_id
    FROM cdl_make_prod_pasx.shop_floor_order
    WHERE production_unit_id in (select production_unit_id 
                                 from SQA.SUSTAIN_PRODUCTION_UNITS)
    ) so on rs.TRIMMED_PROCESS_ORDER = so.order_id
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON rs.MATERIAL_ID = mch.matnr 
                               AND rs.MFG_LOT_NUMBER = mch.charg 
WHERE sig.type_id = 'BrrQualityApproval' 
"""

# COMMAND ----------

# df=spark.sql(pasx_end_qa_brr_query) #.filter(BATCH_NO=='381510C'))
# display(df.filter(df["BATCH_NO"].like("%381510C%")))

# COMMAND ----------

pasx_pass_ar_query = """ 
SELECT DISTINCT rs.PRODUCT_ID
              , rs.TENANT_ID
              , rs.MFG_LOT_NUMBER
              , rs.BATCH_NO
              , rs.ARRIVAL_DATE
              , mch.lwedt as DATE_RECEIVED
              , rs.TRANSACTION_NO
              , rs.CSV_COMMENT
              , rs.PRODUCT_DESCRIPTION
              , rs.MATERIAL_ID
              , rs.PROCESS_ORDER
              , rs.PRODUCT_TYPE
              , rs.TRIMMED_PROCESS_ORDER
              , rs.TENANT_SID
              , 'PASS' AS ACTION
              , 7 AS ACTION_NUMBER
              , current_timestamp() AS INSERTED_AT 
              , '' AS OPTIONAL_1
              , '' AS OPTIONAL_2
              , '' AS OPTIONAL_3
              , '' AS OPTIONAL_4
              , '' AS OPTIONAL_5
              , '' AS OPTIONAL_6
              , '' AS OPTIONAL_7
              , '' AS OPTIONAL_8
              , rs.OPTIONAL_9 AS OPTIONAL_9
              , '' AS OPTIONAL_10
              , nvl(pasxbrr.OPTIONAL_11, '') AS OPTIONAL_11
              , nvl(pasxbrr.OPTIONAL_12, '') AS OPTIONAL_12
              , nvl(sig.type_id, '') AS OPTIONAL_13
              , rs.OPTIONAL_14 AS OPTIONAL_14 
              , rs.OPTIONAL_15 AS OPTIONAL_15 
              , rs.OPTIONAL_16 AS OPTIONAL_16 
              , '' AS OPTIONAL_17
              , rs.OPTIONAL_18 AS OPTIONAL_18 
              , '' AS OPTIONAL_19
              , '' AS OPTIONAL_20
              , '' AS OPTIONAL_21
              , rs.OPTIONAL_22 AS OPTIONAL_22
              , '' AS OPTIONAL_23
              , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'yyyyMMdd') as OPTIONAL_24
              , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'HHmmss') AS OPTIONAL_25
              , rs.OPTIONAL_26 AS OPTIONAL_26
              , '' AS OPTIONAL_27
              , '' AS OPTIONAL_28
              , '' AS OPTIONAL_29
              , '' AS OPTIONAL_30
FROM ALL_INSERTS rs
LEFT JOIN PASX_END_BRR pasxbrr on rs.MFG_LOT_NUMBER = pasxbrr.MFG_LOT_NUMBER
INNER JOIN cdl_make_prod_pasx.brr brr ON rs.TRIMMED_PROCESS_ORDER = brr.order_id 
                           AND rs.tenant_sid = brr.tenant_sid 
INNER JOIN cdl_make_prod_pasx.brr_signature sig ON brr.brr_sid = sig.brr_sid 
                                     AND brr.tenant_sid = sig.tenant_sid 
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON rs.MATERIAL_ID = mch.matnr 
                               AND rs.MFG_LOT_NUMBER = mch.charg 
WHERE sig.type_id = 'Automatically released by system'
and rs.TENANT_ID in ('LE01','CO01')
and rs.ARRIVAL_DATE > '20220501'
order by rs.ARRIVAL_DATE desc
"""

# COMMAND ----------

# df=spark.sql(pasx_pass_ar_query) #.filter(BATCH_NO=='381510C'))
# display(df.filter(df["BATCH_NO"].like("%381510C%")))

# COMMAND ----------

# UPDATED WITH NEW QUERY AND WORKS
pasx_pass_query = """
SELECT DISTINCT rs.PRODUCT_ID
              , rs.TENANT_ID
              , rs.MFG_LOT_NUMBER
              , rs.BATCH_NO
              , rs.ARRIVAL_DATE
              , mch.lwedt as DATE_RECEIVED
              , rs.TRANSACTION_NO
              , rs.CSV_COMMENT
              , rs.PRODUCT_DESCRIPTION
              , rs.MATERIAL_ID
              , rs.PROCESS_ORDER
              , rs.PRODUCT_TYPE
              , rs.TRIMMED_PROCESS_ORDER
              , rs.TENANT_SID
              , CASE
                WHEN rs.TENANT_ID = 'CO01' and passed.vcode = 'CREL' THEN 'PASS-CREL'
                WHEN rs.TENANT_ID = 'CO01' and passed.vcode = 'SHQR' THEN 'PASS-SHQR'
                WHEN rs.TENANT_ID = 'CO01' and nvl(sig.type_id, '') = 'BrrQualityApproval' and (so.production_unit_id is not null) and so.group_id in (1, 3) THEN 'PASS'
                WHEN rs.TENANT_ID = 'CO01' and nvl(sig.type_id, '') <> 'BrrQualityApproval' and (so.production_unit_id is not null) and so.group_id in (1, 3) THEN 'FAIL'
                WHEN passed.vcode in ('REL', 'REJ') and rs.TENANT_ID = 'CO01' and mseg.bwart = 321 THEN 'PASS'
                WHEN rs.TENANT_ID = 'LE01' and mseg.bwart = 321 THEN 'PASS'
                WHEN rs.TENANT_ID = 'MA01' and mseg.bwart in (321, 350) THEN 'PASS'
                ELSE 'FAIL'
                END as ACTION
              , CASE
                WHEN passed.vcode = 'SHQR' and rs.TENANT_ID = 'CO01' THEN 5
                WHEN passed.vcode = 'CREL' and rs.TENANT_ID = 'CO01' THEN 6
                ELSE 7
                END AS ACTION_NUMBER
              , current_timestamp() AS INSERTED_AT 
              , '' AS OPTIONAL_1
              , '' AS OPTIONAL_2
              , '' AS OPTIONAL_3
              , '' AS OPTIONAL_4
              , '' AS OPTIONAL_5
              , '' AS OPTIONAL_6
              , '' AS OPTIONAL_7
              , '' AS OPTIONAL_8
              , rs.OPTIONAL_9 AS OPTIONAL_9
              , '' AS OPTIONAL_10
              , nvl(pasxqabrr.OPTIONAL_11, '') AS OPTIONAL_11
              , nvl(pasxqabrr.OPTIONAL_12, '') AS OPTIONAL_12
              , CASE
                WHEN (sig.type_id is not null) and (so.production_unit_id is not null) THEN sig.type_id
                ELSE nvl(passed.vcode, '')
                END AS OPTIONAL_13
              , rs.OPTIONAL_14 AS OPTIONAL_14 
              , rs.OPTIONAL_15 AS OPTIONAL_15 
              , rs.OPTIONAL_16 AS OPTIONAL_16 
              , '' AS OPTIONAL_17
              , rs.OPTIONAL_18 AS OPTIONAL_18 
              , '' AS OPTIONAL_19
              , '' AS OPTIONAL_20
              , '' AS OPTIONAL_21
              , rs.OPTIONAL_22 AS OPTIONAL_22
              , nvl(sig.sign_date_ts, '') AS OPTIONAL_23
              , CASE
                WHEN passed.vcode = 'SHQR' and rs.TENANT_ID = 'CO01' THEN passed.vdatum
                WHEN passed.vcode = 'CREL' and rs.TENANT_ID = 'CO01' and pass_shqr.MFG_LOT_NUMBER is null THEN passed.vdatum
                WHEN passed.vcode = 'CREL' and rs.TENANT_ID = 'CO01' and pass_shqr.MFG_LOT_NUMBER is not null THEN passed.vaedatum
                WHEN pass_crel.MFG_LOT_NUMBER is null THEN passed.vdatum
                ELSE passed.vaedatum
                END AS OPTIONAL_24
              , CASE
                WHEN passed.vcode = 'SHQR' and rs.TENANT_ID = 'CO01' THEN passed.vezeiterf
                WHEN passed.vcode = 'CREL' and rs.TENANT_ID = 'CO01' and pass_shqr.MFG_LOT_NUMBER is null THEN passed.vezeiterf
                WHEN passed.vcode = 'CREL' and rs.TENANT_ID = 'CO01' and pass_shqr.MFG_LOT_NUMBER is not null THEN passed.vezeitaen
                WHEN pass_crel.MFG_LOT_NUMBER is null THEN passed.vezeiterf
                ELSE passed.vezeitaen
                END AS OPTIONAL_25
              , rs.OPTIONAL_26 AS OPTIONAL_26
              , '' AS OPTIONAL_27
              , '' AS OPTIONAL_28
              , '' AS OPTIONAL_29
              , '' AS OPTIONAL_30
FROM SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY rs
LEFT JOIN PASX_END_QA_BRR pasxqabrr on rs.MFG_LOT_NUMBER = pasxqabrr.MFG_LOT_NUMBER
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo ON mo.id = rs.TRIMMED_PROCESS_ORDER  --**LEFT JOIN
                                          AND mo.tenant_sid = rs.tenant_sid
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch  ON rs.MATERIAL_ID = mch.matnr 
                                AND rs.MFG_LOT_NUMBER = mch.charg
INNER JOIN cdl_prod_l0_sustain.mseg mseg ON mseg.charg = rs.MFG_LOT_NUMBER
                                and mseg.werks = rs.TENANT_ID
                                and mseg.matnr = rs.MATERIAL_ID
                                and mseg.umcha = rs.MFG_LOT_NUMBER
INNER JOIN cdl_prod_l0_sustain.vnd_aufk aufk ON aufk.aufnr = rs.PROCESS_ORDER
INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
INNER JOIN cdl_prod_l0_sustain.vnd_tj02t stat ON jest.stat = stat.istat

--** ONLY GET THOSE WITH a MES% STATUS
LEFT JOIN (
            SELECT distinct aufk.aufnr
            FROM cdl_prod_l0_sustain.vnd_aufk aufk
            INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
            INNER JOIN cdl_prod_l0_sustain.vnd_tj30t user_stat on jest.stat = user_stat.estat
            WHERE jest.inact <> 'X'
            AND user_stat.spras = 'E'
            AND user_stat.txt04 LIKE 'MES%' 
) mes_status ON mes_status.aufnr = rs.PROCESS_ORDER
--**

--AATE-20561
LEFT JOIN cdl_prod_l0_sustain.qals qals on qals.charg = mseg.charg 
                                       and qals.matnr = mseg.matnr
                                       and qals.aufnr = mseg.aufnr
                                       and qals.werk = mseg.werks
LEFT JOIN (
      SELECT qave.mandant, 
             qave.prueflos, 
             qave.vcode, 
             nvl(qave.vaename, qave.vname) as username,
             qave.vdatum,
             qave.vezeitaen,
             qave.vaedatum,
             qave.vezeiterf
      FROM cdl_prod_l0_sustain.qave qave 
      WHERE qave.kzart = 'L'
      AND qave.vcode <> ' '
   ) passed ON qals.mandant = passed.mandant 
           AND qals.prueflos = passed.prueflos

--AATE-23722 END-QA-BRR must be triggered in order to pass
LEFT JOIN (
    SELECT distinct 
          brr.order_id,
          sigb.brr_sid,
          sigb.tenant_sid,
          sigb.type_id,
          sigb.sign_date_ts
    FROM cdl_make_prod_pasx.brr brr
    LEFT JOIN (SELECT distinct brr_sid,
                           tenant_sid,
                           max(sign_date_ts) over (partition by brr_sid, tenant_sid) as sign_date_ts
               FROM cdl_make_prod_pasx.brr_signature
              ) sig_max on sig_max.brr_sid = brr.brr_sid 
                       and sig_max.tenant_sid = brr.tenant_sid
    INNER JOIN cdl_make_prod_pasx.brr_signature sigb on sigb.brr_sid = sig_max.brr_sid
                                               and sigb.tenant_sid = sig_max.tenant_sid
                                               and sigb.sign_date_ts = sig_max.sign_date_ts

  ) sig ON rs.TRIMMED_PROCESS_ORDER = sig.order_id 
       AND rs.tenant_sid = sig.tenant_sid
LEFT JOIN (
    SELECT distinct 
           flo.order_id, 
           flo.production_unit_id,
           pu.group_id
    FROM cdl_make_prod_pasx.shop_floor_order flo
    INNER JOIN SQA.SUSTAIN_PRODUCTION_UNITS pu on flo.production_unit_id = pu.production_unit_id
    ) so on rs.TRIMMED_PROCESS_ORDER = so.order_id

-- Transactional datetime interface
LEFT JOIN SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY pass_crel
  ON pass_crel.MFG_LOT_NUMBER = rs.MFG_LOT_NUMBER
  AND pass_crel.MATERIAL_ID =  rs.MATERIAL_ID
  AND pass_crel.ACTION = 'PASS-CREL'

LEFT JOIN SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY pass_shqr
  ON pass_shqr.MFG_LOT_NUMBER = rs.MFG_LOT_NUMBER
  AND pass_shqr.MATERIAL_ID =  rs.MATERIAL_ID
  AND pass_shqr.ACTION = 'PASS-SHQR'

WHERE jest.inact <> 'X'
AND stat.spras = 'E'
AND rs.ACTION = 'INSERT' 
--** ONLY GET THOSE WITH a MES% STATUS OR PASX MO
AND (mo.id is not null OR mes_status.aufnr is not null)
"""

# COMMAND ----------

# df=spark.sql(pasx_pass_query) #.filter(BATCH_NO=='381510C'))
# display(df.filter(df["BATCH_NO"].like("%381510C%")))

# COMMAND ----------

# UPDATED WITH NEW QUERY AND WORKS
nonpasx_inserts_query = """
SELECT DISTINCT
    right(mseg.matnr, 6) AS PRODUCT_ID
  , mseg.werks AS TENANT_ID
  , mseg.charg AS MFG_LOT_NUMBER
  , CONCAT(right(mseg.matnr, 6), '-', mseg.charg) AS BATCH_NO
  , mch.ersda as ARRIVAL_DATE 
  , CASE
    WHEN mseg.aufnr is null and mseg.ebeln is not null and ekko.bsart = 'UB' THEN mkpf.cpudt
    WHEN mseg.aufnr = ' ' and mseg.ebeln <> ' ' and ekko.bsart = 'UB' THEN mkpf.cpudt
    ELSE mch.lwedt 
    END as DATE_RECEIVED
  , 'DEFAULT' AS TRANSACTION_NO
  , '' AS CSV_COMMENT
  , makt.maktx as PRODUCT_DESCRIPTION
  , mseg.matnr AS MATERIAL_ID
  , mseg.aufnr AS PROCESS_ORDER
  , mara.mtart as PRODUCT_TYPE
  , right(mseg.aufnr, 6) AS TRIMMED_PROCESS_ORDER
  , site.tenant_sid as TENANT_SID
  , 'INSERT' as ACTION 
  , 2 as ACTION_NUMBER
  , current_timestamp() AS INSERTED_AT
  , '' AS OPTIONAL_1
  , '' AS OPTIONAL_2
  , '' AS OPTIONAL_3
  , '' AS OPTIONAL_4
  , '' AS OPTIONAL_5
  , '' AS OPTIONAL_6
  , '' AS OPTIONAL_7
  , '' AS OPTIONAL_8
  , trim(right(mseg.aufnr, 6)) AS OPTIONAL_9 
  , trim(mseg.ebeln) AS OPTIONAL_10
  , '' AS OPTIONAL_11
  , '' AS OPTIONAL_12
  , '' AS OPTIONAL_13
  , t001w.name1 AS OPTIONAL_14 
  , mseg.charg AS OPTIONAL_15 
  , mara.mtart AS OPTIONAL_16 
  , '' AS OPTIONAL_17
  , CASE 
      WHEN marc.webaz = '0' THEN ''
      ELSE marc.webaz
    END AS OPTIONAL_18 
  , '' AS OPTIONAL_19
  , '' AS OPTIONAL_20
  , '' AS OPTIONAL_21
  , '' AS OPTIONAL_22
  , '' AS OPTIONAL_23
  , mkpf.cpudt AS OPTIONAL_24
  , mkpf.cputm AS OPTIONAL_25
  , 'CET' AS OPTIONAL_26
  , '' AS OPTIONAL_27
  , '' AS OPTIONAL_28
  , '' AS OPTIONAL_29
  , '' AS OPTIONAL_30
FROM cdl_prod_l0_sustain.mseg mseg
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch on mseg.matnr = mch.matnr 
                               and mseg.charg = mch.charg 
INNER JOIN cdl_prod_l0_sustain.vnd_mara mara on mara.matnr = mseg.matnr
INNER JOIN cdl_prod_l0_sustain.vnd_makt makt on mseg.matnr = makt.matnr 
INNER JOIN sqa.sustain_sites site on mseg.werks = site.plant  
INNER JOIN cdl_prod_l0_sustain.vnd_t001w t001w on mseg.werks = t001w.werks
INNER JOIN cdl_prod_l0_sustain.vnd_marc marc on mseg.werks = marc.werks 
                                and mseg.matnr = marc.matnr
INNER JOIN sqa.config_sustain_products products on  mara.mtart = products.product_type 
                                      and mseg.werks = products.plant 
                                      and (to_timestamp(mch.ersda, 'yyyyMMdd') >= to_timestamp(products.created_date)) 
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo on mo.id = right(mseg.aufnr, 6) and mo.tenant_sid = site.tenant_sid 

LEFT JOIN cdl_prod_l0_sustain.vnd_ekko ekko on mseg.ebeln = ekko.ebeln

LEFT JOIN (
            SELECT mseg1.werks, mseg1.charg, mseg1.matnr, mseg1.aufnr, mseg1.ebeln 
            FROM cdl_prod_l0_sustain.mseg mseg1
            WHERE mseg1.bwart in (321, 350)
          ) released on mseg.charg = released.charg 
                    and mseg.werks = released.werks 
                    and mseg.matnr = released.matnr 
                    and mseg.aufnr = released.aufnr 
--** ONLY GET THOSE WITHOUT a MES% STATUS
LEFT JOIN (
            SELECT distinct aufk.aufnr
            FROM cdl_prod_l0_sustain.vnd_aufk aufk
            INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
            INNER JOIN cdl_prod_l0_sustain.vnd_tj30t user_stat on jest.stat = user_stat.estat
            WHERE jest.inact <> 'X'
            AND user_stat.spras = 'E'
            AND user_stat.txt04 LIKE 'MES%' 
) mes_status ON mes_status.aufnr = mseg.aufnr

-- Add transactional datetime
LEFT JOIN cdl_prod_l0_sustain.mkpf mkpf ON mkpf.MBLNR = mseg.MBLNR

WHERE mseg.bwart = 101
AND (ekko.bsart in ('NB','UB') or ekko.bsart IS NULL)
AND makt.spras = 'E'  
AND released.charg IS NULL 

--** ONLY GET THOSE WITHOUT a PASX MO
AND mo.id IS NULL 

--** ONLY GET THOSE WITHOUT a MES% status
AND mes_status.aufnr IS NULL
"""

# COMMAND ----------

# Updated with new query
nonpasx_end_brr_query = """
SELECT DISTINCT rs.PRODUCT_ID
              , rs.TENANT_ID
              , rs.MFG_LOT_NUMBER
              , rs.BATCH_NO
              , rs.ARRIVAL_DATE
              , mch.lwedt as DATE_RECEIVED
              , rs.TRANSACTION_NO
              , rs.CSV_COMMENT
              , rs.PRODUCT_DESCRIPTION
              , rs.MATERIAL_ID
              , rs.PROCESS_ORDER
              , rs.PRODUCT_TYPE
              , rs.TRIMMED_PROCESS_ORDER
              , rs.TENANT_SID
              , 'END-BRR' AS ACTION
              , 3 AS ACTION_NUMBER
              , current_timestamp() AS INSERTED_AT 
              , '' AS OPTIONAL_1
              , '' AS OPTIONAL_2
              , '' AS OPTIONAL_3
              , '' AS OPTIONAL_4
              , '' AS OPTIONAL_5
              , '' AS OPTIONAL_6
              , '' AS OPTIONAL_7
              , '' AS OPTIONAL_8
              , rs.OPTIONAL_9 AS OPTIONAL_9
              , '' AS OPTIONAL_10
              , nvl(stat.txt04, '') AS OPTIONAL_11
              , '' AS OPTIONAL_12
              , '' AS OPTIONAL_13
              , rs.OPTIONAL_14 AS OPTIONAL_14 
              , rs.OPTIONAL_15 AS OPTIONAL_15 
              , rs.OPTIONAL_16 AS OPTIONAL_16 
              , '' AS OPTIONAL_17
              , rs.OPTIONAL_18 AS OPTIONAL_18 
              , '' AS OPTIONAL_19
              , '' AS OPTIONAL_20
              , '' AS OPTIONAL_21
              , '' AS OPTIONAL_22
              , '' AS OPTIONAL_23
              , jcds.udate AS OPTIONAL_24
              , jcds.utime AS OPTIONAL_25
              , rs.OPTIONAL_26 AS OPTIONAL_26
              , '' AS OPTIONAL_27
              , '' AS OPTIONAL_28
              , '' AS OPTIONAL_29
              , '' AS OPTIONAL_30
FROM ALL_INSERTS rs
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo  ON rs.TRIMMED_PROCESS_ORDER = mo.id 
                                          AND rs.TENANT_SID = mo.tenant_sid
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch on rs.MATERIAL_ID = mch.matnr 
                                AND rs.MFG_LOT_NUMBER = mch.charg 
INNER JOIN cdl_prod_l0_sustain.vnd_aufk aufk ON aufk.aufnr = rs.PROCESS_ORDER
INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
INNER JOIN cdl_prod_l0_sustain.vnd_tj02t stat ON jest.stat = stat.istat

--Transactional datetime
LEFT JOIN cdl_prod_l0_sustain.jcds jcds ON jest.mandt = jcds.mandt
                                           AND jest.stat = jcds.stat
                                           AND jest.objnr = jcds.objnr
                                           AND jest.chgnr = jcds.chgnr

--** ONLY GET THOSE WITHOUT a MES% STATUS
LEFT JOIN (
            SELECT distinct aufk.aufnr
            FROM cdl_prod_l0_sustain.vnd_aufk aufk
            INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
            INNER JOIN cdl_prod_l0_sustain.vnd_tj30t user_stat on jest.stat = user_stat.estat
            WHERE jest.inact <> 'X'
            AND user_stat.spras = 'E'
            AND user_stat.txt04 LIKE 'MES%' 
) mes_status ON mes_status.aufnr = rs.process_order
--**

WHERE jest.inact <> 'X'
AND stat.spras = 'E'
AND stat.txt04 = 'TECO'  
--** ONLY GET THOSE WITHOUT a PASX MO
AND mo.id is null

--** ONLY GET THOSE WITHOUT a MES% STATUS
AND mes_status.aufnr is null 
"""

# COMMAND ----------

# UPDATED WITH NEW QUERY AND WORKS
nonpasx_pass_query = """
SELECT DISTINCT rs.PRODUCT_ID
              , rs.TENANT_ID
              , rs.MFG_LOT_NUMBER
              , rs.BATCH_NO
              , rs.ARRIVAL_DATE
              , CASE
                WHEN rs.PROCESS_ORDER is null and rs.OPTIONAL_10 is not null and ekko.bsart = 'UB' THEN rs.DATE_RECEIVED
                WHEN rs.PROCESS_ORDER = ' ' and rs.OPTIONAL_10 <> ' ' and ekko.bsart = 'UB' THEN rs.DATE_RECEIVED
                ELSE mch.lwedt 
                END as DATE_RECEIVED
              , rs.TRANSACTION_NO
              , rs.CSV_COMMENT
              , rs.PRODUCT_DESCRIPTION
              , rs.MATERIAL_ID
              , rs.PROCESS_ORDER
              , rs.PRODUCT_TYPE
              , rs.TRIMMED_PROCESS_ORDER
              , rs.TENANT_SID
              , CASE
                WHEN passed.vcode = 'CREL' and rs.TENANT_ID = 'CO01' THEN 'PASS-CREL'
                WHEN passed.vcode = 'SHQR' and rs.TENANT_ID = 'CO01' THEN 'PASS-SHQR'
                ELSE 'PASS'
                END as ACTION
              , CASE
                WHEN passed.vcode = 'SHQR' and rs.TENANT_ID = 'CO01' THEN 5
                WHEN passed.vcode = 'CREL' and rs.TENANT_ID = 'CO01' THEN 6
                ELSE 7
                END AS ACTION_NUMBER
              , current_timestamp() AS INSERTED_AT 
              , '' AS OPTIONAL_1
              , '' AS OPTIONAL_2
              , '' AS OPTIONAL_3
              , '' AS OPTIONAL_4
              , '' AS OPTIONAL_5
              , '' AS OPTIONAL_6
              , '' AS OPTIONAL_7
              , '' AS OPTIONAL_8
              , rs.OPTIONAL_9 AS OPTIONAL_9
              , rs.OPTIONAL_10 AS OPTIONAL_10
              , nvl(nonpasxbrr.OPTIONAL_11, '') AS OPTIONAL_11
              , rs.OPTIONAL_12 AS OPTIONAL_12
              , nvl(passed.vcode, '') AS OPTIONAL_13
              , rs.OPTIONAL_14 AS OPTIONAL_14 
              , rs.OPTIONAL_15 AS OPTIONAL_15 
              , rs.OPTIONAL_16 AS OPTIONAL_16 
              , '' AS OPTIONAL_17
              , rs.OPTIONAL_18 AS OPTIONAL_18 
              , '' AS OPTIONAL_19
              , '' AS OPTIONAL_20
              , '' AS OPTIONAL_21
              , '' AS OPTIONAL_22
              , '' AS OPTIONAL_23
              , passed.vdatum AS OPTIONAL_24
              , passed.vezeiterf AS OPTIONAL_25
              , rs.OPTIONAL_26 AS OPTIONAL_26
              , '' AS OPTIONAL_27
              , '' AS OPTIONAL_28
              , '' AS OPTIONAL_29
              , '' AS OPTIONAL_30
FROM SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY rs
LEFT JOIN NON_PASX_END_BRR nonpasxbrr on rs.MFG_LOT_NUMBER = nonpasxbrr.MFG_LOT_NUMBER
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo ON mo.id = rs.TRIMMED_PROCESS_ORDER 
                                        and mo.tenant_sid = rs.tenant_sid
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON rs.MATERIAL_ID = mch.matnr 
                               and rs.MFG_LOT_NUMBER = mch.charg 
INNER JOIN cdl_prod_l0_sustain.mseg mseg ON mseg.charg = rs.MFG_LOT_NUMBER 
                                and mseg.werks = rs.TENANT_ID 
                                and mseg.matnr = rs.MATERIAL_ID 
                                and mseg.umcha = rs.MFG_LOT_NUMBER

--** ONLY GET THOSE WITHOUT a MES% STATUS
LEFT JOIN (
            SELECT distinct aufk.aufnr
            FROM cdl_prod_l0_sustain.vnd_aufk aufk
            INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
            INNER JOIN cdl_prod_l0_sustain.vnd_tj30t user_stat on jest.stat = user_stat.estat
            WHERE jest.inact <> 'X'
            AND user_stat.spras = 'E'
            AND user_stat.txt04 LIKE 'MES%' 
) mes_status ON mes_status.aufnr = rs.process_order
--**

--AATE-20561
LEFT JOIN cdl_prod_l0_sustain.qals qals on qals.charg = mseg.charg 
                                       and qals.matnr = mseg.matnr
                                       and qals.aufnr = mseg.aufnr
                                       and qals.werk = mseg.werks
LEFT JOIN (
      SELECT qave.mandant, 
             qave.prueflos, 
             qave.vcode, 
             nvl(qave.vaename, qave.vname) as username,
             qave.vdatum,
             qave.vezeiterf
      FROM cdl_prod_l0_sustain.qave qave 
      WHERE qave.kzart = 'L'
      AND qave.vcode <> ' '
   ) passed ON qals.mandant = passed.mandant 
           AND qals.prueflos = passed.prueflos

LEFT JOIN cdl_prod_l0_sustain.vnd_ekko ekko on mseg.ebeln = ekko.ebeln

WHERE mseg.bwart IN (321, 350)
AND rs.ACTION = 'INSERT' 
AND mes_status.aufnr is null

--** ONLY GET THOSE WITHOUT a PASX MO
AND mo.id IS NULL

--** ONLY GET THOSE WITHOUT a MES% STATUS
AND mes_status.aufnr is null 
"""

# COMMAND ----------

update_query = """
SELECT  DISTINCT
      rs.PRODUCT_ID
    , rs.TENANT_ID
    , rs.MFG_LOT_NUMBER
    , rs.BATCH_NO
    , rs.ARRIVAL_DATE
    , CASE
      WHEN rs.PROCESS_ORDER is null and rs.OPTIONAL_10 is not null and ekko.bsart = 'UB' THEN rs.DATE_RECEIVED
      WHEN rs.PROCESS_ORDER = ' ' and rs.OPTIONAL_10 <> ' ' and ekko.bsart = 'UB' THEN rs.DATE_RECEIVED
      ELSE mch.lwedt 
      END as DATE_RECEIVED
    , rs.TRANSACTION_NO
    , rs.CSV_COMMENT
    , rs.PRODUCT_DESCRIPTION
    , rs.MATERIAL_ID
    , rs.PROCESS_ORDER
    , rs.PRODUCT_TYPE
    , rs.TRIMMED_PROCESS_ORDER
    , rs.TENANT_SID
    , 'UPDATE' AS ACTION
    , 1 AS ACTION_NUMBER
    , current_timestamp() AS INSERTED_AT 
    , rs.OPTIONAL_1 AS OPTIONAL_1
    , rs.OPTIONAL_2 AS OPTIONAL_2
    , rs.OPTIONAL_3 AS OPTIONAL_3
    , rs.OPTIONAL_4 AS OPTIONAL_4
    , rs.OPTIONAL_5 AS OPTIONAL_5
    , rs.OPTIONAL_6 AS OPTIONAL_6
    , rs.OPTIONAL_7 AS OPTIONAL_7
    , rs.OPTIONAL_8 AS OPTIONAL_8
    , rs.OPTIONAL_9 AS OPTIONAL_9
    , rs.OPTIONAL_10 AS OPTIONAL_10
    , rs.OPTIONAL_11 AS OPTIONAL_11
    , rs.OPTIONAL_12 AS OPTIONAL_12
    , rs.OPTIONAL_13 AS OPTIONAL_13
    , rs.OPTIONAL_14 AS OPTIONAL_14 
    , rs.OPTIONAL_15 AS OPTIONAL_15 
    , rs.OPTIONAL_16 AS OPTIONAL_16 
    , rs.OPTIONAL_17 AS OPTIONAL_17
    , rs.OPTIONAL_18 AS OPTIONAL_18 
    , rs.OPTIONAL_19 AS OPTIONAL_19
    , rs.OPTIONAL_20 AS OPTIONAL_20
    , rs.OPTIONAL_21 AS OPTIONAL_21
    , rs.OPTIONAL_22 AS OPTIONAL_22
    , rs.OPTIONAL_23 AS OPTIONAL_23
    , rs.OPTIONAL_24 AS OPTIONAL_24
    , rs.OPTIONAL_25 AS OPTIONAL_25
    , rs.OPTIONAL_26 AS OPTIONAL_26
    , rs.OPTIONAL_27 AS OPTIONAL_27
    , rs.OPTIONAL_28 AS OPTIONAL_28
    , rs.OPTIONAL_29 AS OPTIONAL_29
    , rs.OPTIONAL_30 AS OPTIONAL_30
FROM SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY rs
INNER JOIN 
  (SELECT TENANT_ID, BATCH_NO, INSERTED_AT, max(ACTION_NUMBER) AS max_action_number
      FROM SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY 
      GROUP BY TENANT_ID, BATCH_NO, INSERTED_AT 
   ) max_actions
       ON rs.TENANT_ID = max_actions.TENANT_ID 
      AND rs.BATCH_NO = max_actions.BATCH_NO 
      AND rs.INSERTED_AT = max_actions.INSERTED_AT 
      AND rs.ACTION_NUMBER = max_actions.max_action_number
   
INNER JOIN
  (SELECT TENANT_ID, BATCH_NO, max(INSERTED_AT) AS last_update_date
      FROM SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY
      GROUP BY TENANT_ID, BATCH_NO
   ) latest_updates
       ON rs.TENANT_ID = latest_updates.TENANT_ID 
      AND rs.BATCH_NO = latest_updates.BATCH_NO 
      AND rs.INSERTED_AT = latest_updates.last_update_date 
      
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch 
   ON  rs.material_id = mch.matnr 
   AND rs.mfg_lot_number = mch.charg

LEFT JOIN cdl_prod_l0_sustain.vnd_ekko ekko on rs.OPTIONAL_10 = ekko.ebeln

-- Check if the record did not pass
LEFT JOIN SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY pass
  ON pass.MFG_LOT_NUMBER = rs.MFG_LOT_NUMBER
  AND pass.MATERIAL_ID =  rs.MATERIAL_ID
  AND pass.ACTION = 'PASS'
      
WHERE rs.date_received <> mch.lwedt
and pass.MFG_LOT_NUMBER is null
"""

# COMMAND ----------

from functools import reduce
from pyspark.sql import DataFrame

#mount_point = dbutils.secrets.get('sqa', 'sqa_mount_point') 
sqif = Framework()

#sqif.mount()

# COMMAND ----------

sqif.update_processing_state('SUSTAIN_UPCOMING_BATCHES', 'SQA.SUSTAIN_UPCOMING_BATCHES') 


#add etl_id to results
etl_id = sqif.get_etl_id()
print('etl_id: ', etl_id)

# COMMAND ----------

#get PASX INSERTS
print('getting PASX Inserts')
pasx_inserts_df_aux = sqif.to_df(pasx_inserts_query)
pasx_inserts_df = pasx_inserts_df_aux.filter(pasx_inserts_df_aux.ACTION == 'INSERT')

# COMMAND ----------

#get NON PASX INSERTS
print('getting non-PASX Inserts')
nonpasx_inserts_df = sqif.to_df(nonpasx_inserts_query)


# COMMAND ----------

print('creating all_current_inserts')
#union pasx and non pasx inserts as all new inserts
all_current_inserts_df = pasx_inserts_df.union(nonpasx_inserts_df)
all_current_inserts_df.createOrReplaceTempView('INSERTS');

# COMMAND ----------

print('getting historical inserts')
historical_inserts_df = spark.sql("""
select
PRODUCT_ID
,TENANT_ID
,MFG_LOT_NUMBER
,BATCH_NO
,ARRIVAL_DATE
,DATE_RECEIVED
,TRANSACTION_NO
,CSV_COMMENT
,PRODUCT_DESCRIPTION
,MATERIAL_ID
,PROCESS_ORDER
,PRODUCT_TYPE
,TRIMMED_PROCESS_ORDER
,TENANT_SID
,ACTION
,ACTION_NUMBER
,INSERTED_AT 
,OPTIONAL_1
,OPTIONAL_2
,OPTIONAL_3
,OPTIONAL_4
,OPTIONAL_5
,OPTIONAL_6
,OPTIONAL_7
,OPTIONAL_8
,OPTIONAL_9
,OPTIONAL_10
,OPTIONAL_11
,OPTIONAL_12
,OPTIONAL_13
,OPTIONAL_14 
,OPTIONAL_15 
,OPTIONAL_16 
,OPTIONAL_17
,OPTIONAL_18 
,OPTIONAL_19
,OPTIONAL_20
,OPTIONAL_21
,OPTIONAL_22
,OPTIONAL_23
,OPTIONAL_24
,OPTIONAL_25
,OPTIONAL_26
,OPTIONAL_27
,OPTIONAL_28
,OPTIONAL_29
,OPTIONAL_30
from SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY
where ACTION = 'INSERT'
""")


# COMMAND ----------

print('creating all inserts')
all_inserts_df = all_current_inserts_df.union(historical_inserts_df)
all_inserts_df.createOrReplaceTempView('ALL_INSERTS');

# COMMAND ----------

print('running PASX END BRR query')
pasx_end_brr_df_aux = (sqif.to_df(pasx_end_brr_query))
pasx_end_brr_df = pasx_end_brr_df_aux.filter(pasx_end_brr_df_aux.ACTION == 'END-BRR')

pasx_end_brr_df.createOrReplaceTempView('PASX_END_BRR')

# COMMAND ----------

print('running PASX END QA BRR query')
pasx_end_qa_brr_df_aux = (sqif.to_df(pasx_end_qa_brr_query))
pasx_end_qa_brr_df = pasx_end_qa_brr_df_aux.filter(pasx_end_qa_brr_df_aux.ACTION == 'END-QA-BRR')

pasx_end_qa_brr_df.createOrReplaceTempView('PASX_END_QA_BRR')

# COMMAND ----------

print('running PASX PASS queries')
pasx_pass_ar_df = (sqif.to_df(pasx_pass_ar_query))
pasx_pass_df_aux = sqif.to_df(pasx_pass_query)
pasx_pass_df = pasx_pass_df_aux.filter(pasx_pass_df_aux.ACTION != 'FAIL')

# COMMAND ----------

print('running non-PASX END BRR query')
nonpasx_end_brr_df = (sqif.to_df(nonpasx_end_brr_query)) 

nonpasx_end_brr_df.createOrReplaceTempView('NON_PASX_END_BRR')

# COMMAND ----------

print('running non-PASX PASS query')
nonpasx_pass_df = sqif.to_df(nonpasx_pass_query)

# COMMAND ----------

print('running update query')
updates_df = sqif.to_df(update_query)

# COMMAND ----------

print('create csv dataframe')
dfs = [all_current_inserts_df, pasx_end_brr_df, pasx_end_qa_brr_df, pasx_pass_ar_df, pasx_pass_df, nonpasx_end_brr_df, nonpasx_pass_df]
union_df = reduce(DataFrame.union, dfs)

# COMMAND ----------

print('get PASX history')
ingested_records_alias_df = union_df.alias('ingested_records_alias_df')
existing_records_df = spark.sql('SELECT * FROM SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY')
existing_records_alias_df = existing_records_df.alias('existing_records_alias_df')

# COMMAND ----------

print('filter for new records')
filter_clause = "existing_records_alias_df.BATCH_NO is null and existing_records_alias_df.TENANT_ID is null and existing_records_alias_df.ACTION is null"
results_df = ingested_records_alias_df.join(existing_records_alias_df,
(
  (col("ingested_records_alias_df.BATCH_NO") == col("existing_records_alias_df.BATCH_NO")) &
  (col("ingested_records_alias_df.ACTION") == col("existing_records_alias_df.ACTION")) &
  (col("ingested_records_alias_df.TENANT_ID") == col("existing_records_alias_df.TENANT_ID"))
),"left").filter( 
  filter_clause 
).select(
  'ingested_records_alias_df.*'
)

# COMMAND ----------

#add updates to filtered results
all_results_df = results_df.union(updates_df)
#print('all_results count: ', all_results.count())

all_results_df.cache()

# COMMAND ----------

all_results_df = all_results_df.withColumn('PRODUCT_DESCRIPTION', regexp_replace('PRODUCT_DESCRIPTION', ',|"', ' ')) #replace commas with space
all_results_df = all_results_df.withColumn('ETL_ID', lit(etl_id))  #add etl_id


print('get mandatory fields')
trimmed_results_df = all_results_df.select(
  col('TENANT_ID'),
  col('BATCH_NO'),
  col('PRODUCT_ID'),
  col('PRODUCT_DESCRIPTION'),
  col('MFG_LOT_NUMBER'),
  date_format(to_date(col('ARRIVAL_DATE'),"yyyyMMdd"), "MM/dd/yyyy").alias('ARRIVAL_DATE'),
  col('TRANSACTION_NO'),
  date_format(to_date(col('DATE_RECEIVED'),"yyyyMMdd"), "MM/dd/yyyy").alias('DATE_RECEIVED'),
  col('ACTION'),
  col('CSV_COMMENT').alias('COMMENT'),
  col('OPTIONAL_1'),
  col('OPTIONAL_2'),
  col('OPTIONAL_3'),
  col('OPTIONAL_4'),
  col('OPTIONAL_5'),
  col('OPTIONAL_6'),
  col('OPTIONAL_7'),
  col('OPTIONAL_8'),
  col('OPTIONAL_9'),
  col('OPTIONAL_10'),
  col('OPTIONAL_11'),
  col('OPTIONAL_12'),
  col('OPTIONAL_13'),
  col('OPTIONAL_14'),
  col('OPTIONAL_15'),
  col('OPTIONAL_16'),
  col('OPTIONAL_17'),
  col('OPTIONAL_18'),
  col('OPTIONAL_19'),
  col('OPTIONAL_20'),
  col('OPTIONAL_21'),
  col('OPTIONAL_22'),
  col('OPTIONAL_23'),
  col('OPTIONAL_24'),
  col('OPTIONAL_25'),
  col('OPTIONAL_26'),
  col('OPTIONAL_27'),
  col('OPTIONAL_28'),
  col('OPTIONAL_29'),
  col('OPTIONAL_30')
)


trimmed_results_df.cache()

print('Getting result count')
trimmed_results_count = trimmed_results_df.count()
print('Result Count: ', trimmed_results_count)

# COMMAND ----------

dbutils.notebook.exit("exit")

# COMMAND ----------

# if trimmed_results_count==0:
#   print('Zero results, updating config')
#   sqif.update_config(None, 'SUSTAIN_UPCOMING_BATCHES', 'SQA.SUSTAIN_UPCOMING_BATCHES')
#   sqlContext.clearCache()
#   dbutils.notebook.exit('Zero results, exiting')

# COMMAND ----------

# print('converting to csv')
# filename = sqif.to_csv(trimmed_results_df.orderBy(
#   ['BATCH_NO', 'ACTION_NUMBER'] #order by BATCH_NO, ACTION_NUMBER
# ), 'sustain_upcoming_batches_csv_file')
# print('csv file created: ', filename)

# COMMAND ----------

# try:
#   print('sftping')
#   sftp_result = sqif.sftp(filename, 'uploadib')
# except:
#   dbutils.notebook.exit('Unable to SFTP, exiting')

# print('sftp successful')

# COMMAND ----------

# print('Moving file from processing to archive')
# sqif.move_csv_to_archive(filename, 'sustain_upcoming_batches')

# COMMAND ----------

# print('saving results to history')
# sqif.save(all_results_df, 'SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY') 
# print('saving results to history complete')

# COMMAND ----------

# print('updating config')
# sqif.update_config(filename, 'SUSTAIN_UPCOMING_BATCHES', 'SQA.SUSTAIN_UPCOMING_BATCHES') 
# print('config updated')

# COMMAND ----------

# print('exit')
# sqlContext.clearCache()
# dbutils.notebook.exit(filename)