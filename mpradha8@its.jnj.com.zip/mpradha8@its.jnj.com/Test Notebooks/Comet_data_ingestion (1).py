# Databricks notebook source
import requests
import pandas as pd
import json
from pyspark.sql.types import StructType, StructField, FloatType, StringType, BooleanType, TimestampType, IntegerType
from time import sleep
from collections import defaultdict
import datetime
import time
import re
from pyspark.sql.functions import *
from datetime import datetime as dt
from pyspark.sql.functions import col

# COMMAND ----------

# Read the credentials
username = dbutils.secrets.get('comet', 'api_username')
password = dbutils.secrets.get('comet', 'api_password')
client_id = dbutils.secrets.get('comet', 'api_client_id')
client_secret = dbutils.secrets.get('comet', 'api_client_secret')

## Authentication API Call
url = dbutils.secrets.get('comet', 'api_auth_url')
response = requests.post(url, data = {  "username": username,  
                                        "password": password,
                                        "client_id": client_id,
                                        "client_secret": client_secret,
                                        "grant_type": "password"})

print(response.status_code)

# COMMAND ----------

def buildCometBodyRequest(sites, maxSystemModstamp):
  comet_data = {
  "RecordType": "Nonconformance, CAPA ",
  "Batch ID/Lot Number": "",
  "Material/Item": "",
  "Status": "Draft, Open, Complete, Closed, Void",
  "SiteName": sites,
  "ClosedAfterDate": maxSystemModstamp,
  "ClosedBeforeDate": "",
  "SourceSystem": "",
  "LastModifiedDate": maxSystemModstamp,
  "SystemModStampDate": maxSystemModstamp,
  "NextOffset": 0
  }
  
  return json.dumps(comet_data)

# COMMAND ----------

print(maxSystemModstamp)

# COMMAND ----------

accessToken = response.json()['access_token']

sites = spark.sql("""select cast(collect_list(J_J_SITE_NAME) as string) as J_J_SITE_NAME from SQA.COMET_SITES""").collect()[0][0]

maxSystemModstamp = spark.sql("""select date_format(max(SystemModstamp), 'yyyy-MM-dd HH:mm:ss') from SQA.COMET_NC_DETAILS""").collect()[0][0]

comet_data = buildCometBodyRequest(sites[1:-1], maxSystemModstamp)

headers = {'Authorization': 'Bearer {}'.format(accessToken),'ClientId': '{}'.format(client_id), 'Content-Type': 'application/json'}

dataresponse = requests.post(dbutils.secrets.get('comet', 'api_url_lookup'), data=comet_data, headers=headers)

print(dataresponse.content)

# COMMAND ----------

s

# COMMAND ----------

 dbutils.notebook.exit("exit")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read and Parse JSON data/file

# COMMAND ----------

data = dataresponse.json()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Noncomformance Tables

# COMMAND ----------

#Adding json data to NC_DETAILS table
parsed_data_nc = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:
  parsed_data_nc["attributes_type"].append(data[0]['NC_Records'][index]['NCDetails']["attributes"]["type"])
  parsed_data_nc["attributes_url"].append(data[0]['NC_Records'][index]['NCDetails']["attributes"]["url"])
  parsed_data_nc["Id"].append(data[0]['NC_Records'][index]['NCDetails']["Id"])
  parsed_data_nc["Name"].append(data[0]['NC_Records'][index]['NCDetails']["Name"])
  parsed_data_nc["compliancequest__NC_Title__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__NC_Title__c"])
  parsed_data_nc["compliancequest__Status__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Status__c"])
  parsed_data_nc["CreatedDate"].append(data[0]['NC_Records'][index]['NCDetails']["CreatedDate"])
  parsed_data_nc["compliancequest__Record_Stage__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Record_Stage__c"])
  parsed_data_nc["CreatedById"].append(data[0]['NC_Records'][index]['NCDetails']["CreatedById"])
  parsed_data_nc["LastModifiedDate"].append(data[0]['NC_Records'][index]['NCDetails']["LastModifiedDate"])
  parsed_data_nc["LastModifiedById"].append(data[0]['NC_Records'][index]['NCDetails']["LastModifiedById"])
  parsed_data_nc["CQ_JNJ_SQX_Nonconformance_Owner__c"].append(data[0]['NC_Records'][index]['NCDetails']["CQ_JNJ_SQX_Nonconformance_Owner__c"])
  parsed_data_nc["compliancequest__Due_Date_Investigation__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Due_Date_Investigation__c"])
  parsed_data_nc["compliancequest__Org_Site__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Org_Site__c"])
  parsed_data_nc["SystemModstamp"].append(data[0]['NC_Records'][index]['NCDetails']["SystemModstamp"])
  parsed_data_nc["CQ_JNJ_Functional_Area_1__c"].append(data[0]['NC_Records'][index]['NCDetails']["CQ_JNJ_Functional_Area_1__c"])
  parsed_data_nc["CQ_JNJ_Functional_Area_2__c"].append(data[0]['NC_Records'][index]['NCDetails']["CQ_JNJ_Functional_Area_2__c"])
  parsed_data_nc["CQ_JNJ_Functional_Area__c"].append(data[0]['NC_Records'][index]['NCDetails']["CQ_JNJ_Functional_Area__c"])
  parsed_data_nc["compliancequest__Org_Division__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Org_Division__c"])
  parsed_data_nc["compliancequest__Org_Business_Unit__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Org_Business_Unit__c"])
  parsed_data_nc["compliancequest__Aware_Date__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Aware_Date__c"])
  parsed_data_nc["Owner_name"].append(data[0]['NC_Records'][index]['NCDetails']["Owner"]["Name"])
  parsed_data_nc["CreatedBy_type"].append(data[0]['NC_Records'][index]['NCDetails']["CreatedBy"]["attributes"]["type"])
  parsed_data_nc["CreatedBy_url"].append(data[0]['NC_Records'][index]['NCDetails']["CreatedBy"]["attributes"]["url"])
  parsed_data_nc["CreatedBy_Id"].append(data[0]['NC_Records'][index]['NCDetails']["CreatedBy"]["Id"])
  parsed_data_nc["CreatedBy_Name"].append(data[0]['NC_Records'][index]['NCDetails']["CreatedBy"]["Name"])
  parsed_data_nc["LastModifiedBy_type"].append(data[0]['NC_Records'][index]['NCDetails']["LastModifiedBy"]["attributes"]["type"])
  parsed_data_nc["LastModifiedBy_url"].append(data[0]['NC_Records'][index]['NCDetails']["LastModifiedBy"]["attributes"]["url"])
  parsed_data_nc["LastModifiedBy_Id"].append(data[0]['NC_Records'][index]['NCDetails']["LastModifiedBy"]["Id"])
  parsed_data_nc["LastModifiedBy_Name"].append(data[0]['NC_Records'][index]['NCDetails']["LastModifiedBy"]["Name"])
  parsed_data_nc["compliancequest__Close_Date__c"].append(data[0]['NC_Records'][index]['NCDetails']["compliancequest__Close_Date__c"])

  index += 1

nc_details = pd.DataFrame(parsed_data_nc).dropna(axis='columns', how='all')

if not nc_details.empty:
  df_nc_details = spark.createDataFrame(nc_details)

  df_nc_details = df_nc_details.withColumn("INSERTED_AT", current_timestamp())

  df_nc_details.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_DETAILS')

# COMMAND ----------

#Adding json data to NC_ResponseApprovalRecords table
parsed_data_nc_rar = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:

  nc_rar_size = len(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'])
  
  if nc_rar_size != 0:
      parsed_data_nc_rar["attributes_type"].append(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0]["attributes"]["type"])
      parsed_data_nc_rar["attributes_url"].append(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0]["attributes"]["url"])
      parsed_data_nc_rar["Id"].append(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0]["Id"])
      parsed_data_nc_rar["compliancequest__SQX_Nonconformance__c"].append(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0]["compliancequest__SQX_Nonconformance__c"])
      parsed_data_nc_rar["compliancequest__Step__c"].append(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0]["compliancequest__Step__c"])
      parsed_data_nc_rar["compliancequest__SQX_User__c"].append(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0]["compliancequest__SQX_User__c"])

      if data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0].get('compliancequest__SQX_User__r') != None:
        parsed_data_nc_rar["compliancequest__SQX_User__r_Name"].append(data[0]['NC_Records'][index]['relatedResponseApprovalRecords'][0]["compliancequest__SQX_User__r"]["Name"])
      else:
        parsed_data_nc_rar["compliancequest__SQX_User__r_Name"].append(None)
  
  index += 1

nc_rar = pd.DataFrame(parsed_data_nc_rar).dropna(axis='columns', how='all')

if not nc_rar.empty:
  #Cast column to string.
  nc_rar['compliancequest__Step__c'] = nc_rar['compliancequest__Step__c'].astype(str)

  #Create spark dataframe
  df_nc_rar = spark.createDataFrame(nc_rar)

  df_nc_rar = df_nc_rar.withColumn("INSERTED_AT", current_timestamp())

  df_nc_rar.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_ResponseApprovalRecords')

# COMMAND ----------

#Adding json data to NC_relatedNCRiskAssessmentRecords table
parsed_data_nc_risk = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:

  nc_risk_len = len(data[0]['NC_Records'][index]['relatedNCRiskAssessmentRecords'])

  if nc_risk_len != 0:
    parsed_data_nc_risk["attributes_type"].append(data[0]['NC_Records'][index]['relatedNCRiskAssessmentRecords'][0]["attributes"]["type"])
    parsed_data_nc_risk["attributes_url"].append(data[0]['NC_Records'][index]['relatedNCRiskAssessmentRecords'][0]["attributes"]["url"])
    parsed_data_nc_risk["Id"].append(data[0]['NC_Records'][index]['relatedNCRiskAssessmentRecords'][0]["Id"])
    parsed_data_nc_risk["compliancequest__Conclusion__c"].append(data[0]['NC_Records'][index]['relatedNCRiskAssessmentRecords'][0]["compliancequest__Conclusion__c"])
    parsed_data_nc_risk["compliancequest__SQX_Nonconformance__c"].append(data[0]['NC_Records'][index]['relatedNCRiskAssessmentRecords'][0]["compliancequest__SQX_Nonconformance__c"])

  index += 1

nc_risk = pd.DataFrame(parsed_data_nc_risk).dropna(axis='columns', how='all')

if not nc_risk.empty:
  #Create spark dataframe
  df_nc_risk = spark.createDataFrame(nc_risk)
  df_nc_risk = df_nc_risk.withColumn("INSERTED_AT", current_timestamp())
  df_nc_risk.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_RiskAssessmentRecords')

# COMMAND ----------

#Adding json data to NC_relatedNCAdditionalInfoRecords table
parsed_data_nc_info = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:

  none_record = data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords']
  
  if none_record != None:
    nc_info_len = len(data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords'])
  else:
    nc_info_len = 1

  if nc_info_len != 0 and none_record != None:
    parsed_data_nc_info["attributes_type"].append(data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords'][0]["attributes"]["type"])
    parsed_data_nc_info["attributes_url"].append(data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords'][0]["attributes"]["url"])
    parsed_data_nc_info["Id"].append(data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords'][0]["Id"])
    parsed_data_nc_info["CQ_JNJ_SQX_Nonconformance__c"].append(data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords'][0]["CQ_JNJ_SQX_Nonconformance__c"])
    parsed_data_nc_info["CQ_JNJ_SQX_Mfg_Category__c"].append(data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords'][0]["CQ_JNJ_SQX_Mfg_Category__c"])
    parsed_data_nc_info["CQ_JNJ_SQX_Mfg_Technology__c"].append(data[0]['NC_Records'][index]['relatedNCAdditionalInfoRecords'][0]["CQ_JNJ_SQX_Mfg_Technology__c"])

  index += 1

nc_info = pd.DataFrame(parsed_data_nc_info).dropna(axis='columns', how='all')

if not nc_info.empty:
  #Create spark dataframe
  df_nc_info = spark.createDataFrame(nc_info)

  df_nc_info = df_nc_info.withColumn("INSERTED_AT", current_timestamp())

  df_nc_info.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_AdditionalInfoRecords')

# COMMAND ----------

#Adding json data to NC_relatedInvestigationRecords table
parsed_data_nc_investigation = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:

  investigation_size = len(data[0]['NC_Records'][index]['relatedInvestigationRecords'])
  investigation_index = 0

  if investigation_size != 0:
    while investigation_index < investigation_size:
            parsed_data_nc_investigation["attributes_type"].append(data[0]['NC_Records'][index]['relatedInvestigationRecords'][investigation_index]["attributes"]["type"])
            parsed_data_nc_investigation["attributes_url"].append(data[0]['NC_Records'][index]['relatedInvestigationRecords'][investigation_index]["attributes"]["url"])
            parsed_data_nc_investigation["Id"].append(data[0]['NC_Records'][index]['relatedInvestigationRecords'][investigation_index]["Id"])
            parsed_data_nc_investigation["compliancequest__SQX_Nonconformance__c"].append(data[0]['NC_Records'][index]['relatedInvestigationRecords'][investigation_index]["compliancequest__SQX_Nonconformance__c"])
            parsed_data_nc_investigation["compliancequest__Completed_On__c"].append(data[0]['NC_Records'][index]['relatedInvestigationRecords'][investigation_index]["compliancequest__Completed_On__c"])
            
            investigation_index += 1

  index += 1

nc_investigation = pd.DataFrame(parsed_data_nc_investigation).dropna(axis='columns', how='all')

if not nc_investigation.empty:
  df_nc_investigation = spark.createDataFrame(nc_investigation)

  df_nc_investigation = df_nc_investigation.withColumn("INSERTED_AT", current_timestamp())

  df_nc_investigation.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_InvestigationRecords')

# COMMAND ----------

#Adding json data to NC_relatedImpactedPartLotRecords table
parsed_data_nc_impacted = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:

  impacted_size = len(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'])
  impacted_index = 0

  if impacted_size != 0:
    while impacted_index < impacted_size:
            parsed_data_nc_impacted["attributes_type"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["attributes"]["type"])
            parsed_data_nc_impacted["attributes_url"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["attributes"]["url"])
            parsed_data_nc_impacted["Id"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["Id"])
            parsed_data_nc_impacted["CQ_JNJ_Vendor_Supplier_Number__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Vendor_Supplier_Number__c"])
            parsed_data_nc_impacted["CQ_JNJ_Manufacture_Source_Number__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Manufacture_Source_Number__c"])
            parsed_data_nc_impacted["CQ_JNJ_Manufacturer_Source_Name__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Manufacturer_Source_Name__c"])
            parsed_data_nc_impacted["CQ_JNJ_Source_System__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Source_System__c"])
            parsed_data_nc_impacted["CQ_JNJ_Material_Item__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Material_Item__c"])
            parsed_data_nc_impacted["compliancequest__Lot_Number__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__Lot_Number__c"])
            parsed_data_nc_impacted["compliancequest__SQX_Nonconformance__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Nonconformance__c"])
            parsed_data_nc_impacted["CQ_JNJ_Material_Description__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Material_Description__c"])
            parsed_data_nc_impacted["CQ_JNJ_Product_Grouping__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Product_Grouping__c"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__c"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_attributes_type"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["attributes"]["type"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_attributes_url"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["attributes"]["url"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_Id"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Id"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_OwnerId"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["OwnerId"])
            #parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Part_Description__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Part_Description__c"])
            #parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_CQ_JNJ_Source__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["CQ_JNJ_Source__c"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Part_Number__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Part_Number__c"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Active__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Active__c"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Part_Family__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Part_Family__c"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_Name"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Name"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_Owner_attributes_type"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["attributes"]["type"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_Owner_attributes_url"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["attributes"]["url"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_Owner_Id"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["Id"])
            parsed_data_nc_impacted["compliancequest__SQX_Impacted_Part__r_Owner_Name"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["Name"])
            parsed_data_nc_impacted["CQ_JNJ_Decision_Date__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Decision_Date__c"])
            parsed_data_nc_impacted["compliancequest_SQX_CAPA__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest_SQX_CAPA__c"])
            parsed_data_nc_impacted["CQ_JNJ_Disposition_Details__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Disposition_Details__c"])
            parsed_data_nc_impacted["CQ_JNJ_Disposition_Type__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Disposition_Type__c"])
            parsed_data_nc_impacted["CQ_JNJ_Release_from_Investigation__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Release_from_Investigation__c"])
            parsed_data_nc_impacted["CQ_JNJ_Qty_Unit_of_Measure__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Qty_Unit_of_Measure__c"])
            parsed_data_nc_impacted["CQ_JNJ_Material_Continuation_Decision__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Material_Continuation_Decision__c"])
            parsed_data_nc_impacted["compliancequest__Lot_Quantity__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__Lot_Quantity__c"])
            
            
            impacted_index += 1

  index += 1

nc_impacted = pd.DataFrame(parsed_data_nc_impacted).dropna(axis='columns', how='all')

if not nc_impacted.empty:
  #Cast column to string.
  nc_impacted['compliancequest__SQX_Impacted_Part__r_compliancequest__Active__c'] = nc_impacted['compliancequest__SQX_Impacted_Part__r_compliancequest__Active__c'].astype(str)
  if 'compliancequest__Lot_Quantity__c' in nc_impacted.columns:
      nc_impacted['compliancequest__Lot_Quantity__c'] = nc_impacted['compliancequest__Lot_Quantity__c'].astype(str)

  df_nc_impacted = spark.createDataFrame(nc_impacted)

  df_nc_impacted = df_nc_impacted.withColumn("INSERTED_AT", current_timestamp())

  df_nc_impacted.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_ImpactedPartLotRecords')

# COMMAND ----------

#Adding json data to NC_relatedFindingResponseRecords table
parsed_data_nc_response = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:

  response_size = len(data[0]['NC_Records'][index]['relatedFindingResponseRecords'])
  response_index = 0

  if response_size != 0:
    while response_index < response_size:
            parsed_data_nc_response["attributes_type"].append(data[0]['NC_Records'][index]['relatedFindingResponseRecords'][response_index]["attributes"]["type"])
            parsed_data_nc_response["attributes_url"].append(data[0]['NC_Records'][index]['relatedFindingResponseRecords'][response_index]["attributes"]["url"])
            parsed_data_nc_response["Id"].append(data[0]['NC_Records'][index]['relatedFindingResponseRecords'][response_index]["Id"])
            parsed_data_nc_response["compliancequest__Published_Date__c"].append(data[0]['NC_Records'][index]['relatedFindingResponseRecords'][response_index]["compliancequest__Published_Date__c"])
            parsed_data_nc_response["compliancequest__SQX_Nonconformance__c"].append(data[0]['NC_Records'][index]['relatedFindingResponseRecords'][response_index]["compliancequest__SQX_Nonconformance__c"])
                        
            response_index += 1

  index += 1

nc_response = pd.DataFrame(parsed_data_nc_response).dropna(axis='columns', how='all')

if not nc_response.empty:
  df_nc_response = spark.createDataFrame(nc_response)
  df_nc_response = df_nc_response.withColumn("INSERTED_AT", current_timestamp())
  df_nc_response.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_FindingResponseRecords')

# COMMAND ----------

#Adding json data to NC_relatedAdditionalSites table
parsed_data_nc_sites = defaultdict(list)

nc_size = len(data[0]['NC_Records'])

index = 0

while index < nc_size:

  none_record = data[0]['NC_Records'][index]['relatedAdditionalSites']
  
  if none_record != None:
    sites_size = len(data[0]['NC_Records'][index]['relatedAdditionalSites'])
  else:
    sites_size = 1
  
  sites_index = 0

  if sites_size != 0 and none_record != None:
    while sites_index < sites_size:
            parsed_data_nc_sites["attributes_type"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["attributes"]["type"])
            parsed_data_nc_sites["attributes_url"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["attributes"]["url"])
            parsed_data_nc_sites["Id"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["Id"])
            parsed_data_nc_sites["CQ_JNJ_Nonconformance__c"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["CQ_JNJ_Nonconformance__c"])

            if data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index].get('CQ_JNJ_J_J_Site_Name__r') != None:
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_attributes_type"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["CQ_JNJ_J_J_Site_Name__r"]["attributes"]["type"])
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_attributes_url"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["CQ_JNJ_J_J_Site_Name__r"]["attributes"]["url"])
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_Id"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["CQ_JNJ_J_J_Site_Name__r"]["Id"])
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_Name"].append(data[0]['NC_Records'][index]['relatedAdditionalSites'][sites_index]["CQ_JNJ_J_J_Site_Name__r"]["Name"])
            else:
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_attributes_type"].append(None)
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_attributes_url"].append(None)
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_Id"].append(None)
              parsed_data_nc_sites["CQ_JNJ_J_J_Site_Name__r_Name"].append(None)
                        
            sites_index += 1

  index += 1

nc_sites = pd.DataFrame(parsed_data_nc_sites).dropna(axis='columns', how='all')

if not nc_sites.empty:
  df_nc_sites = spark.createDataFrame(nc_sites)
  df_nc_sites = df_nc_sites.withColumn("INSERTED_AT", current_timestamp())
  df_nc_sites.write.format("delta").mode("append").saveAsTable('SQA.COMET_NC_AdditionalSites')

# COMMAND ----------

# MAGIC %md
# MAGIC ##CAPA Tables

# COMMAND ----------

#Adding json data to CAPA_DETAILS table
parsed_data_capa = defaultdict(list)

nc_size = len(data[1]['CAPA_Records'])

index = 0

while index < nc_size:
  parsed_data_capa["attributes_type"].append(data[1]['CAPA_Records'][index]['CapaDetails']["attributes"]["type"])
  parsed_data_capa["attributes_url"].append(data[1]['CAPA_Records'][index]['CapaDetails']["attributes"]["url"])
  parsed_data_capa["Id"].append(data[1]['CAPA_Records'][index]['CapaDetails']["Id"])
  parsed_data_capa["Name"].append(data[1]['CAPA_Records'][index]['CapaDetails']["Name"])
  parsed_data_capa["compliancequest__SQX_Source_NC__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__SQX_Source_NC__c"])
  parsed_data_capa["compliancequest__Title__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__Title__c"])
  parsed_data_capa["compliancequest__Status__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__Status__c"])
  parsed_data_capa["compliancequest__Record_Stage__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__Record_Stage__c"])
  parsed_data_capa["CreatedDate"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CreatedDate"])
  parsed_data_capa["CreatedById"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CreatedById"])
  parsed_data_capa["LastModifiedDate"].append(data[1]['CAPA_Records'][index]['CapaDetails']["LastModifiedDate"])
  parsed_data_capa["LastModifiedById"].append(data[1]['CAPA_Records'][index]['CapaDetails']["LastModifiedById"])
  parsed_data_capa["OwnerId"].append(data[1]['CAPA_Records'][index]['CapaDetails']["OwnerId"])
  parsed_data_capa["compliancequest__Due_Date_Investigation__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__Due_Date_Investigation__c"])
  parsed_data_capa["compliancequest__Org_Site__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__Org_Site__c"])
  parsed_data_capa["CQ_JNJ_Functional_Area__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CQ_JNJ_Functional_Area__c"])
  parsed_data_capa["CQ_JNJ_Functional_Area_1__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CQ_JNJ_Functional_Area_1__c"])
  parsed_data_capa["CQ_JNJ_Functional_Area_2__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CQ_JNJ_Functional_Area_2__c"])
  parsed_data_capa["RecordTypeId"].append(data[1]['CAPA_Records'][index]['CapaDetails']["RecordTypeId"])
  parsed_data_capa["CreatedBy_type"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CreatedBy"]["attributes"]["type"])
  parsed_data_capa["CreatedBy_url"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CreatedBy"]["attributes"]["url"])
  parsed_data_capa["CreatedBy_Id"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CreatedBy"]["Id"])
  parsed_data_capa["CreatedBy_Name"].append(data[1]['CAPA_Records'][index]['CapaDetails']["CreatedBy"]["Name"])
  parsed_data_capa["LastModifiedBy_type"].append(data[1]['CAPA_Records'][index]['CapaDetails']["LastModifiedBy"]["attributes"]["type"])
  parsed_data_capa["LastModifiedBy_url"].append(data[1]['CAPA_Records'][index]['CapaDetails']["LastModifiedBy"]["attributes"]["url"])
  parsed_data_capa["LastModifiedBy_Id"].append(data[1]['CAPA_Records'][index]['CapaDetails']["LastModifiedBy"]["Id"])
  parsed_data_capa["LastModifiedBy_Name"].append(data[1]['CAPA_Records'][index]['CapaDetails']["LastModifiedBy"]["Name"])
  parsed_data_capa["Owner_type"].append(data[1]['CAPA_Records'][index]['CapaDetails']["Owner"]["attributes"]["type"])
  parsed_data_capa["Owner_url"].append(data[1]['CAPA_Records'][index]['CapaDetails']["Owner"]["attributes"]["url"])
  parsed_data_capa["Owner_Id"].append(data[1]['CAPA_Records'][index]['CapaDetails']["Owner"]["Id"])
  parsed_data_capa["Owner_Name"].append(data[1]['CAPA_Records'][index]['CapaDetails']["Owner"]["Name"])
  parsed_data_capa["compliancequest__Org_Business_Unit__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__Org_Business_Unit__c"])
  parsed_data_capa["compliancequest__Closed_Date__c"].append(data[1]['CAPA_Records'][index]['CapaDetails']["compliancequest__Closed_Date__c"])

  index += 1

capa_details = pd.DataFrame(parsed_data_capa).dropna(axis='columns', how='all')

if not capa_details.empty:
  df_capa_details = spark.createDataFrame(capa_details)
  df_capa_details = df_capa_details.withColumn("INSERTED_AT", current_timestamp())
  df_capa_details.write.format("delta").mode("append").saveAsTable('SQA.COMET_CAPA_DETAILS')

# COMMAND ----------

#Adding json data to CAPA_ResponseApprovalRecords table
parsed_data_capa_rar = defaultdict(list)

capa_size = len(data[1]['CAPA_Records'])

index = 0

while index < capa_size:

  rar_size = len(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'])
  rar_index = 0

  if rar_size != 0:
    while rar_index < rar_size:
        parsed_data_capa_rar["attributes_type"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["attributes"]["type"])
        parsed_data_capa_rar["attributes_url"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["attributes"]["url"])
        parsed_data_capa_rar["Id"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["Id"])
        parsed_data_capa_rar["compliancequest__SQX_CAPA__c"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["compliancequest__SQX_CAPA__c"])
        parsed_data_capa_rar["compliancequest__Step__c"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["compliancequest__Step__c"])
        parsed_data_capa_rar["compliancequest__SQX_User__c"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["compliancequest__SQX_User__c"])
        parsed_data_capa_rar["compliancequest__SQX_User__r_attributes_type"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["compliancequest__SQX_User__r"]["attributes"]["type"])
        parsed_data_capa_rar["compliancequest__SQX_User__r_attributes_url"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["compliancequest__SQX_User__r"]["attributes"]["url"])
        parsed_data_capa_rar["compliancequest__SQX_User__r_Id"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["compliancequest__SQX_User__r"]["Id"])
        parsed_data_capa_rar["compliancequest__SQX_User__r_Name"].append(data[1]['CAPA_Records'][index]['relatedResponseApprovalRecords'][rar_index]["compliancequest__SQX_User__r"]["Name"])

        rar_index += 1

  index += 1

capa_rar = pd.DataFrame(parsed_data_capa_rar).dropna(axis='columns', how='all')

if not capa_rar.empty:
  #Cast column to string.
  capa_rar['compliancequest__Step__c'] = capa_rar['compliancequest__Step__c'].astype(str)
  #Create spark dataframe
  df_capa_rar = spark.createDataFrame(capa_rar)
  df_capa_rar = df_capa_rar.withColumn("INSERTED_AT", current_timestamp())
  df_capa_rar.write.format("delta").mode("append").saveAsTable('SQA.COMET_CAPA_ResponseApprovalRecords')

# COMMAND ----------

#Adding json data to CAPA_relatedInvestigationRecords table
parsed_data_capa_investigation = defaultdict(list)

capa_size = len(data[1]['CAPA_Records'])

index = 0

while index < capa_size:

  investigation_size = len(data[1]['CAPA_Records'][index]['relatedInvestigationRecords'])
  investigation_index = 0

  if investigation_size != 0:
    while investigation_index < investigation_size:
            parsed_data_capa_investigation["attributes_type"].append(data[1]['CAPA_Records'][index]['relatedInvestigationRecords'][investigation_index]["attributes"]["type"])
            parsed_data_capa_investigation["attributes_url"].append(data[1]['CAPA_Records'][index]['relatedInvestigationRecords'][investigation_index]["attributes"]["url"])
            parsed_data_capa_investigation["Id"].append(data[1]['CAPA_Records'][index]['relatedInvestigationRecords'][investigation_index]["Id"])
            parsed_data_capa_investigation["compliancequest__SQX_CAPA__c"].append(data[1]['CAPA_Records'][index]['relatedInvestigationRecords'][investigation_index]["compliancequest__SQX_CAPA__c"])
            parsed_data_capa_investigation["compliancequest__Completed_On__c"].append(data[1]['CAPA_Records'][index]['relatedInvestigationRecords'][investigation_index]["compliancequest__Completed_On__c"])
            
            investigation_index += 1

  index += 1

capa_investigation = pd.DataFrame(parsed_data_capa_investigation).dropna(axis='columns', how='all')

if not capa_investigation.empty:
  df_capa_investigation = spark.createDataFrame(capa_investigation)
  df_capa_investigation = df_capa_investigation.withColumn("INSERTED_AT", current_timestamp())
  df_capa_investigation.write.format("delta").mode("append").saveAsTable('SQA.COMET_CAPA_InvestigationRecords')

# COMMAND ----------

#Adding json data to CAPA_relatedImpactedPartLotRecords table
parsed_data_capa_impacted = defaultdict(list)

capa_size = len(data[1]['CAPA_Records'])

index = 0

while index < capa_size:

  impacted_size = len(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'])
  impacted_index = 0

  if impacted_size != 0:
    while impacted_index < impacted_size:
            parsed_data_capa_impacted["attributes_type"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["attributes"]["type"])
            parsed_data_capa_impacted["attributes_url"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["attributes"]["url"])
            parsed_data_capa_impacted["Id"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["Id"])
            parsed_data_capa_impacted["CQ_JNJ_Vendor_Supplier_Number__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Vendor_Supplier_Number__c"])
            parsed_data_capa_impacted["CQ_JNJ_Manufacture_Source_Number__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Manufacture_Source_Number__c"])
            parsed_data_capa_impacted["CQ_JNJ_Manufacturer_Source_Name__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Manufacturer_Source_Name__c"])
            parsed_data_capa_impacted["CQ_JNJ_Source_System__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Source_System__c"])
            parsed_data_capa_impacted["CQ_JNJ_Material_Item__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Material_Item__c"])
            parsed_data_capa_impacted["compliancequest__Lot_Number__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__Lot_Number__c"])
            parsed_data_capa_impacted["compliancequest__SQX_Nonconformance__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Nonconformance__c"])
            parsed_data_capa_impacted["CQ_JNJ_Material_Description__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Material_Description__c"])
            parsed_data_capa_impacted["CQ_JNJ_Product_Grouping__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Product_Grouping__c"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__c"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_attributes_type"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["attributes"]["type"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_attributes_url"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["attributes"]["url"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_Id"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Id"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_OwnerId"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["OwnerId"])
            #parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Part_Description__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Part_Description__c"])
            #parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_CQ_JNJ_Source__c"].append(data[0]['NC_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["CQ_JNJ_Source__c"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Part_Number__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Part_Number__c"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Active__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Active__c"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_compliancequest__Part_Family__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["compliancequest__Part_Family__c"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_Name"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Name"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_Owner_attributes_type"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["attributes"]["type"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_Owner_attributes_url"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["attributes"]["url"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_Owner_Id"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["Id"])
            parsed_data_capa_impacted["compliancequest__SQX_Impacted_Part__r_Owner_Name"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__SQX_Impacted_Part__r"]["Owner"]["Name"])
            parsed_data_capa_impacted["CQ_JNJ_Decision_Date__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Decision_Date__c"])
            parsed_data_capa_impacted["compliancequest_SQX_CAPA__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest_SQX_CAPA__c"])
            parsed_data_capa_impacted["CQ_JNJ_Disposition_Details__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Disposition_Details__c"])
            parsed_data_capa_impacted["CQ_JNJ_Disposition_Type__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Disposition_Type__c"])
            parsed_data_capa_impacted["CQ_JNJ_Release_from_Investigation__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Release_from_Investigation__c"])
            parsed_data_capa_impacted["CQ_JNJ_Qty_Unit_of_Measure__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Qty_Unit_of_Measure__c"])
            parsed_data_capa_impacted["CQ_JNJ_Material_Continuation_Decision__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["CQ_JNJ_Material_Continuation_Decision__c"])
            parsed_data_capa_impacted["compliancequest__Lot_Quantity__c"].append(data[1]['CAPA_Records'][index]['relatedImpactedPartLotRecords'][impacted_index]["compliancequest__Lot_Quantity__c"])
            
            
            impacted_index += 1

  index += 1

capa_impacted = pd.DataFrame(parsed_data_capa_impacted).dropna(axis='columns', how='all')

if not capa_impacted.empty:
  #Cast column to string.
  capa_impacted['compliancequest__SQX_Impacted_Part__r_compliancequest__Active__c'] = capa_impacted['compliancequest__SQX_Impacted_Part__r_compliancequest__Active__c'].astype(str)
  if 'compliancequest__Lot_Quantity__c' in capa_impacted.columns:
    capa_impacted['compliancequest__Lot_Quantity__c'] = capa_impacted['compliancequest__Lot_Quantity__c'].astype(str)
  df_capa_impacted = spark.createDataFrame(capa_impacted)
  df_capa_impacted = df_capa_impacted.withColumn("INSERTED_AT", current_timestamp())
  df_capa_impacted.write.format("delta").mode("append").saveAsTable('SQA.COMET_CAPA_ImpactedPartLotRecords')

# COMMAND ----------

#Adding json data to CAPA_relatedFindingResponseRecords table
parsed_data_capa_response = defaultdict(list)

capa_size = len(data[1]['CAPA_Records'])

index = 0

while index < capa_size:

  response_size = len(data[1]['CAPA_Records'][index]['relatedFindingResponseRecords'])
  response_index = 0

  if response_size != 0:
    while response_index < response_size:
            parsed_data_capa_response["attributes_type"].append(data[1]['CAPA_Records'][index]['relatedFindingResponseRecords'][response_index]["attributes"]["type"])
            parsed_data_capa_response["attributes_url"].append(data[1]['CAPA_Records'][index]['relatedFindingResponseRecords'][response_index]["attributes"]["url"])
            parsed_data_capa_response["Id"].append(data[1]['CAPA_Records'][index]['relatedFindingResponseRecords'][response_index]["Id"])
            parsed_data_capa_response["compliancequest__Published_Date__c"].append(data[1]['CAPA_Records'][index]['relatedFindingResponseRecords'][response_index]["compliancequest__Published_Date__c"])
            parsed_data_capa_response["compliancequest__SQX_CAPA__c"].append(data[1]['CAPA_Records'][index]['relatedFindingResponseRecords'][response_index]["compliancequest__SQX_CAPA__c"])
                        
            response_index += 1

  index += 1

capa_response = pd.DataFrame(parsed_data_capa_response).dropna(axis='columns', how='all')

if not capa_response.empty:
  df_capa_response = spark.createDataFrame(capa_response)
  df_capa_response = df_capa_response.withColumn("INSERTED_AT", current_timestamp())
  df_capa_response.write.format("delta").mode("append").saveAsTable('SQA.COMET_CAPA_FindingResponseRecords')