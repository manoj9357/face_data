# Databricks notebook source
from pyspark.sql import Row

row=Row('maheer',2000)
print(row[0]+' '+str(row[1]))

# COMMAND ----------

# MAGIC %md
# MAGIC # **_Row() Class Object_**

# COMMAND ----------

row1=Row(name='maheer',salary=2000)
print(row1.name+" "+ str(row1.salary))

# COMMAND ----------

from pyspark.sql import Row

row1=Row(name='Manoj',salary=2000)
row2=Row(name="Srinjoy",salary=5000)
print(row1.name+" "+str(row1.salary)+" and "+row2.name+" "+str(row2.salary))
row3=Row("manoj",2000)
row4=("srinjoy",5000)
print(row1[0]+" "+str(row1[1])+" and "+row2[0]+" "+str(row2[1]))

# COMMAND ----------

data=[row1,row2]#,row3,row4]--columns are not defined for row3 and row4
df=spark.createDataFrame(data)
df.show()
display(df)

# COMMAND ----------

#Person=Row(name,salary)--need to define the data type as well
Person=Row('name','salary')
p1=Person("manoj",2000)
p2=Person("srinjoy",5000)
print(p1.name+" "+str(p1.salary))
# data1=[p1,p2]
# df1=spark.createDataFrame(data)
df1=spark.createDataFrame([p1,p2])
df1.show()
df1.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **_Nested Struct type using Row() class Object_**

# COMMAND ----------

from pyspark.sql import Row

data=[Row(name="manoj",properties=Row(hair="black",eye="blue")),
      Row(name='srinjoy',properties=Row(hair='grey',eye='black'))]
df=spark.createDataFrame(data)
df.show()
df.display()
df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC # **_Column Class Object using lit()_**

# COMMAND ----------

from pyspark.sql.functions import lit

col1=lit("abcd")
print(type(col1))

# COMMAND ----------

data=[('Manoj','Male',2000),('Srinjoy','Male',500)]
schema=['name','gender','salary']
df=spark.createDataFrame(data,schema)
df.show()
df.display()

# COMMAND ----------

df1=df.withColumn("status",lit("active"))
df1.show()
df1.display()

# COMMAND ----------

# MAGIC %md
# MAGIC # **_Access Column from Dataframe_**

# COMMAND ----------

from pyspark.sql.functions import lit
from pyspark.sql.types import StringType,StructType,StructField,IntegerType

data=[("manoj","male",("black","blue")),('srinjoy','male',('grey','black')),\
      ("mansi","female",("black",'black'))]

PropsType=StructType([\
    StructField('hair',StringType()),\
        StructField('eyes',StringType())])

schema=StructType([\
    StructField('name',StringType()),\
    StructField('gender',StringType()),\
    StructField('properties',PropsType)])

df=spark.createDataFrame(data,schema)
df.show()
df.display()

# COMMAND ----------

from pyspark.sql.functions import col
df.select(df.name).show()
df.select(df.name).show(2)
df.select(df['name']).show()
df.select(col('name')).show()
df.select(df.properties.hair).show()
df.select(df['properties.eyes']).show()
df.select(col('properties.hair')).show()

# COMMAND ----------

rows=df.collect()
print(rows)
print('\n')
print(rows[0]['name'])
threerows=df.take(3)
print(threerows)
print('\n')
firstrow=df.first() #or df.head()
print(firstrow)
print('\n')
lastrow=df.tail(1)
print(lastrow[0]['name'])
lastrow=df.tail(1)[0]
print(lastrow['name'])

# COMMAND ----------

# MAGIC %md
# MAGIC # **_pivot() dataframe_**

# COMMAND ----------

from pyspark.sql.functions import expr
data=[(1,'mahi','male','it'),\
      (2,'waf','male','it'),
      (3,'asi','female','hr'),
      (4,'annu','female','it'),
      (5,'shakti','female','it'),
      (6,'pradeep','male','hr'),
      (7,'sarf','male','hr'),
      (8,'ayesha','female','it')
      ]

schema=['id','name','gender','dep']
df=spark.createDataFrame(data,schema)
df.show()
df.groupBy('dep').count().show()
df.groupBy('dep','gender').count().show()
pivotDf=df.groupBy('dep').pivot('gender').count()
pivotDf.show()
df.groupBy('dep').pivot('gender',['male']).count().show()

unpivotDf=pivotDf.select('dep',expr("stack(2,'M',Male,'F',Female) as (gender,count)"))
unpivotDf.show()

# COMMAND ----------

data=[('it',8,5),
      ('payroll',3,2),
      ('hr',2,4)
      ]
schema=['dep','male','female']
df=spark.createDataFrame(data,schema)
df.show()

from pyspark.sql.functions import expr
df.select('dep',expr("stack(2,'male',male,'female',female) as (gender,count)")).show()

# COMMAND ----------

unpivotedDf=df.select('dep',expr("stack(2,'m',male,'f',female) as (gender,count)"))
unpivotedDf.show()

# COMMAND ----------

data=[(1,'mahi','male',1000,None),(2,'asi','female',2000,'it'),(3,'abcd',None,1000,'hr')]
schema=['id','name','gender','salary','dep']

df=spark.createDataFrame(data,schema)
df.show()

datarows=df.collect()
print(datarows)
print(datarows[0])
print(datarows[0][1])

# COMMAND ----------

# MAGIC %md
# MAGIC # **_Dataframe transform()_**

# COMMAND ----------

