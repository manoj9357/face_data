# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ****************NEED TO PAUSE APPROVAL DATA JOB****************

# COMMAND ----------

# MAGIC %md 
# MAGIC custom_timestamp format must be YYYY-MM-DD HH:MM:SS

# COMMAND ----------

dbutils.widgets.text(name='custom_timestamp', defaultValue = '',label='NOT REQUIRED')
dbutils.widgets.text(name='Maintenance_strt_time', defaultValue = '',label='YYYY-MM-DD HH:MM:SS.000000  Maintenance window Start Time')
dbutils.widgets.text(name='Maintenance_end_time', defaultValue = '',label='YYYY-MM-DD HH:MM:SS.000000   Maintenance window End Time')

# COMMAND ----------

Start_Time = dbutils.widgets.get("Maintenance_strt_time") 
End_Time = dbutils.widgets.get("Maintenance_end_time") 
print(Start_Time)
print(End_Time)

# COMMAND ----------

spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

# COMMAND ----------

# MAGIC %run /Workspace/Shared/SQA/Packages/sqif_Framework

# COMMAND ----------

from datetime import datetime, timedelta


def convert_to_local_timezone(site, date_to_convert):
  site_upperCase = site.upper()
  if not date_to_convert:
    return
  
  try:
    print('date_to_convert: {}'.format(date_to_convert))
    date_to_convert = datetime.strptime(date_to_convert, '%d-%b-%y')
  except: 
    print('date_to_convert: {}'.format(date_to_convert))
    date_to_convert = datetime.strptime(date_to_convert[0:-4], '%Y%m%d%H%M%S%f')
    
  print(date_to_convert)
  difference = 0
  if site_upperCase == 'APDC':
    difference = 3.5;
  elif site_upperCase == 'FUJI_FF':
    difference = 7
  elif site_upperCase == 'XIANNEW_FF':
    difference = 6
  elif site_upperCase == 'EBS_TELHASHOMER':
    difference = 1
  elif site_upperCase == 'CORK':
    difference = -1
  elif site_upperCase == 'CORK_API-L':
    difference = -1
  elif site == 'SAO JOSE DOS CAMPOS':
    difference = -5
  elif site_upperCase == 'SAO JOSE - CONSUMER':
    difference = -5
  elif site_upperCase == 'SAO JOSE - MD':
    difference = -5
  elif site_upperCase == 'ATHENS':
    difference = -6
  elif site_upperCase == 'GURABO':
    difference = -6
  elif site_upperCase == 'GURABO ORTHO':
    difference = -6
  elif site_upperCase == 'RARITAN':
    difference = -6
  elif site_upperCase == 'RARITAN_API-L':
    difference = -6
  elif site_upperCase == 'RARITAN_CAR-T':
    difference = -6
  elif site_upperCase == 'TITUSVILLE':
    difference = -6
  elif site_upperCase == 'PUEBLA':
    difference = -7
  elif site_upperCase == 'MALVERN_API-L':
    difference = -9
  elif site_upperCase == 'VACAVILLE':
    difference = -9
  elif site_upperCase == 'MANATI':
    difference = -6
  elif site_upperCase == 'MANATI_API-L':
    difference = -6
  elif site_upperCase == 'HYANGNAM_FF':
    difference = 7
  elif site_upperCase == 'INCHEON_VACCINES':
    difference = 7
  converted_date = date_to_convert + timedelta(hours=difference)
  return converted_date.strftime('%m/%d/%Y %H:%M:%S')

spark.udf.register('convert_to_local_timezone', convert_to_local_timezone)

# COMMAND ----------

custom_time = dbutils.widgets.get("custom_timestamp")  
elims_approval_data_config = ""
custom_date_set = False
if custom_time:
  try:
    custom_time = datetime.strptime(custom_time, '%Y-%m-%d %H:%M:%S')
    elims_approval_data_config = custom_time
    custom_date_set = True
  except Exception as e:
    elims_approval_data_config = (spark.sql("select * from SQA.ELIMS_APPROVAL_DATA where NAME = 'APPROVAL_DATA'").first()).LAST_TIMESTAMP
else:
  elims_approval_data_config = (spark.sql("select * from SQA.ELIMS_APPROVAL_DATA where NAME = 'APPROVAL_DATA'").first()).LAST_TIMESTAMP
  

# COMMAND ----------

query = """
select 
  case 
    when s.allocatedfordepartmentid = 'Schaffhausen Pharma' then 'Schaffhausen'
    when s.allocatedfordepartmentid = 'Cork_API-L' then 'Corkbio'
	when s.allocatedfordepartmentid = 'Gurabo Ortho' then 'Gurabo'
    when s.allocatedfordepartmentid = 'Leiden_API-L' then 'Leiden'
    when s.allocatedfordepartmentid = 'Malvern_API-L' then 'Malvern'
    when s.allocatedfordepartmentid = 'Sao Jose dos Campos' then 'Brazil'
    when s.allocatedfordepartmentid = 'XianNew_FF' then 'Xian'
    when s.allocatedfordepartmentid =  'Incheon_Vaccines' then 'Incheon'
  else s.allocatedfordepartmentid end as TENANT_ID,
  s.s_sampleid as SAMPLE_ID,
  convert_to_local_timezone(s.allocatedfordepartmentid, nvl(CASE WHEN s.u_verifieddt = '0000000000' THEN NULL ELSE s.u_verifieddt END, s.u_canceldt)) as APPROVALDATE
from cdl_prod_l0_elims.vnd_s_sample s 
where 
    s.samplestatus in ('Cancelled','Completed')  
    AND s.u_lotid is not null 
    AND s.u_qc_orderid is not null
AND s.sampletypeid <> 'NoSample'
AND(
        (
            s.sampletypeid in ('Additional','AutoComplete','Composite Additional','Composite Retain','CompositeMin5-Addit','CompositeMin5-Retain','Reference','Retain','Retain Pack Flag','Retain-sealed','StabilityRequest','Subbatch Retain')
             AND s.allocatedfordepartmentid in ('Cork','Geel','Schaffhausen Pharma','Latina','Cork_API-L','Gurabo','Gurabo Ortho','Leiden_API-L','Malvern_API-L', 'Sao Jose dos Campos','XianNew_FF','Athens','Fuji_FF','Incheon_Vaccines','Puebla')
        )
        OR 
        (
            s.allocatedfordepartmentid = 'Beerse'
            AND (s.u_lab IN ('B_IQA','B_QA','B_QA2','B_EXC_RET','B_HG-FG_RET','B_PM_RET','B_EXC_ADD','B_PM_ADD','B_HG-FG_RET_SEAL','B_HG-FG_STAB','B_SAMPLE MNGT','B_PHAST') or s.sampletypeid = 'LabResult')
        )
        OR (s.allocatedfordepartmentid = 'Geel' and s.u_lab not like 'G_%' and s.u_lotid is not null)
    )
    AND (
      (to_timestamp(nvl(s.u_verifieddt, s.u_canceldt), 'yyyyMMddHHmmssSS') >= (to_timestamp('{Start_Time}') - interval '40' minute) 
      or to_timestamp(nvl(s.u_verifieddt, s.u_canceldt), 'dd-MMM-yy') >= (to_timestamp('{Start_Time}') - interval '40' minute) )
      AND 
      (to_timestamp(nvl(s.u_verifieddt, s.u_canceldt), 'yyyyMMddHHmmssSS') <= (to_timestamp('{End_Time}') - interval '40' minute) 
      or to_timestamp(nvl(s.u_verifieddt, s.u_canceldt), 'dd-MMM-yy') <= (to_timestamp('{End_Time}') - interval '40' minute) )
      )
""".format(last_time=elims_approval_data_config,Start_Time=Start_Time,End_Time=End_Time)

print(query)
# print(elims_approval_data_config)

# COMMAND ----------

#mount_point = dbutils.secrets.get('sqa', 'sqa_mount_point')
sqif = Framework()

# COMMAND ----------

if not custom_date_set:
  sqif.update_processing_state('APPROVAL_DATA', 'SQA.ELIMS_APPROVAL_DATA')

# COMMAND ----------

#sqif.mount()
df = sqif.to_df(query)

# COMMAND ----------

df_results_count = df.count()
print('Result Count: ', df_results_count)

# COMMAND ----------

if df_results_count==0:
  print('Zero results, updating config')
  sqif.update_config(None, 'APPROVAL_DATA', 'SQA.ELIMS_APPROVAL_DATA')
  dbutils.notebook.exit('Zero results, exiting')

# COMMAND ----------

print('converting to csv')
filename = sqif.to_csv(df, 'elims_approval_data')

# COMMAND ----------

try:
  print('sftping')
  sftp_result = sqif.sftp(filename, 'approve')
except:
  dbutils.notebook.exit('Unable to SFTP, exiting')

# print('sftp_result: {}'.format(sftp_result))

# COMMAND ----------

print('Moving the CSV to archive')
sqif.move_csv_to_archive(filename,'elims_approval_data')

# COMMAND ----------

if not custom_date_set:
  print('updating config')
  sqif.update_config(filename, 'APPROVAL_DATA', 'SQA.ELIMS_APPROVAL_DATA')

# COMMAND ----------

dbutils.notebook.exit(filename)