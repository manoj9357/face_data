# Databricks notebook source
key = dbutils.secrets.get(scope = 'sqacdl_prod_scope', key = 'sqacdl_L1_client')
print(key[0:2])
print(key[1:1000])

# COMMAND ----------

archive_path = dbutils.secrets.get('sqa', 'sqa_archive_location') 
print(archive_path[0:2])
print(archive_path[1:1000])

# COMMAND ----------

https://adb-6803967472078692.12.azuredatabricks.net/sqa/archive/comet_csv_file/comet_nc_capa_csv_file-1728900693537.csv

# COMMAND ----------

# archive_path = dbutils.secrets.get('sqa', 'sqa_archive_location') 
archive_path='dbfs:/FileStore/sqa/archive/comet_csv_file/comet_nc_capa_csv_file-1728900693537.csv'

# Load the CSV into a DataFrame
df = spark.read.csv(archive_path, header=True, inferSchema=True)

display(df)

# COMMAND ----------

# archive_path = dbutils.secrets.get('sqa', 'sqa_archive_location') 
archive_path='dbfs:/FileStore/sqa/archive/comet_csv_file/comet_nc_capa_csv_file-1728918694290.csv'

# Load the CSV into a DataFrame
df = spark.read.csv(archive_path, header=True, inferSchema=True)

display(df)

# COMMAND ----------

# archive_path = dbutils.secrets.get('sqa', 'sqa_archive_location') 
archive_path='dbfs:/FileStore/sqa/archive/comet_csv_file/comet_nc_capa_csv_file-1729678298937.csv'

# Load the CSV into a DataFrame
df = spark.read.csv(archive_path, header=True, inferSchema=True)

display(df)

# COMMAND ----------

# MAGIC %fs 
# MAGIC ls dbfs:/FileStore/sqa/archive/comet_csv_file/comet_nc_capa_csv_file-1728900693537.csv

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/FileStore/sqa/archive/comet_csv_file/comet_nc_capa_csv_file-1728900693537.csv

# COMMAND ----------

# MAGIC %fs head dbfs:/FileStore/sqa/archive/comet_csv_file/comet_nc_capa_csv_file-1728900693537.csv

# COMMAND ----------

Grun_time = float((filename.split('-')[-1])[:-4])     
      run_time_str = '{}'.format(dt.fromtimestamp(run_time/1000.0))
      timestamp = (spark.sql("select to_timestamp('{}') as tmp".format(run_time_str)).first()).tmp
      spark.sql("UPDATE {} set LAST_TIMESTAMP = '{}', PROCESSING = false where NAME = '{}'".format(table, timestamp, name))

# COMMAND ----------

from datetime import datetime as dt
filename='comet_nc_capa_csv_file-1716459085494.csv'
run_time = float((filename.split('-')[-1])[:-4])  
print(run_time)
run_time_str = '{}'.format(dt.fromtimestamp(run_time/1000.0))
print(run_time_str)

# COMMAND ----------

import datetime
import time
run_time = int(time.time() * 1000)
print(run_time)
print(time.time())

# COMMAND ----------

from datetime import datetime

# Given timestamp (in ISO 8601 format)
timestamp_str = "2024-03-27 03:11:18.808000"

# Convert the timestamp string to a datetime object
dt_object = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S.%f")

# Convert the datetime object to a timestamp (in milliseconds)
timestamp_ms = int(dt_object.timestamp() * 1000)

# Create the filename using the timestamp
filename = f"csv_file-{timestamp_ms}.csv"

print(f"Generated filename: {filename}")


# COMMAND ----------

timestamp = (spark.sql("select to_timestamp('{}') as tmp".format(run_time_str)).first()).tmp
print(timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.ATLAS_BATCH_GENEALOGY_HISTORY
# MAGIC order by INSERTED_AT desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.atlas_upcoming_batches_history where BATCH_NO like ('%24BG0945%') or BATCH_NO like ('%24BG0946%')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.atlas_BATCH_GENEALOGY_HISTORY where TENANT_ID in ('1300','1700') and 
# MAGIC MFG_LOT_NUMBER in ('24BG0945','24BG0946') order by INSERTED_AT desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.BATCH_GENEALOGY_HISTORY
# MAGIC -- where
# MAGIC -- -- --source = 'atl'
# MAGIC -- -- --and
# MAGIC -- tenant_id in ('1300', '1700')
# MAGIC -- and
# MAGIC -- PARENT_NO like ('%24DG856%')--, '24BG0945', '24DG856')
# MAGIC -- or SUBLOT_NO like ('%24BG0946%')
# MAGIC -- order by INSERTED_AT desc
# MAGIC -- ETL_ID in (1763965708,1763965708)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.atlas_BATCH_GENEALOGY_HISTORY
# MAGIC where
# MAGIC --source = 'atl'
# MAGIC --and
# MAGIC tenant_id in ('1300', '1700')
# MAGIC and
# MAGIC MFG_LOT_NUMBER in ('24BG0946', '24BG0945', '24DG856')
# MAGIC order by INSERTED_AT desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.ATLAS_BATCH_GENEALOGY

# COMMAND ----------

# MAGIC %sql
# MAGIC  SELECT  
# MAGIC          gen.INP_PLNT_NUM AS TENANT_ID
# MAGIC        , CONCAT(INP_MATL_NUM, '-', gen.INP_BTCH_NUM) AS PARENT_NO
# MAGIC        , CONCAT(gen.OUTP_MATL_NUM, '-', gen.OUTP_BTCH_NUM) AS SUBLOT_NO
# MAGIC  FROM atlas_new_batches batches
# MAGIC  INNER JOIN cdl_prod_l1_batch_genealogy.l1_genealogy gen ON batches.TENANT_ID = gen.INP_PLNT_NUM 
# MAGIC                                    AND batches.MFG_LOT_NUMBER = gen.INP_BTCH_NUM 
# MAGIC                                    AND batches.PRODUCT_ID = gen.INP_MATL_NUM 
# MAGIC  WHERE gen.OUTP_BTCH_NUM IS NOT NULL 
# MAGIC    AND gen.OUTP_BTCH_NUM <> ''
# MAGIC    AND gen.SRC_SYS_CD = 'atl'
# MAGIC UNION 
# MAGIC
# MAGIC  SELECT 
# MAGIC           gen.INP_PLNT_NUM AS TENANT_ID
# MAGIC         , CONCAT(gen.INP_MATL_NUM, '-', gen.INP_BTCH_NUM) AS PARENT_NO
# MAGIC         , CONCAT(gen.OUTP_MATL_NUM, '-', gen.OUTP_BTCH_NUM) AS SUBLOT_NO
# MAGIC  FROM atlas_new_batches batches
# MAGIC  INNER JOIN cdl_prod_l1_batch_genealogy.l1_genealogy gen ON batches.TENANT_ID = gen.OUTP_PLNT_NUM 
# MAGIC                                    AND batches.MFG_LOT_NUMBER = gen.OUTP_BTCH_NUM 
# MAGIC                                    AND batches.PRODUCT_ID = gen.OUTP_MATL_NUM
# MAGIC   WHERE gen.SRC_SYS_CD = 'atl' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.BATCH_GENEALOGY_HISTORY where SUBLOT_NO like ('%927280%') and SUBLOT_NO like ('%24BG0946%')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where BATCH_ID_LOT_NUMBER like ("%370504%")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where BATCH_ID_LOT_NUMBER like ("%24BG0946%")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.elims_sample_data

# COMMAND ----------

# MAGIC %sql
# MAGIC select BATCH_NO,action,MFG_LOT_NUMBER,OPTIONAL_11,OPTIONAL_12,OPTIONAL_13,INSERTED_AT from sqa.europe2_upcoming_batches_history
# MAGIC where
# MAGIC --batch_no in ('376969-NGL7S00','379304-NHL4700','383570-NKL7800') 
# MAGIC batch_no like '%PCB3C' or batch_no like '%PCB36'
# MAGIC order by INSERTED_AT

# COMMAND ----------

# MAGIC %sql
# MAGIC select BATCH_NO,action,OPTIONAL_11,OPTIONAL_12,OPTIONAL_13,INSERTED_AT from sqa.europe2_upcoming_batches_history
# MAGIC where
# MAGIC batch_no in ('376969-NGL7S00','379304-NHL4700','383570-NKL7800') 
# MAGIC order by INSERTED_AT

# COMMAND ----------

# MAGIC %sql
# MAGIC  SELECT jest._createTime_ as JEST_ETL_crt_time, collect_set(user_stat.txt04) as user_stats, concat(regexp_replace(qals.matnr, '^[0]*', ''), '-', qals.charg) as batch_no,
# MAGIC        qals.prueflos as inspection_lot,jest.INACT as inactive_flag
# MAGIC     FROM
# MAGIC     cdl_prod_l0_europe2.qals qals
# MAGIC     inner join cdl_prod_l0_europe2.vnd_jest jest on jest.mandt = qals.mandant and jest.objnr = qals.objnr
# MAGIC     INNER JOIN cdl_prod_l0_europe2.vnd_tj30t user_stat ON jest.mandt = user_stat.mandt
# MAGIC                                        AND jest.stat = user_stat.estat
# MAGIC     INNER JOIN SQA.EUROPE2_USER_STATS stats ON stats.stsma = user_stat.stsma and stats.estat = user_stat.estat
# MAGIC     LEFT JOIN cdl_prod_l0_europe2.vnd_jcds jcds ON jest.mandt = jcds.mandt and jest.stat = jcds.stat and jest.objnr = jcds.objnr and jest.chgnr = jcds.chgnr
# MAGIC     WHERE
# MAGIC     --jest.inact <> 'X'
# MAGIC     --and
# MAGIC     concat(regexp_replace(qals.matnr, '^[0]*', ''), '-', qals.charg) like ('%PCB36') or concat(regexp_replace(qals.matnr, '^[0]*', ''), '-', qals.charg) like ('%PCB3C')
# MAGIC     --and qals.AUFNR like '%20918621'
# MAGIC     AND user_stat.spras = 'E'  
# MAGIC      GROUP BY jest._createTime_, qals.MATNR, qals.CHARG, qals.PRUEFLOS, jest.INACT
# MAGIC    order by jest.`_createTime_`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_upcoming_batches_history
# MAGIC where
# MAGIC TRIMMED_PROCESS_ORDER in ('373471'--, '373788'
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC select mo.id as mfg_order, mo.batch_id as batch, mo.material_id, mo.status_txt as mo_status, so.status_txt as so_status,mo.actual_start_ts, mo.actual_end_ts, sig.type_id, sig.sign_date_ts 
# MAGIC from cdl_make_prod_pasx.manufacturing_order mo 
# MAGIC INNER JOIN cdl_make_prod_pasx.brr brr on brr.order_id = mo.id
# MAGIC inner join cdl_make_prod_pasx.brr_signature sig on sig.brr_sid = brr.brr_sid
# MAGIC inner join cdl_make_prod_pasx.shop_floor_order so on mo.id = so.order_id
# MAGIC where 
# MAGIC mo.id in ('373471','373788')
# MAGIC and sig.type_id like '%Appr%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select BATCH_NO,action,OPTIONAL_11,OPTIONAL_12,OPTIONAL_13,INSERTED_AT from sqa.pandas_upcoming_batches_history
# MAGIC where
# MAGIC batch_no in ('JP383554-A0065','JP419847-NKS35MA','JP419847-NKS35MA')--,'379304-NHL4700','383570-NKL7800') 
# MAGIC order by INSERTED_AT

# COMMAND ----------

base_query = """
-- Fuji – plant code 8111
SELECT 
    mseg.mandt as mandant
  , mseg.werks
  , mseg.matnr
  , mseg.charg
  , makt.maktx
  , qals.prueflos
  , mcha.ersda
  , CASE 
      WHEN mch1.lwedt = '00000000' then mcha.ersda
      ELSE mch1.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , mseg.aufnr
  , mseg.ebeln
  , mara.mtart
  , qals.paendterm
  , mseg.bwart
  
FROM cdl_prod_l0_pandas.mseg mseg
left join cdl_prod_l0_pandas.qals qals on qals.charg = mseg.charg 
                                       and qals.matnr = mseg.matnr
                                       and qals.aufnr = mseg.aufnr 

INNER JOIN cdl_prod_l0_pandas.mara mara ON  mseg.mandt = mara.mandt
                                        AND mseg.matnr = mara.matnr 
                              
INNER JOIN cdl_prod_l0_pandas.makt makt ON  mseg.mandt = makt.mandt
                                        AND mseg.matnr = makt.matnr 
                              
INNER JOIN cdl_prod_l0_pandas.mcha mcha ON mseg.mandt = mcha.mandt
                              AND mseg.werks = mcha.werks 
                              AND mseg.charg = mcha.charg 
                              AND mseg.matnr = mcha.matnr
                              
INNER JOIN cdl_prod_l0_pandas.mch1 mch1 ON mseg.mandt = mch1.mandt
                              AND mseg.charg = mch1.charg 
                              AND mseg.matnr = mch1.matnr

INNER JOIN SQA.CONFIG_PANDAS_PRODUCTS ap ON ap.plant = mseg.werks 
                                       AND ap.product_type = mara.mtart 
                                       AND ap.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd')

WHERE makt.spras = 'E'
  and mseg.werks = '8111'
  and mseg.bwart in ('101', '321')

UNION

-- Icheon – plant code 8921
SELECT 
    mseg.mandt as mandant
  , mseg.werks
  , mseg.matnr
  , mseg.charg
  , makt.maktx
  , qals.prueflos
  , mcha.ersda
  , CASE 
      WHEN mch1.lwedt = '00000000' then mcha.ersda
      ELSE mch1.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , mseg.aufnr
  , mseg.ebeln
  , mara.mtart
  , qals.paendterm
  , mseg.bwart
  
FROM cdl_prod_l0_pandas.mseg mseg
left join cdl_prod_l0_pandas.qals qals on qals.charg = mseg.charg 
                                       and qals.matnr = mseg.matnr
                                       and qals.aufnr = mseg.aufnr 

INNER JOIN cdl_prod_l0_pandas.mara mara ON  mseg.mandt = mara.mandt
                                        AND mseg.matnr = mara.matnr 
                              
INNER JOIN cdl_prod_l0_pandas.makt makt ON  mseg.mandt = makt.mandt
                                        AND mseg.matnr = makt.matnr 
                              
INNER JOIN cdl_prod_l0_pandas.mcha mcha ON mseg.mandt = mcha.mandt
                              AND mseg.werks = mcha.werks 
                              AND mseg.charg = mcha.charg 
                              AND mseg.matnr = mcha.matnr
                              
INNER JOIN cdl_prod_l0_pandas.mch1 mch1 ON mseg.mandt = mch1.mandt
                              AND mseg.charg = mch1.charg 
                              AND mseg.matnr = mch1.matnr

INNER JOIN SQA.CONFIG_PANDAS_PRODUCTS ap ON ap.plant = mseg.werks 
                                       AND ap.product_type = mara.mtart 
                                       AND ap.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd')

WHERE makt.spras = 'E'
  and mseg.werks = '8921'
  and mseg.bwart = '101'
  
 UNION
 
--Xian – plant code 8621 -	Material type: HALB 
SELECT 
    mseg.mandt as mandant
  , mseg.werks
  , mseg.matnr
  , mseg.charg
  , makt.maktx
  , qals.prueflos
  , syncade.MFG_Review_Start as ersda
  , CASE 
      WHEN mch1.lwedt = '00000000' then syncade.MFG_Review_Start
      ELSE mch1.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , mseg.aufnr
  , mseg.ebeln
  , mara.mtart
  , qals.paendterm
  , mseg.bwart
  
FROM cdl_prod_l0_pandas.mseg mseg
left join cdl_prod_l0_pandas.qals qals on qals.charg = mseg.charg 
                                       and qals.matnr = mseg.matnr
                                       and qals.aufnr = mseg.aufnr 

INNER JOIN cdl_prod_l0_pandas.mara mara ON  mseg.mandt = mara.mandt
                                        AND mseg.matnr = mara.matnr 
                              
INNER JOIN cdl_prod_l0_pandas.makt makt ON  mseg.mandt = makt.mandt
                                        AND mseg.matnr = makt.matnr
                              
INNER JOIN cdl_prod_l0_pandas.mch1 mch1 ON mseg.mandt = mch1.mandt
                              AND mseg.charg = mch1.charg 
                              AND mseg.matnr = mch1.matnr

INNER JOIN SQA.CONFIG_PANDAS_PRODUCTS ap ON ap.plant = mseg.werks 
                                       AND ap.product_type = mara.mtart 
                                   
INNER JOIN sqa.mes_ebrreview_time syncade on mseg.charg = syncade.batch_number

WHERE makt.spras = 'E'
  and mseg.werks = '8621'
  and mara.qmpur = ' '
  and mara.mtart ='HALB'
  and mseg.bwart = '101'
  
 UNION
 
--Xian – plant code 8621 -	Material type: FERT
SELECT 
    mseg.mandt as mandant
  , mseg.werks
  , mseg.matnr
  , mseg.charg
  , makt.maktx
  , qals.prueflos
  , syncade.MFG_Review_Start as ersda
  , CASE 
      WHEN mch1.lwedt = '00000000' then syncade.MFG_Review_Start
      ELSE mch1.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , mseg.aufnr
  , mseg.ebeln
  , mara.mtart
  , qals.paendterm
  , mseg.bwart
  
FROM cdl_prod_l0_pandas.mseg mseg
left join cdl_prod_l0_pandas.qals qals on qals.charg = mseg.charg 
                                       and qals.matnr = mseg.matnr
                                       and qals.aufnr = mseg.aufnr 

INNER JOIN cdl_prod_l0_pandas.mara mara ON  mseg.mandt = mara.mandt
                                        AND mseg.matnr = mara.matnr 
                              
INNER JOIN cdl_prod_l0_pandas.makt makt ON  mseg.mandt = makt.mandt
                                        AND mseg.matnr = makt.matnr
                              
INNER JOIN cdl_prod_l0_pandas.mch1 mch1 ON mseg.mandt = mch1.mandt
                              AND mseg.charg = mch1.charg 
                              AND mseg.matnr = mch1.matnr

INNER JOIN SQA.CONFIG_PANDAS_PRODUCTS ap ON ap.plant = mseg.werks 
                                       AND ap.product_type = mara.mtart

INNER JOIN sqa.mes_ebrreview_time syncade on mseg.charg = syncade.batch_number

WHERE makt.spras = 'E'
  and mseg.werks = '8621'
  and mara.mtart ='FERT'
  and mseg.bwart = '101'
"""

df=spark.sql(base_query)
display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from CDL_L0_PROD_ELIMS.sdidataitem

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC FROM cdl_prod_l0_sustain.mseg mseg

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/mnt/CDL_PROD_L0_ajdpdeltaadlsn4/prd/raw/sus/mseg`

# COMMAND ----------

files = dbutils.fs.ls("/mnt/CDL_PROD_L0_ajdpdeltaadlsn4/prd/raw/sus/mseg")
display(files)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta.`abfss://rawdelta@ajdpdeltaadlsn4.dfs.core.windows.net/`

# COMMAND ----------

# MAGIC %sh
# MAGIC ls /dbfs/databricks/scripts/

# COMMAND ----------

# MAGIC %sh
# MAGIC cat /dbfs/databricks/scripts/cdl-private-endpoint-dns-setup.sh

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema manoj_test;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop database manoj_test cascade;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- show databases;
# MAGIC use manoj_test;
# MAGIC create table atlas_monitor(
# MAGIC   RUN_ID INT,
# MAGIC   SUCCESS_FLAG char(3),
# MAGIC   ELAPSED_TIME DECIMAL(6,3)
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO ATLAS_MONITOR VALUES(12345,'YES',23.6)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM manoj_test.ATLAS_MONITOR;

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.get(scope="sqacdl_scope",key="sqacdl_L1_client")

# COMMAND ----------

# for x in dbutils.secrets.get(scope="sqacdl_scope",key="sqacdl_L1_client"):
#   print(x)

# COMMAND ----------

dbutils.fs.ls('dbfs:/cluster-logs')

# COMMAND ----------

dbutils.fs.ls('dbfs:/user/hive/warehouse/1212-034401-claws171')

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC -- Start CSV fields --
# MAGIC   nc_details.compliancequest__Org_Site__c as J_J_SITE_NAME
# MAGIC -- lot info
# MAGIC , concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c) AS BATCH_NO
# MAGIC , nc_lot.compliancequest__Lot_Number__c as BATCH_ID_LOT_NUMBER
# MAGIC , nc_lot.CQ_JNJ_Material_Item__c as MATERIAL_ITEM
# MAGIC --NC/CAPA name - if capa present, the capa id will be concatenated with the nc id
# MAGIC , CASE
# MAGIC   WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
# MAGIC   ELSE nc_details.Name
# MAGIC   END AS PR_ID
# MAGIC --NC/CAPA stage/state - if capa present, the capa stage/state will be concatenated with the nc stage/state
# MAGIC , CASE
# MAGIC   WHEN capa_details.Name is not null then concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC) / ', capa_details.compliancequest__Record_Stage__c,'-',capa_details.compliancequest__Status__c, ' (CAPA)')
# MAGIC   ELSE concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC)')
# MAGIC   END AS STATE
# MAGIC , nc_risk.compliancequest__Conclusion__c as PROJECT
# MAGIC , date_format(nc_details.CreatedDate, 'yyyy-MM-dd HH:mm:ss') as DATE_CREATED
# MAGIC , nc_details.CreatedBy_Name as ORIGINATOR
# MAGIC , CASE
# MAGIC   WHEN capa_details.Owner_Name is not null then concat(nc_details.owner_name,' (NC) - ',capa_details.Owner_Name, ' (CAPA)')
# MAGIC   ELSE concat(nc_details.owner_name,' (NC)')
# MAGIC   END AS ASSIGNED_TO
# MAGIC , CASE
# MAGIC   WHEN capa_details.compliancequest__Due_Date_Investigation__c is not null then date_format(capa_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   ELSE date_format(nc_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   END AS DUE_DATE
# MAGIC -- ACTION
# MAGIC , 'UPDATE' as ACTION
# MAGIC , '' as COMMENT_TEXT
# MAGIC , nc_details.CQ_JNJ_Functional_Area_1__c as J_J_FUNCTIONAL_AREA_1
# MAGIC , nc_details.CQ_JNJ_Functional_Area_2__c as J_J_FUNCTIONAL_AREA_2
# MAGIC , nc_details.compliancequest__Org_Division__c as J_J_SEGMENT
# MAGIC , nc_details.compliancequest__Org_Business_Unit__c as J_J_BUSINESS_UNIT
# MAGIC , nc_additional.CQ_JNJ_SQX_Mfg_Category__c as MFG_CATEGORY
# MAGIC , nc_additional.CQ_JNJ_SQX_Mfg_Technology__c as MFG_TECHNOLOGY  
# MAGIC -- not ingested to date - , nc_additional.CQ_JNJ_SQX_Equipment_List__c as MFG_EQUIPMENT_LIST  
# MAGIC , '' as MFG_EQUIPMENT_LIST
# MAGIC , nc_risk.compliancequest__Conclusion__c as INVESTIGATION_LEVEL
# MAGIC , CASE
# MAGIC   WHEN capa_response_app.compliancequest__SQX_User__r_name is not null then concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC) - ',capa_response_app.compliancequest__SQX_User__r_name, ' (CAPA)')
# MAGIC   ELSE concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC)')
# MAGIC   END AS INVESTIGATION_APPROVED_BY
# MAGIC , CASE
# MAGIC   WHEN capa_finding_response.compliancequest__Published_Date__c is not null then date_format(capa_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   ELSE date_format(nc_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   END AS INVESTIGATION_APPROVED_ON
# MAGIC , date_format(nc_details.compliancequest__Aware_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_IDENTIFIED
# MAGIC , '' as IMPACT_ASSESSMENT_APPROVED_BY --not available in comet
# MAGIC , '' as IMPACT_ASSESSMENT_APPROVED_ON --not available in comet
# MAGIC , '' as ORIGINAL_DUE_DATE --not available in comet
# MAGIC , date_format(nc_details.compliancequest__Close_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_CLOSED
# MAGIC , '' as QUALITY_ISSUE_CLOSED_BY --not available in comet
# MAGIC , CASE
# MAGIC   WHEN capa_details.compliancequest__Title__c is not null then concat(nc_details.compliancequest__NC_Title__c ,' (NC) - ',capa_details.compliancequest__Title__c, ' (CAPA)')
# MAGIC   ELSE concat(nc_details.compliancequest__NC_Title__c,' (NC)')
# MAGIC   END AS TITLE
# MAGIC , nc_lot.CQ_JNJ_Release_from_Investigation__c as RELEASE_FROM_INVESTIGATION
# MAGIC , date_format(nc_investigation.compliancequest__Completed_On__c, 'yyyy-MM-dd HH:mm:ss') as DATE_INVESTIGATION_COMPLETE
# MAGIC , nc_lot.CQ_JNJ_Source_System__c as SOURCE_SYSTEM
# MAGIC  
# MAGIC from SQA.vw_comet_nc_details nc_details
# MAGIC inner join SQA.vw_NC_ImpactedPartLotRecords nc_lot on nc_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
# MAGIC left join SQA.vw_comet_capa_details capa_details on capa_details.compliancequest__SQX_Source_NC__c = nc_details.id
# MAGIC left join SQA.vw_comet_capa_impactedpartlotrecords capa_lot on capa_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
# MAGIC left join SQA.vw_comet_nc_additionalinforecords nc_additional on nc_additional.CQ_JNJ_SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_nc_riskassessmentrecords nc_risk on nc_risk.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_capa_responseapprovalrecords capa_response_app on capa_response_app.compliancequest__SQX_CAPA__c = capa_details.Id
# MAGIC left join SQA.vw_comet_nc_responseapprovalrecords nc_response_app on nc_response_app.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_NC_FindingResponseRecords nc_finding_response on nc_finding_response.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_CAPA_FindingResponseRecords capa_finding_response on capa_finding_response.compliancequest__SQX_capa__c = capa_details.Id
# MAGIC left join SQA.vw_comet_nc_investigationrecords nc_investigation on nc_investigation.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_capa_investigationrecords capa_investigation on capa_investigation.compliancequest__SQX_CAPA__c = capa_details.Id
# MAGIC  
# MAGIC where
# MAGIC (
# MAGIC -- 1. NC flow: NC Stage 'Disposition/Investigate' / Status 'Open' ; CAPA: N/A
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Disposition_Investigate' and nc_details.compliancequest__Status__c = 'Open') OR
# MAGIC -- 2. NC + CAPA flow: NC Stage 'Implement / Status = 'Open' ; CAPA Stage 'Investigate’ / Status = 'Open'
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Investigate' and capa_details.compliancequest__Status__c = 'Open') OR
# MAGIC -- 3. NC + CAPA flow: NC Stage 'Verification’ / Status = 'Complete' ; CAPA Stage 'Investigate’ / Status = 'Open'
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Investigate' and capa_details.compliancequest__Status__c = 'Open')
# MAGIC )
# MAGIC  
# MAGIC and
# MAGIC nc_details.compliancequest__Org_Site__c in
# MAGIC (
# MAGIC 'Japan_Sunto-gun_600-8 Minamiisshiki'
# MAGIC ,'Netherlands_Leiden_Einsteinweg 92'
# MAGIC ,'Belgium_Beerse_Turnhoutseweg 30'
# MAGIC ,'Puerto Rico_Gurabo_Rd 933 Mamey Ward (Plant 1300)'
# MAGIC ,'Brazil_SaoJoseDosCampos_RodoviaPresidenteDutraKm154'
# MAGIC ,'US_ GA_Athens_1440 Olympic Dr'
# MAGIC ,'Ireland_Cork_Barnahely'
# MAGIC ,'China_Xian_19 Cao Tang Si Lu'
# MAGIC ,'Switzerland_Schaffhausen_Hochstrasse'
# MAGIC ,'Puerto Rico_Gurabo_Rd 933 Mamey Ward (Plant (1700)'
# MAGIC ,'Italy_Latina_Via C. Janssen'
# MAGIC ,'Ireland_Cork_Little Island'
# MAGIC ,'Belgium_Geel_Janssen-Pharmaceuticalaan 3'
# MAGIC ,'US_PA_Malvern_200 GreatValleyPkwy'
# MAGIC ,'Mexico_Huejotzingo_CarreteraFederalMexico-PueblaKm81.5'
# MAGIC ,'Korea_Incheon_Songdo'
# MAGIC  
# MAGIC )
# MAGIC  
# MAGIC and nc_details.name = 'NC-004767'
# MAGIC  
# MAGIC  
# MAGIC order by nc_details.Name desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_AdditionalInfoRecords' as name,count(*) from SQA.COMET_NC_AdditionalInfoRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_DETAILS' as name,count(*) from SQA.COMET_NC_DETAILS

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_ResponseApprovalRecords' as name,count(*) from SQA.COMET_NC_ResponseApprovalRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_RiskAssessmentRecords' as name,count(*) from SQA.COMET_NC_RiskAssessmentRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_AdditionalInfoRecords' as name,count(*) from SQA.COMET_NC_AdditionalInfoRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_InvestigationRecords' as name,count(*) from SQA.COMET_NC_InvestigationRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_ImpactedPartLotRecords' as name,count(*) from SQA.COMET_NC_ImpactedPartLotRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_FindingResponseRecords' as name,count(*) from SQA.COMET_NC_FindingResponseRecords

# COMMAND ----------

# MAGIC %sql
# MAGIC select 'COMET_NC_AdditionalSites' as name,count(*) from SQA.COMET_NC_AdditionalSites

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.mes_ebrreview_time --where Batch_Number in (030018C-PEJ59)--', '030075B-PEJ62')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.mes_ebrreview_time where Batch_Number in ('PEJ59','PEJ62')

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC select * from sqa.mes_ebrreview_time where Batch_Number in ('PFJ71')
# MAGIC --030001B-PFJ71

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.pandas_upcoming_batches_history where BATCH_NO in('030001B-PFJ71')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.pandas_upcoming_batches_history where BATCH_NO in('030075B-PEJ62')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_upcoming_batches_history where BATCH_NO like '%309547%' and BATCH_NO like '%378906C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_upcoming_batches_history where BATCH_NO like '%381510C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_upcoming_batches_history where BATCH_NO like '%381510C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%300121%' and SUBLOT_NO like '%381510C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%309694%' and SUBLOT_NO like '%381693C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct source from sqa.batch_genealogy_history where SUBLOT_NO like '%309547%' and SUBLOT_NO like '%378906C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT sig.type_id
# MAGIC               , rs.PRODUCT_ID
# MAGIC               , rs.TENANT_ID
# MAGIC               , rs.MFG_LOT_NUMBER
# MAGIC               , rs.BATCH_NO
# MAGIC               , rs.ARRIVAL_DATE
# MAGIC               , mch.lwedt as DATE_RECEIVED
# MAGIC               , rs.TRANSACTION_NO
# MAGIC               , rs.CSV_COMMENT
# MAGIC               , rs.PRODUCT_DESCRIPTION
# MAGIC               , rs.MATERIAL_ID
# MAGIC               , rs.PROCESS_ORDER
# MAGIC               , rs.PRODUCT_TYPE
# MAGIC               , rs.TRIMMED_PROCESS_ORDER
# MAGIC               , rs.TENANT_SID
# MAGIC               , CASE
# MAGIC                 WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is not null) THEN 'END-BRR'
# MAGIC                 WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is null) THEN 'NOT END-BRR'
# MAGIC                 ELSE 'END-BRR'
# MAGIC                 END AS ACTION
# MAGIC               , 3 AS ACTION_NUMBER
# MAGIC               , current_timestamp() AS INSERTED_AT
# MAGIC               , '' AS OPTIONAL_1
# MAGIC               , '' AS OPTIONAL_2
# MAGIC               , '' AS OPTIONAL_3
# MAGIC               , '' AS OPTIONAL_4
# MAGIC               , '' AS OPTIONAL_5
# MAGIC               , '' AS OPTIONAL_6
# MAGIC               , '' AS OPTIONAL_7
# MAGIC               , '' AS OPTIONAL_8
# MAGIC               , rs.OPTIONAL_9 AS OPTIONAL_9
# MAGIC               , '' AS OPTIONAL_10
# MAGIC               , nvl(sig.type_id, '') AS OPTIONAL_11
# MAGIC               , '' AS OPTIONAL_12
# MAGIC               , '' AS OPTIONAL_13
# MAGIC               , rs.OPTIONAL_14 AS OPTIONAL_14
# MAGIC               , rs.OPTIONAL_15 AS OPTIONAL_15
# MAGIC               , rs.OPTIONAL_16 AS OPTIONAL_16
# MAGIC               , '' AS OPTIONAL_17
# MAGIC               , rs.OPTIONAL_18 AS OPTIONAL_18
# MAGIC               , '' AS OPTIONAL_19
# MAGIC               , '' AS OPTIONAL_20
# MAGIC               , '' AS OPTIONAL_21
# MAGIC               , rs.OPTIONAL_22 AS OPTIONAL_22
# MAGIC               , min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id) AS OPTIONAL_23
# MAGIC               , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'yyyyMMdd') as OPTIONAL_24
# MAGIC               , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'HHmmss') AS OPTIONAL_25
# MAGIC               , rs.OPTIONAL_26 AS OPTIONAL_26
# MAGIC               , '' AS OPTIONAL_27
# MAGIC               , '' AS OPTIONAL_28
# MAGIC               , '' AS OPTIONAL_29
# MAGIC               , '' AS OPTIONAL_30
# MAGIC FROM SQA.SUSTAIN_UPCOMING_BATCHES_HISTORY rs
# MAGIC INNER JOIN cdl_make_prod_pasx.brr brr ON rs.TRIMMED_PROCESS_ORDER = brr.order_id
# MAGIC                            and rs.tenant_sid = brr.tenant_sid
# MAGIC INNER JOIN cdl_make_prod_pasx.brr_signature sig ON brr.brr_sid = sig.brr_sid
# MAGIC                                      and brr.tenant_sid = sig.tenant_sid
# MAGIC LEFT JOIN (
# MAGIC     SELECT distinct order_id,
# MAGIC            production_unit_id
# MAGIC     FROM cdl_make_prod_pasx.shop_floor_order
# MAGIC     WHERE production_unit_id in (select production_unit_id
# MAGIC                                  from SQA.SUSTAIN_PRODUCTION_UNITS)
# MAGIC     ) so on rs.TRIMMED_PROCESS_ORDER = so.order_id
# MAGIC INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch on rs.MATERIAL_ID = mch.matnr
# MAGIC                                and rs.MFG_LOT_NUMBER = mch.charg
# MAGIC where sig.type_id in ('BrrManufacturingApproval', 'BrrProductionApproval')
# MAGIC AND rs.batch_no LIKE '%381510C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT DISTINCT rs.PRODUCT_ID
# MAGIC               , rs.TENANT_ID
# MAGIC               , rs.MFG_LOT_NUMBER
# MAGIC               , rs.BATCH_NO
# MAGIC               , rs.ARRIVAL_DATE
# MAGIC               , mch.lwedt as DATE_RECEIVED
# MAGIC               , rs.TRANSACTION_NO
# MAGIC               , rs.CSV_COMMENT
# MAGIC               , rs.PRODUCT_DESCRIPTION
# MAGIC               , rs.MATERIAL_ID
# MAGIC               , rs.PROCESS_ORDER
# MAGIC               , rs.PRODUCT_TYPE
# MAGIC               , rs.TRIMMED_PROCESS_ORDER
# MAGIC               , rs.TENANT_SID
# MAGIC               , CASE
# MAGIC                 WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is not null) THEN 'END-QA-BRR'
# MAGIC                 WHEN rs.TENANT_ID = 'CO01' and (so.production_unit_id is null) THEN 'NOT END-QA-BRR'
# MAGIC                 ELSE 'END-QA-BRR' 
# MAGIC                 END AS ACTION
# MAGIC               , 4 AS ACTION_NUMBER
# MAGIC               , current_timestamp() AS INSERTED_AT 
# MAGIC               , '' AS OPTIONAL_1
# MAGIC               , '' AS OPTIONAL_2
# MAGIC               , '' AS OPTIONAL_3
# MAGIC               , '' AS OPTIONAL_4
# MAGIC               , '' AS OPTIONAL_5
# MAGIC               , '' AS OPTIONAL_6
# MAGIC               , '' AS OPTIONAL_7
# MAGIC               , '' AS OPTIONAL_8
# MAGIC               , rs.OPTIONAL_9 AS OPTIONAL_9
# MAGIC               , '' AS OPTIONAL_10
# MAGIC               , nvl(pasxbrr.OPTIONAL_11, '') AS OPTIONAL_11
# MAGIC               , nvl(sig.type_id, '') AS OPTIONAL_12
# MAGIC               , '' AS OPTIONAL_13
# MAGIC               , rs.OPTIONAL_14 AS OPTIONAL_14 
# MAGIC               , rs.OPTIONAL_15 AS OPTIONAL_15 
# MAGIC               , rs.OPTIONAL_16 AS OPTIONAL_16 
# MAGIC               , '' AS OPTIONAL_17
# MAGIC               , rs.OPTIONAL_18 AS OPTIONAL_18 
# MAGIC               , '' AS OPTIONAL_19
# MAGIC               , '' AS OPTIONAL_20
# MAGIC               , '' AS OPTIONAL_21
# MAGIC               , rs.OPTIONAL_22 AS OPTIONAL_22
# MAGIC               , min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id) AS OPTIONAL_23
# MAGIC               , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'yyyyMMdd') as OPTIONAL_24
# MAGIC               , date_format(min(sig.sign_date_ts) over (partition by sig.brr_sid, sig.tenant_sid, sig.type_id), 'HHmmss') AS OPTIONAL_25
# MAGIC               , rs.OPTIONAL_26 AS OPTIONAL_26
# MAGIC               , '' AS OPTIONAL_27
# MAGIC               , '' AS OPTIONAL_28
# MAGIC               , '' AS OPTIONAL_29
# MAGIC               , '' AS OPTIONAL_30
# MAGIC FROM ALL_INSERTS rs
# MAGIC LEFT JOIN PASX_END_BRR pasxbrr on rs.MFG_LOT_NUMBER = pasxbrr.MFG_LOT_NUMBER
# MAGIC INNER JOIN cdl_make_prod_pasx.brr brr ON rs.TRIMMED_PROCESS_ORDER = brr.order_id 
# MAGIC                            AND rs.tenant_sid = brr.tenant_sid 
# MAGIC INNER JOIN cdl_make_prod_pasx.brr_signature sig ON brr.brr_sid = sig.brr_sid 
# MAGIC                                      AND brr.tenant_sid = sig.tenant_sid 
# MAGIC LEFT JOIN (
# MAGIC     SELECT distinct order_id, 
# MAGIC            production_unit_id
# MAGIC     FROM cdl_make_prod_pasx.shop_floor_order
# MAGIC     WHERE production_unit_id in (select production_unit_id 
# MAGIC                                  from SQA.SUSTAIN_PRODUCTION_UNITS)
# MAGIC     ) so on rs.TRIMMED_PROCESS_ORDER = so.order_id
# MAGIC INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON rs.MATERIAL_ID = mch.matnr 
# MAGIC                                AND rs.MFG_LOT_NUMBER = mch.charg 
# MAGIC WHERE sig.type_id = 'BrrQualityApproval'
# MAGIC AND rs.batch_no LIKE '%381510C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from sqa.comet_history where BATCH_NO like '%A24AC0787%' --and PR_ID like 'NC-013875%'

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from sqa.comet_history where BATCH_NO like '%A24AC0787%' and PR_ID like 'NC-013875%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select BATCH_NO,ACTION  from (Select * from sqa.comet_history where PR_ID like '%CAPA%' ) group by BATCH_NO,ACTION-- where ACTION in ('OPEN','UPDATE')--and ACTION like'closed'

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from sqa.comet_history where PR_ID like '%CAPA%' and action = 'CLOSE' and INSERTED_AT > TIMESTAMP '2024-07-22 07:11:14.850+00:00'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.vw_comet_nc_details nc_details where name='NC-013875'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.vw_NC_ImpactedPartLotRecords WHERE compliancequest__SQX_Nonconformance__c='a2Y5f000003ZteGEAS'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from SQA.vw_comet_nc_additionalinforecords where CQ_JNJ_SQX_Nonconformance__c='a2Y5f000003ZteGEAS'

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC -- Start CSV fields --
# MAGIC   nc_details.compliancequest__Org_Site__c as J_J_SITE_NAME
# MAGIC -- lot info
# MAGIC , concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c) AS BATCH_NO
# MAGIC , nc_lot.compliancequest__Lot_Number__c as BATCH_ID_LOT_NUMBER
# MAGIC , nc_lot.CQ_JNJ_Material_Item__c as MATERIAL_ITEM
# MAGIC --NC/CAPA name - if capa present, the capa id will be concatenated with the nc id
# MAGIC , CASE
# MAGIC   WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
# MAGIC   ELSE nc_details.Name
# MAGIC   END AS PR_ID
# MAGIC --NC/CAPA stage/state - if capa present, the capa stage/state will be concatenated with the nc stage/state
# MAGIC , CASE
# MAGIC   WHEN capa_details.Name is not null then concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC) / ', capa_details.compliancequest__Record_Stage__c,'-',capa_details.compliancequest__Status__c, ' (CAPA)')
# MAGIC   ELSE concat(nc_details.compliancequest__Record_Stage__c,'-',nc_details.compliancequest__Status__c, ' (NC)')
# MAGIC   END AS STATE
# MAGIC , nc_risk.compliancequest__Conclusion__c as PROJECT
# MAGIC , date_format(nc_details.CreatedDate, 'yyyy-MM-dd HH:mm:ss') as DATE_CREATED
# MAGIC , nc_details.CreatedBy_Name as ORIGINATOR
# MAGIC , CASE
# MAGIC   WHEN capa_details.Owner_Name is not null then concat(nc_details.owner_name,' (NC) - ',capa_details.Owner_Name, ' (CAPA)')
# MAGIC   ELSE concat(nc_details.owner_name,' (NC)')
# MAGIC   END AS ASSIGNED_TO
# MAGIC , CASE
# MAGIC   WHEN capa_details.compliancequest__Due_Date_Investigation__c is not null then date_format(capa_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   ELSE date_format(nc_details.compliancequest__Due_Date_Investigation__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   END AS DUE_DATE
# MAGIC -- ACTION
# MAGIC , 'CLOSE' as ACTION
# MAGIC , '' as COMMENT_TEXT
# MAGIC , nc_details.CQ_JNJ_Functional_Area_1__c as J_J_FUNCTIONAL_AREA_1
# MAGIC , nc_details.CQ_JNJ_Functional_Area_2__c as J_J_FUNCTIONAL_AREA_2
# MAGIC , nc_details.compliancequest__Org_Division__c as J_J_SEGMENT
# MAGIC , nc_details.compliancequest__Org_Business_Unit__c as J_J_BUSINESS_UNIT
# MAGIC , nc_additional.CQ_JNJ_SQX_Mfg_Category__c as MFG_CATEGORY
# MAGIC , nc_additional.CQ_JNJ_SQX_Mfg_Technology__c as MFG_TECHNOLOGY  
# MAGIC -- not ingested to date - , nc_additional.CQ_JNJ_SQX_Equipment_List__c as MFG_EQUIPMENT_LIST  
# MAGIC , '' as MFG_EQUIPMENT_LIST
# MAGIC , nc_risk.compliancequest__Conclusion__c as INVESTIGATION_LEVEL
# MAGIC , CASE
# MAGIC   WHEN capa_response_app.compliancequest__SQX_User__r_name is not null then concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC) - ',capa_response_app.compliancequest__SQX_User__r_name, ' (CAPA)')
# MAGIC   ELSE concat(nc_response_app.compliancequest__SQX_User__r_Name,' (NC)')
# MAGIC   END AS INVESTIGATION_APPROVED_BY
# MAGIC , CASE
# MAGIC   WHEN capa_finding_response.compliancequest__Published_Date__c is not null then date_format(capa_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   ELSE date_format(nc_finding_response.compliancequest__Published_Date__c, 'yyyy-MM-dd HH:mm:ss')
# MAGIC   END AS INVESTIGATION_APPROVED_ON
# MAGIC , date_format(nc_details.compliancequest__Aware_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_IDENTIFIED
# MAGIC , '' as IMPACT_ASSESSMENT_APPROVED_BY --not available in comet
# MAGIC , '' as IMPACT_ASSESSMENT_APPROVED_ON --not available in comet
# MAGIC , '' as ORIGINAL_DUE_DATE --not available in comet
# MAGIC , date_format(nc_details.compliancequest__Close_Date__c, 'yyyy-MM-dd HH:mm:ss') as DATE_CLOSED
# MAGIC , '' as QUALITY_ISSUE_CLOSED_BY --not available in comet
# MAGIC , CASE
# MAGIC   WHEN capa_details.compliancequest__Title__c is not null then concat(nc_details.compliancequest__NC_Title__c ,' (NC) - ',capa_details.compliancequest__Title__c, ' (CAPA)')
# MAGIC   ELSE concat(nc_details.compliancequest__NC_Title__c,' (NC)')
# MAGIC   END AS TITLE
# MAGIC , nc_lot.CQ_JNJ_Release_from_Investigation__c as RELEASE_FROM_INVESTIGATION
# MAGIC , date_format(nc_investigation.compliancequest__Completed_On__c, 'yyyy-MM-dd HH:mm:ss') as DATE_INVESTIGATION_COMPLETE
# MAGIC , nc_lot.CQ_JNJ_Source_System__c as SOURCE_SYSTEM
# MAGIC  
# MAGIC from SQA.vw_comet_nc_details nc_details
# MAGIC inner join SQA.COMET_SITES sites on nc_details.compliancequest__Org_Site__c = sites.J_J_SITE_NAME
# MAGIC inner join SQA.vw_NC_ImpactedPartLotRecords nc_lot on nc_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
# MAGIC left join SQA.vw_comet_capa_details capa_details on capa_details.compliancequest__SQX_Source_NC__c = nc_details.id
# MAGIC left join SQA.vw_comet_capa_impactedpartlotrecords capa_lot on capa_lot.compliancequest__SQX_Nonconformance__c = nc_details.id
# MAGIC left join SQA.vw_comet_nc_additionalinforecords nc_additional on nc_additional.CQ_JNJ_SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_nc_riskassessmentrecords nc_risk on nc_risk.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_capa_responseapprovalrecords capa_response_app on capa_response_app.compliancequest__SQX_CAPA__c = capa_details.Id
# MAGIC left join SQA.vw_comet_nc_responseapprovalrecords nc_response_app on nc_response_app.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_NC_FindingResponseRecords nc_finding_response on nc_finding_response.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_CAPA_FindingResponseRecords capa_finding_response on capa_finding_response.compliancequest__SQX_capa__c = capa_details.Id
# MAGIC left join SQA.vw_comet_nc_investigationrecords nc_investigation on nc_investigation.compliancequest__SQX_Nonconformance__c = nc_details.Id
# MAGIC left join SQA.vw_comet_capa_investigationrecords capa_investigation on capa_investigation.compliancequest__SQX_CAPA__c = capa_details.Id
# MAGIC left join (
# MAGIC   select J_J_SITE_NAME,
# MAGIC          BATCH_ID_LOT_NUMBER,
# MAGIC          PR_ID,
# MAGIC          BATCH_NO
# MAGIC   from sqa.comet_history
# MAGIC   where ACTION = 'OPEN'
# MAGIC ) history on history.J_J_SITE_NAME = nc_details.compliancequest__Org_Site__c
# MAGIC          and history.BATCH_ID_LOT_NUMBER = nc_lot.compliancequest__Lot_Number__c
# MAGIC          and (CASE
# MAGIC               WHEN capa_details.Name is not null then concat(nc_details.Name,'-',capa_details.Name)
# MAGIC               ELSE nc_details.Name
# MAGIC               END) like concat(history.PR_ID, '%')
# MAGIC          and nvl(history.BATCH_NO, 'NA') = nvl(concat(regexp_replace(nc_lot.CQ_JNJ_Material_Item__c, '^[0]*', ''), '-', nc_lot.compliancequest__Lot_Number__c), 'NA')
# MAGIC  
# MAGIC where
# MAGIC --For a NC record in status ‘VOID’ -- case1
# MAGIC ((nc_details.compliancequest__Status__c = 'Void') OR
# MAGIC -- NC Flow : For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND no CAPA record AND Product impact = Product grid is filled with Product and lot number -- case2
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.Name is null)  OR
# MAGIC -- NC Flow : For a NC record with an existing site/material/batch, at NC ‘CLOSED’ stage ; NC ‘CLOSED’ status AND Product impact = Product grid is filled with Product and lot number -- case3
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Closed' and nc_details.compliancequest__Status__c = 'Closed') OR
# MAGIC -- NC flow: For a NC record from which a product/lot has been removed from the grid = released from investigation flag = yes -- case4
# MAGIC (nc_details.compliancequest__Status__c = 'Open' and  nc_details.compliancequest__Record_Stage__c = 'Disposition_Investigate' and nc_lot.CQ_JNJ_Release_from_Investigation__c = 'Yes') OR
# MAGIC -- NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND a CAPA record at CAPA ‘IMPLEMENT’ stage ; CAPA ‘OPEN’ status Product impact = Product grid is filled with Product and lot number -- case5
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Implement' and capa_details.compliancequest__Status__c = 'Open') OR
# MAGIC --NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND a CAPA record at CAPA ‘VERIFICATION’ stage ; CAPA ‘COMPLETE’ status Product impact = Product grid is filled with Product and lot number -- -- case6
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Verfication' and capa_details.compliancequest__Status__c = 'Complete') OR
# MAGIC -- NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘IMPLEMENT’ stage ; NC ‘OPEN’ status AND a CAPA record at CAPA ‘Closed’ stage ; CAPA ‘Closed’ status Product impact = Product grid is filled with Product and lot number -- case7
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Implement' and nc_details.compliancequest__Status__c = 'Open' and capa_details.compliancequest__Record_Stage__c = 'Closed' and capa_details.compliancequest__Status__c = 'Closed') OR
# MAGIC --NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘VERIFICATION’ stage ; NC ‘COMPLETE’ status AND a CAPA record at ‘IMPLEMENT’ stage ; CAPA ‘OPEN’ status Product impact = Product grid is filled with Product and lot number -- case 8
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Implement' and capa_details.compliancequest__Status__c = 'Open') OR
# MAGIC --NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘VERIFICATION’ stage ; NC ‘COMPLETE’ status AND a CAPA record at CAPA ‘VERIFICATION’ stage ; CAPA ‘COMPLETE’ status Product impact = Product grid is filled with Product and lot number -- case 9
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Verification' and capa_details.compliancequest__Status__c = 'Complete') OR
# MAGIC --NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘VERIFICATION’ stage ; NC ‘COMPLETE’ status AND a CAPA record at CAPA ‘CLOSED’ stage ; CAPA ‘CLOSED’ status Product impact = Product grid is filled with Product and lot number -- case 10
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Verification' and nc_details.compliancequest__Status__c = 'Complete' and capa_details.compliancequest__Record_Stage__c = 'Closed' and capa_details.compliancequest__Status__c = 'Closed') OR
# MAGIC --NC + CAPA flow: For a NC record with an existing site/material/batch, at NC ‘CLOSED’ stage ; NC ‘CLOSED’ status AND a CAPA record at CAPA ‘CLOSED’ stage ; CAPA ‘CLOSED’ status Product impact = Product grid is filled with Product and lot number -- case 11
# MAGIC (nc_details.compliancequest__Record_Stage__c = 'Closed' and nc_details.compliancequest__Status__c = 'Closed' and capa_details.compliancequest__Record_Stage__c = 'Closed' and capa_details.compliancequest__Status__c = 'Closed')
# MAGIC  
# MAGIC )
# MAGIC and history.PR_ID is not null
# MAGIC  
# MAGIC and nc_details.name = 'NC-013875'
# MAGIC and nc_lot.compliancequest__Lot_Number__c = 'A24AC0787'
# MAGIC and nc_lot.CQ_JNJ_Material_Item__c like '%563493'
# MAGIC  
# MAGIC order by nc_details.Name desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%377430%' and SUBLOT_NO like '%PFB4B00%'
# MAGIC -- 377430-PFB4B00
# MAGIC -- 761838-0022374968 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like('413828-NFBS604') order by INSERTED_AT asc

# COMMAND ----------

# MAGIC %sql
# MAGIC -- sqa.sustain_upcoming_batches_history
# MAGIC
# MAGIC select * from sqa.sustain_upcoming_batches_history where PRODUCT_ID like('%307956%') and BATCH_NO like '%386579C001%'-- order by INSERTED_AT asc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%386579%' and SUBLOT_NO like '%386579%'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC --PU is null...existing backlog...SAP HISTORY command
# MAGIC SELECT DISTINCT
# MAGIC               right(matnr, 6) AS PRODUCT_ID
# MAGIC             , werks AS TENANT_ID
# MAGIC             , charg AS MFG_LOT_NUMBER
# MAGIC             , CONCAT(right(matnr, 6), '-', charg) AS BATCH_NO
# MAGIC               , production_unit_id as PU
# MAGIC               , group_id as Group
# MAGIC               , status_txt as mo_statustxt
# MAGIC               , BWART as bwartmvt
# MAGIC from cdl_prod_l0_sustain.mseg TIMESTAMP AS OF '2024-09-30T00:00:00.000+00:00' mseg
# MAGIC INNER JOIN sqa.sustain_sites site ON mseg.werks = site.plant
# MAGIC LEFT JOIN cdl_make_prod_pasx.manufacturing_order TIMESTAMP AS OF '2024-09-30T00:00:00.000+00:00' mo
# MAGIC ON id = right(aufnr, 6)  AND site.tenant_sid = mo.tenant_sid --** LEFT JOIN
# MAGIC LEFT JOIN (
# MAGIC     SELECT distinct
# MAGIC            order_id,
# MAGIC            sfo.production_unit_id,
# MAGIC            pu.group_id
# MAGIC     FROM cdl_make_prod_pasx.shop_floor_order TIMESTAMP AS OF '2024-09-30T00:00:00.000+00:00' sfo
# MAGIC     INNER JOIN SQA.SUSTAIN_PRODUCTION_UNITS TIMESTAMP AS OF '2024-07-11T04:56:19.000+00:00' pu
# MAGIC     on pu.production_unit_id = sfo.production_unit_id
# MAGIC     ) so on id = order_id
# MAGIC  
# MAGIC     where mseg.matnr like ('%307956%') and mseg.charg like '%386579%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%410284%' and SUBLOT_NO like '%PEB3X00%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like '%410284-PEB3X00%' --and SUBLOT_NO like '%PEB3X00%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where BATCH_NO like '%PHJ89%' 
# MAGIC or BATCH_NO like '%PIJ97%' 
# MAGIC or BATCH_NO like '%PIJ72%' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%030102B%' and SUBLOT_NO like '%PIJ97%'
# MAGIC -- 030006B-PHJ89

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.pandas_upcoming_batches_history where BATCH_NO in('030006B-PHJ89','030102B-PIJ97',' 030065C-PIJ72')
# MAGIC --SUBLOT_NO like '%030102B%' and SUBLOT_NO like '%PIJ97%'
# MAGIC -- 030006B-PHJ89

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.mes_ebrreview_time where Batch_Number in ('PHJ89','PIJ97','PIJ72')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where BATCH_NO like '%410284-PEB3X00%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%388093C%' --and SUBLOT_NO like '%PIJ97%'
# MAGIC -- 030006B-PHJ89

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_upcoming_batches_history where BATCH_NO like '%388093C%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_batch_genealogy_history where SUBLOT_NO like '%388093C%' or PARENT_NO like '%388093C%'

# COMMAND ----------

# UPDATED WITH NEW QUERY AND WORKS

pasx_inserts_query = """
Select * from
(SELECT DISTINCT 
              right(mseg.matnr, 6) AS PRODUCT_ID
            , mseg.werks AS TENANT_ID
            , mseg.charg AS MFG_LOT_NUMBER
            , CONCAT(right(mseg.matnr, 6), '-', mseg.charg) AS BATCH_NO
            , mch.ersda as ARRIVAL_DATE
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 THEN date_format(mo.actual_start_ts, 'yyyyMMdd')
              ELSE mch.lwedt 
              END as DATE_RECEIVED
            , 'DEFAULT' AS TRANSACTION_NO
            , '' AS CSV_COMMENT
            , makt.maktx as PRODUCT_DESCRIPTION
            , mseg.matnr AS MATERIAL_ID
            , mseg.aufnr AS PROCESS_ORDER
            , mara.mtart as PRODUCT_TYPE
            , right(mseg.aufnr, 6) AS TRIMMED_PROCESS_ORDER
            , site.tenant_sid AS TENANT_SID
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt = 'Started' and mseg.bwart not in ('261', '262') THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt <> 'Started' THEN 'DONT INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 3 and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart <> 101 THEN 'DONT INSERT'
              WHEN mseg.bwart = 101 THEN 'INSERT'
              ELSE 'DONT INSERT' 
              END AS ACTION
            , 2 AS ACTION_NUMBER
            , current_timestamp() AS INSERTED_AT
            , '' AS OPTIONAL_1
            , '' AS OPTIONAL_2
            , '' AS OPTIONAL_3
            , '' AS OPTIONAL_4
            , '' AS OPTIONAL_5
            , '' AS OPTIONAL_6
            , '' AS OPTIONAL_7
            , '' AS OPTIONAL_8
            , right(mseg.aufnr, 6) AS OPTIONAL_9
            , '' AS OPTIONAL_10
            , '' AS OPTIONAL_11
            , '' AS OPTIONAL_12
            , '' AS OPTIONAL_13
            , t001w.name1 AS OPTIONAL_14 
            , mseg.charg AS OPTIONAL_15 
            , mara.mtart AS OPTIONAL_16 
            , '' AS OPTIONAL_17
            , CASE 
                WHEN marc.webaz = '0' THEN ''
                ELSE marc.webaz
              END AS OPTIONAL_18
            , '' AS OPTIONAL_19
            , '' AS OPTIONAL_20
            , '' AS OPTIONAL_21
            , CASE
               WHEN mo.id is null THEN ''
               WHEN mes_status.aufnr is null THEN ''
               ELSE mo.id 
              END AS OPTIONAL_22
            , '' AS OPTIONAL_23
            , mkpf.cpudt AS OPTIONAL_24
            , mkpf.cputm AS OPTIONAL_25
            , 'CET' AS OPTIONAL_26
            , '' AS OPTIONAL_27
            , '' AS OPTIONAL_28
            , '' AS OPTIONAL_29
            , '' AS OPTIONAL_30
FROM cdl_prod_l0_sustain.mseg mseg
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON mseg.matnr = mch.matnr AND mseg.charg = mch.charg 
INNER JOIN cdl_prod_l0_sustain.vnd_mara mara ON mara.matnr = mseg.matnr
INNER JOIN cdl_prod_l0_sustain.vnd_makt makt ON mseg.matnr = makt.matnr 
INNER JOIN sqa.sustain_sites site ON mseg.werks = site.plant  
INNER JOIN cdl_prod_l0_sustain.vnd_t001w t001w ON mseg.werks = t001w.werks
INNER JOIN cdl_prod_l0_sustain.vnd_marc marc ON mseg.werks = marc.werks AND mseg.matnr = marc.matnr
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo ON mo.id = right(mseg.aufnr, 6) AND mo.tenant_sid = site.tenant_sid --** LEFT JOIN
LEFT JOIN (
    SELECT distinct 
           flo.order_id, 
           flo.production_unit_id,
           pu.group_id
    FROM cdl_make_prod_pasx.shop_floor_order flo
    INNER JOIN SQA.SUSTAIN_PRODUCTION_UNITS pu on flo.production_unit_id = pu.production_unit_id
    ) so on mo.id = so.order_id
INNER JOIN sqa.config_sustain_products products  ON mara.mtart = products.product_type 
                                      AND mseg.werks = products.plant 
                                      AND (to_timestamp(mch.ersda, 'yyyyMMdd') >= to_timestamp(products.created_date))
  
LEFT JOIN (
            SELECT mseg1.werks, mseg1.charg, mseg1.matnr, mseg1.aufnr, mseg1.ebeln 
            FROM cdl_prod_l0_sustain.mseg mseg1
            WHERE mseg1.bwart in (321, 350)
          ) released on mseg.charg = released.charg 
                    and mseg.werks = released.werks 
                    and mseg.matnr = released.matnr 
                    and mseg.aufnr = released.aufnr
            
-- ONLY GET THOSE WITH a MES% STATUS
INNER JOIN (
            SELECT distinct aufk.aufnr
            FROM cdl_prod_l0_sustain.vnd_aufk aufk
            INNER JOIN cdl_prod_l0_sustain.vnd_jest jest ON aufk.objnr = jest.objnr
            INNER JOIN cdl_prod_l0_sustain.vnd_tj30t user_stat on jest.stat = user_stat.estat
            WHERE jest.inact <> 'X'
            AND user_stat.spras = 'E'
            AND user_stat.txt04 LIKE 'MES%' 
) mes_status ON mes_status.aufnr = mseg.aufnr

-- Add transactional datetime
LEFT JOIN cdl_prod_l0_sustain.mkpf mkpf ON mkpf.MBLNR = mseg.MBLNR

WHERE makt.spras = 'E' 
AND released.charg IS NULL
--** ONLY GET THOSE WITH a MES% STATUS OR PASX MO
AND (mo.id is not null OR mes_status.aufnr is not null))
where BATCH_NO like '%388093C%'
"""

# COMMAND ----------

pasx_inserts_query= spark.sql(pasx_inserts_query)
display(pasx_inserts_query)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.mes_ebrreview_time --where Material_Code like '%307954%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_upcoming_batches_history where BATCH_NO like '%389394%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where BATCH_NO like '%PIB0C%' 
# MAGIC or BATCH_NO like '%PIB3F%' 
# MAGIC -- or BATCH_NO like '%PIJ72%' 
# MAGIC --Hi, can you please check when the CLOSED action for following NCs was sent from COMET to Smart QA?
# MAGIC -- batch 276775-PIB3F - NC-023443
# MAGIC -- batch 258504-PIB0C - NC-023765

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where PARENT_NO like '%466979-PKS61%' or PARENT_NO like '%466979-PKS61%'
# MAGIC -- PARENT_NO

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.pandas_upcoming_batches_history where BATCH_NO like "%PEB3N02%" or BATCH_NO like "%PGS2JMA%"

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where BATCH_NO like '%PJB1000%' 
# MAGIC -- or BATCH_NO like '%PIB3F%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like "%442221-PKS2I%"

# COMMAND ----------

case when base.OPTIONAL_13 in ('APPROVED', 'RESTRICTED USE', 'REPROCESS', 'REJECT', 'REWORK') then 'TRUE'
         when base.OPTIONAL_13 = 'REANALYSIS' and coalesce(pass_user.vcode,'') = 'I' and g.GROUP_ID = 2 then 'TRUE'
         when g.GROUP_ID = 2 and (coalesce(purchase_order.txt04,'') = 'LTCA' or coalesce(process_order.txt04,'') = 'LTCA') then 'TRUE'
         when (array_contains(base.il_status, 'AVJD') AND base.OPTIONAL_13 = 'PRE-APPROVED' and g.tenant_id in ('CHP1', 'CHP2')) OR (coalesce(pass_user.vcode,'') = 'P' AND array_contains(base.il_status, 'AVJD') and g.tenant_id in ('CHP1', 'CHP2')) then 'TRUE'
         when (array_contains(base.il_status, 'APG2') AND base.OPTIONAL_13 <> 'SPECIAL') then 'TRUE'
         when (array_contains(base.il_status, 'APG2') AND base.OPTIONAL_13 = 'SPECIAL' and g.tenant_id in ('CHP1', 'CHP2')) then 'TRUE'
         else 'FALSE'
    end AS pass_action

LEFT JOIN (
     SELECT mandant, TENANT_ID, MFG_LOT_NUMBER, PRODUCT_ID
     FROM sqa.europe2_upcoming_batches_history
     WHERE action = 'PASS'
   ) hist_pass  ON base.mandant = hist_pass.mandant 
             AND base.TENANT_ID = hist_pass.TENANT_ID 
             AND base.MFG_LOT_NUMBER = hist_pass.MFG_LOT_NUMBER 
             AND base.PRODUCT_ID = hist_pass.PRODUCT_ID  



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.comet_history where BATCH_NO like '%383306%'  --PRODUCT_ID like '305751' and BATCH_NO like '%383306%' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.sustain_upcoming_batches_history where PRODUCT_ID like '%305751%' and BATCH_NO like '%383306%' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.batch_genealogy_history where SUBLOT_NO like '%383306L%' 

# COMMAND ----------

pasx_inserts_query = """
SELECT DISTINCT 
              right(mseg.matnr, 6) AS PRODUCT_ID
            , mseg.werks AS TENANT_ID
            , mseg.charg AS MFG_LOT_NUMBER
            , CONCAT(right(mseg.matnr, 6), '-', mseg.charg) AS BATCH_NO
            , mch.ersda as ARRIVAL_DATE
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 THEN date_format(mo.actual_start_ts, 'yyyyMMdd')
              ELSE mch.lwedt 
              END as DATE_RECEIVED
            , 'DEFAULT' AS TRANSACTION_NO
            , '' AS CSV_COMMENT
            , makt.maktx as PRODUCT_DESCRIPTION
            , mseg.matnr AS MATERIAL_ID
            , mseg.aufnr AS PROCESS_ORDER
            , mara.mtart as PRODUCT_TYPE
            , right(mseg.aufnr, 6) AS TRIMMED_PROCESS_ORDER
            , site.tenant_sid AS TENANT_SID
            , CASE
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt = 'Started' and mseg.bwart not in ('261', '262') THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 1 and mo.status_txt <> 'Started' THEN 'DONT INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is not null) and so.group_id = 3 and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart = 101 THEN 'INSERT'
              WHEN mseg.werks = 'CO01' and (so.production_unit_id is null) and mseg.bwart <> 101 THEN 'DONT INSERT'
              WHEN mseg.bwart = 101 THEN 'INSERT'
              ELSE 'DONT INSERT' 
              END AS ACTION
FROM cdl_prod_l0_sustain.mseg mseg
INNER JOIN cdl_prod_l0_sustain.vnd_mch1 mch ON mseg.matnr = mch.matnr AND mseg.charg = mch.charg 
INNER JOIN cdl_prod_l0_sustain.vnd_mara mara ON mara.matnr = mseg.matnr
INNER JOIN cdl_prod_l0_sustain.vnd_makt makt ON mseg.matnr = makt.matnr 
INNER JOIN sqa.sustain_sites site ON mseg.werks = site.plant  
INNER JOIN cdl_prod_l0_sustain.vnd_t001w t001w ON mseg.werks = t001w.werks
INNER JOIN cdl_prod_l0_sustain.vnd_marc marc ON mseg.werks = marc.werks AND mseg.matnr = marc.matnr
LEFT JOIN cdl_make_prod_pasx.manufacturing_order mo ON mo.id = right(mseg.aufnr, 6) AND mo.tenant_sid = site.tenant_sid 
LEFT JOIN (
    SELECT distinct 
           flo.order_id, 
           flo.production_unit_id,
           pu.group_id
    FROM cdl_make_prod_pasx.shop_floor_order flo
    INNER JOIN SQA.SUSTAIN_PRODUCTION_UNITS pu on flo.production_unit_id = pu.production_unit_id
    ) so on mo.id = so.order_id
 """

# COMMAND ----------

df=spark.sql(pasx_inserts_query)
df.createOrReplaceTempView("pasx_inserts_query")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select CONCAT(right(mseg.matnr, 6), '-', mseg.charg) as batch FROM cdl_prod_l0_sustain.mseg where CONCAT(right(mseg.matnr, 6), '-', mseg.charg) like '%305751-383306%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like '%PGL52%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like '%PGL53%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like '%PGL6D%'

# COMMAND ----------

base_query_mfg = """
SELECT 
    qals.mandant
  , qals.werk
  , qals.matnr
  , qals.charg
  , qals.prueflos
  , mcha.ersda
  , CASE
    WHEN qals.aufnr is null and qals.ebeln is null and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN qals.aufnr = ' ' and qals.ebeln = ' ' and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN mcha.lwedt = '00000000' then mcha.ersda
    ELSE mcha.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , qals.aufnr
  , qals.ebeln
  , qals.paendterm
  , mara.mtart
  , mcha.cuobj_bm
  , '' as yqualf 
  , CASE 
      WHEN marc.webaz IS NULL THEN ''
      WHEN marc.webaz = '0' THEN ''
      ELSE marc.webaz
    END AS grpt
  , qals.aenderdat
  , qals.aenderzeit
  , mcha.ERSDA_TZ_SYS

FROM cdl_prod_l0_europe2.vnd_qals qals 

LEFT JOIN SQA.EUROPE2_MFG_PLANTS mfg on qals.werk = mfg.reswk

INNER JOIN cdl_prod_l0_europe2.vnd_mara mara ON qals.mandant = mara.mandt 
                              AND qals.matnr = mara.matnr 
                                                           
INNER JOIN cdl_prod_l0_europe2.vnd_mcha mcha ON qals.mandant = mcha.mandt 
                              AND qals.werk = mcha.werks 
                              AND qals.charg = mcha.charg 
                              AND qals.matnr = mcha.matnr
  
LEFT JOIN cdl_prod_l0_europe2.vnd_marc marc  ON qals.mandant = marc.mandt 
                              AND qals.werk = marc.werks 
                              AND qals.matnr = marc.matnr

LEFT JOIN SQA.CONFIG_EUROPE2_PRODUCTS pI ON pI.plant = qals.werk 
                                       AND pI.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd') 
                                       AND pI.product_type = mara.mtart
LEFT JOIN (SELECT Plant as Plant, INCLUDED_EXCLUDED_MATL, MAX(created_date) AS created_date
          FROM SQA.CONFIG_EUROPE2_PRODUCTS 
          WHERE INCLUDED_EXCLUDED_MATL = 'E'
          GROUP BY Plant, INCLUDED_EXCLUDED_MATL) pE ON pE.plant = qals.werk 
                                       AND pE.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd')
LEFT JOIN cdl_prod_l0_europe2.mkpf mkpf on qals.MBLNR=mkpf.MBLNR                                                                 
WHERE  ( pI.INCLUDED_EXCLUDED_MATL = 'I' 
        OR  (pI.INCLUDED_EXCLUDED_MATL IS NULL AND pE.INCLUDED_EXCLUDED_MATL = 'E')
      )
  AND qals.charg <> ' '
  AND qals.herkunft <> '03' 
  AND qals.sprache = 'E'
"""

# COMMAND ----------

base_query_non_mfg = """
SELECT 
    qals.mandant
  , qals.werk
  , qals.matnr
  , qals.charg
  , qals.prueflos
  , mcha.ersda
  , CASE
    WHEN qals.aufnr is null and qals.ebeln is null and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN qals.aufnr = ' ' and qals.ebeln = ' ' and qals.werk in ('IEP1', 'BEP7') THEN mkpf.cpudt
    WHEN mcha.lwedt = '00000000' then mcha.ersda
    ELSE mcha.lwedt 
    END AS lwedt
  , qals.enstehdat
  , qals.entstezeit
  , qals.objnr
  , qals.aufnr 
  , ypm1.aufnr as ebeln 
  , qals.paendterm
  , mara.mtart
  , mcha.cuobj_bm
  , ysls.yqualf 
  , '' as grpt
  , qals.aenderdat
  , qals.aenderzeit
  , mcha.ERSDA_TZ_SYS

FROM cdl_prod_l0_europe2.vnd_qals qals 

LEFT JOIN SQA.EUROPE2_MFG_PLANTS mfg on qals.werk = mfg.reswk

INNER JOIN cdl_prod_l0_europe2.vnd_mara mara ON qals.mandant = mara.mandt 
                              AND qals.matnr = mara.matnr 
                              
INNER JOIN cdl_prod_l0_europe2.vnd_mcha mcha ON qals.mandant = mcha.mandt 
                              AND qals.werk = mcha.werks 
                              AND qals.charg = mcha.charg 
                              AND qals.matnr = mcha.matnr
 
INNER JOIN 
    ( SELECT distinct matnr, eu_dc_batch_id, yqualf
     FROM cdl_prod_l0_europe2.vnd_YSLSGRC
     ) ysls ON qals.matnr = ysls.matnr and qals.charg = ysls.eu_dc_batch_id 
INNER JOIN cdl_prod_l0_europe2.vnd_cawn cawn on ysls.yqualf = cawn.atwrt
INNER JOIN cdl_prod_l0_europe2.vnd_cabn cabn on cawn.atinn = cabn.atinn and cawn.adzhl = cabn.adzhl  

INNER JOIN cdl_prod_l0_europe2.vnd_YPM00001 ypm1 on qals.mandant = ypm1.mandt and qals.werk = ypm1.werks and qals.charg = ypm1.charg and qals.matnr = ypm1.matnr  

LEFT JOIN SQA.CONFIG_EUROPE2_PRODUCTS pI ON pI.plant = qals.werk 
                                       AND pI.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd') 
                                       AND pI.product_type = mara.mtart
LEFT JOIN (SELECT Plant as Plant, INCLUDED_EXCLUDED_MATL, MAX(created_date) AS created_date
          FROM SQA.CONFIG_EUROPE2_PRODUCTS 
          WHERE INCLUDED_EXCLUDED_MATL = 'E'
          GROUP BY Plant, INCLUDED_EXCLUDED_MATL) pE ON pE.plant = qals.werk 
                                       AND pE.created_date <= to_timestamp(mcha.ersda, 'yyyyMMdd')
LEFT JOIN cdl_prod_l0_europe2.mkpf mkpf on qals.MBLNR=mkpf.MBLNR                                                                    
WHERE  ( pI.INCLUDED_EXCLUDED_MATL = 'I' 
        OR  (pI.INCLUDED_EXCLUDED_MATL IS NULL AND pE.INCLUDED_EXCLUDED_MATL = 'E')
      )
  AND qals.charg <> ' '
  AND qals.herkunft <> '03' 
  AND qals.sprache = 'E'
  AND mfg.reswk is null -- Only include non-mfg plants
  AND cabn.atnam = 'C_RELEASE_QP' 
  
"""

# COMMAND ----------

df_base_query_mfg = spark.sql(base_query_mfg)
df_base_query_non_mfg = spark.sql(base_query_non_mfg)
df_base_query_all = df_base_query_mfg.union(df_base_query_non_mfg)

df_base_query_all.createOrReplaceTempView('base_e2_dataset')
spark.catalog.cacheTable('base_e2_dataset')

# COMMAND ----------

base_filter_query = """
SELECT 
    base.mandant
  , base.werk
  , base.matnr
  , base.charg
  , base.prueflos
  , base.ersda
  , base.lwedt 
  , base.enstehdat
  , base.entstezeit
  , base.objnr
  , base.aufnr
  , base.ebeln
  , base.paendterm
  , base.mtart
  , base.cuobj_bm
  , base.yqualf
  , base.grpt
  , base.aenderdat
  , base.aenderzeit
  , base.ERSDA_TZ_SYS

FROM base_e2_dataset base 

-- Only keep IL with latest date
INNER JOIN 
    (
       SELECT mandant, werk, charg, matnr, max(enstehdat) AS max_il_creation_date
       FROM base_e2_dataset
       GROUP BY mandant, werk, charg, matnr
     ) max_date ON base.mandant = max_date.mandant 
               AND base.werk = max_date.werk 
               AND base.charg = max_date.charg 
               AND base.matnr = max_date.matnr 
               AND base.enstehdat = max_date.max_il_creation_date
       
-- And only keep IL with latest time (for the latest date)
INNER JOIN 
    (
      SELECT mandant, werk, charg, matnr, enstehdat, max(entstezeit) AS max_il_creation_time
      FROM base_e2_dataset
      GROUP BY mandant, werk, charg, matnr, enstehdat
     ) max_time ON base.mandant = max_time.mandant 
               AND base.werk = max_time.werk 
               AND base.charg = max_time.charg 
               AND base.matnr = max_time.matnr 
               AND base.enstehdat = max_time.enstehdat 
               AND base.entstezeit = max_time.max_il_creation_time
               
"""

# COMMAND ----------

df_base_filter_query = spark.sql(base_filter_query)
df_base_filter_query.createOrReplaceTempView('filtered_e2_dataset')
spark.catalog.cacheTable('filtered_e2_dataset')

# COMMAND ----------

# MAGIC %sql
# MAGIC select  concat(regexp_replace(base.matnr, '^[0]*', ''), '-', base.charg) AS BATCH_NO,il_status.udate as end_qa_brr_date,il_status.objnr FROM filtered_e2_dataset base
# MAGIC left JOIN
# MAGIC   (
# MAGIC     SELECT distinct
# MAGIC            jest.mandt, 
# MAGIC            jest.objnr
# MAGIC     -- ** USERNAME UPDATE 4 of 5 **
# MAGIC     , max(
# MAGIC       case when user_stat.txt04 = 'AVJD' then jcds.usnam
# MAGIC       else ''
# MAGIC       end
# MAGIC       ) over (partition by jest.mandt, jest.objnr) as avjd_usnam 
# MAGIC     -- ** 
# MAGIC     , collect_set(user_stat.txt04) over (partition by jest.mandt, jest.objnr) as user_stats
# MAGIC     , jcds.udate
# MAGIC     , jcds.utime
# MAGIC     FROM cdl_prod_l0_europe2.vnd_jest jest
# MAGIC     INNER JOIN cdl_prod_l0_europe2.vnd_tj30t user_stat ON jest.mandt = user_stat.mandt 
# MAGIC                                        AND jest.stat = user_stat.estat
# MAGIC     -- Only check for configured stats                                   
# MAGIC     INNER JOIN SQA.EUROPE2_USER_STATS stats ON stats.stsma = user_stat.stsma and stats.estat = user_stat.estat 
# MAGIC     LEFT JOIN cdl_prod_l0_europe2.vnd_jcds jcds ON jest.mandt = jcds.mandt and jest.stat = jcds.stat and jest.objnr = jcds.objnr and jest.chgnr = jcds.chgnr 
# MAGIC     WHERE jest.inact <> 'X'
# MAGIC     AND user_stat.spras = 'E'
# MAGIC   ) il_status ON base.mandant = il_status.mandt 
# MAGIC                 AND base.objnr = il_status.objnr
# MAGIC
# MAGIC where concat(regexp_replace(base.matnr, '^[0]*', ''), '-', base.charg) like  '%PGL52%'   

# COMMAND ----------

# MAGIC %sql
# MAGIC select       qals.mandant
# MAGIC   , qals.werk
# MAGIC   , qals.matnr
# MAGIC   , qals.charg
# MAGIC   , qals.prueflos
# MAGIC   , qals.enstehdat
# MAGIC   , qals.entstezeit
# MAGIC   , qals.objnr
# MAGIC   , qals.aufnr
# MAGIC   , qals.paendterm
# MAGIC   , qals.aenderdat
# MAGIC   , qals.aenderzeit
# MAGIC  FROM cdl_prod_l0_europe2.vnd_qals qals where OBJNR='QL040001138409'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like '%PIL3P00%'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like '%PILK001%' order by INSERTED_AT asc;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sqa.europe2_upcoming_batches_history where BATCH_NO like '%471504-PJBS500%' order by INSERTED_AT asc;

# COMMAND ----------

