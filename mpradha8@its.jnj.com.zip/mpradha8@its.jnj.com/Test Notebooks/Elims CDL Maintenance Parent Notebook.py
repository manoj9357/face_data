# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ############IMPORTANT: PAUSE ELIMS APPROVAL DATA AND ELIMS SAMPLE DATA JOBS BEFORE RUNNING THIS NOTEBOOK

# COMMAND ----------

dbutils.widgets.text(name='Maintenance_strt_time', defaultValue = '',label='YYYY-MM-DD HH:MM:SS.000000  Maintenance window Start Time')
dbutils.widgets.text(name='Maintenance_end_time', defaultValue = '',label='YYYY-MM-DD HH:MM:SS.000000   Maintenance window End Time')

# COMMAND ----------

mtn_Start_Time=dbutils.widgets.get("Maintenance_strt_time") 
mtn_End_Time=dbutils.widgets.get("Maintenance_end_time")

# COMMAND ----------

print(mtn_Start_Time)
print(mtn_End_Time)

# COMMAND ----------

if not (mtn_Start_Time.strip() and mtn_End_Time.strip()):
  dbutils.notebook.exit("Text widget is empty,Stopping Execution. Please Run the notebook Again and fill the blank parameters")
else:
  pass

# COMMAND ----------

class FailureException(Exception):
    pass
        

# COMMAND ----------

# MAGIC %md
# MAGIC #########Remove Parameter details from widgets provided in the child notebooks. So that Parent Notebook Parameter gets the preference

# COMMAND ----------

Elims_CDL_mtn_Approval_data_status = False
Elims_CDL_mtn_Approval_data_error = None
try:
  dbutils.notebook.run("/Workspace/Users/mpradha8@its.jnj.com/Test Notebooks/Elims Approval Data (CDL Maintenance window)",2400,{'Maintenance_strt_time':'{mtn_Start_Time}','Maintenance_end_time':'{mtn_End_Time}'})
  Elims_CDL_mtn_Approval_data_status = True
except Exception as e:
  print('Exception: ', e)
  Elims_CDL_mtn_Approval_data_error = e
  Elims_CDL_mtn_Approval_data_status = False
print("Error in Elims_CDL_mtn_Approval_data" if not Elims_CDL_mtn_Approval_data_status else '')

# COMMAND ----------

Elims_CDL_mtn_sample_data_status = False
Elims_CDL_mtn_sample_data_error = None
try:
  dbutils.notebook.run("/Workspace/Users/mpradha8@its.jnj.com/Test Notebooks/Elims Sample_Data (CDL Maintenance window)",2400,{'Maintenance_strt_time':'{mtn_Start_Time}','Maintenance_end_time':'{mtn_End_Time}'})
  Elims_CDL_mtn_sample_data_status = True
except Exception as e:
  print('Exception: ', e)
  Elims_CDL_mtn_sample_data_error = e
  Elims_CDL_mtn_sample_data_status = False
print("Error in Elims_CDL_mtn_sample_data" if not Elims_CDL_mtn_sample_data_status else '')

# COMMAND ----------

if not Elims_CDL_mtn_Approval_data_status or not Elims_CDL_mtn_sample_data_status:
  err_msg = 'Elims CDL mtn sample data error: ' + str(Elims_CDL_mtn_sample_data_error) if not Elims_CDL_mtn_sample_data_status else ''
  err_msg = err_msg + "\r\n" 'Elims CDL mtn Approval data error: ' + str(Elims_CDL_mtn_Approval_data_error) if not Elims_CDL_mtn_Approval_data_status else ''
  raise FailureException(err_msg)

# COMMAND ----------

print(Elims_CDL_mtn_sample_data_status)

# COMMAND ----------

print(Elims_CDL_mtn_Approval_data_status)