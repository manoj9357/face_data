# Databricks notebook source
# MAGIC %md
# MAGIC #SQIF Framework#
# MAGIC **Description:** Framework used to mount all the configurations and functions.  
# MAGIC **Author:** Haroon Khalid
# MAGIC **Managed By:** Niall Moore, Ramya Baliga 
# MAGIC **Date:** 07 Jan 2021

# COMMAND ----------

import datetime
import time
import re
from pyspark.sql.functions import *
from datetime import datetime as dt


try:
  import pysftp
except Exception as e:
  if "No module named" in str(e):
    dbutils.library.installPyPI('pysftp')
finally:
  import pysftp

class Framework:
  
  def __init__(self):
    #self.mount_point = mount_point
    self.config = None
    
  def get_etl_id(self):
    try:
      run_id = dbutils.notebook.entry_point.getDbutils().notebook().getContext().currentRunId().toString()
      etl_id=int(re.search(r'\d+', run_id).group())
      return etl_id
    except:
      return 1  

  def update_processing_state(self, app_key, table):
    print('updating processing state')
    self.config = spark.sql("SELECT * FROM {} where NAME = '{}'".format(table, app_key)).first()
    if self.config.PROCESSING:
      path = dbutils.secrets.get('sqa', 'sqa_processing_location')
      for file in dbutils.fs.ls(path):
        if(app_key.upper() in file.path.upper()):
          dbutils.fs.rm(file.path, recurse=True)
    spark.sql("UPDATE {} set PROCESSING = true where NAME = '{}'".format(table, app_key))    
    
    
  #def mount(self):
  #  storage_account = dbutils.secrets.get('sqa', 'mdh_storage_account') 
  #  container = dbutils.secrets.get('sqa', 'mdh_container') 
  #  sas_token = dbutils.secrets.get('mdh_access', 'mdh_secret') #SAS token 
  #  URI = 'fs.azure.sas.{}.{}.blob.core.windows.net'.format(container, storage_account)
  #  source = 'wasbs://{}@{}.blob.core.windows.net'.format(container, storage_account)
  #  mounted = self.mount_point in [mnt.mountPoint for mnt in dbutils.fs.mounts()]
  #  
  #  if mounted:
  #    print('mount point exists, returning')
  #    return
  #    
  #  print('Attempting to mount ADLS at {}'.format(self.mount_point))
  #  try:
  #    dbutils.fs.mount(
  #      source=source,
  #      mount_point=self.mount_point,
  #      extra_configs={URI: sas_token}
  #    )
  #  except Exception as e:
  #    if "Error Occured in Mount storage " in str(e):
  #      pass # Ignore error if already mounted.
  #    else:
  #      raise e  
        
          
  def unmount(self):
    dbutils.fs.unmount(self.mount_point)

    
  def to_df(self, query):
    return spark.sql(query)
    
    
  def read_csv(self, path):
    return spark.read.format('csv')\
      .options(header='true')\
      .load(path)

  
  def write_csv(self, df, filename):
    df.coalesce(1).write \
    .format("com.databricks.spark.csv")\
    .option("header", "true")\
    .option("emptyValue", '')\
    .option('mode', 'append')\
    .save(filename)
    
  
  def to_csv(self, df, name):
    path = dbutils.secrets.get('sqa', 'sqa_processing_location') 
    run_time = int(time.time() * 1000)
    filename = '{}-{}.csv'.format(name, run_time)
    self.write_csv(df, "{}/{}".format(path, filename))
    return filename
    
    
  def archive(self, df, filename, folder):
    path = dbutils.secrets.get('sqa', 'sqa_archive_location') 
    delta_path = dbutils.secrets.get('sqa', 'sqa_delta_archive_location') 
    
    df = df.withColumn('FILE_NAME', lit(filename));
    self.write_csv(df, "{}/{}/{}".format(path, folder, filename))
    
    
  
  def save(self, df, tablename): 
    df.write\
    .format("delta")\
    .mode('append')\
    .saveAsTable("{}".format(tablename))
    


  def get_csv_name(self, filename): 
    path = dbutils.secrets.get('sqa', 'sqa_processing_location') 
    for f in dbutils.fs.ls('{}/{}'.format(path, filename)):
      if f.path.endswith(('.csv')):
        return f.name
      
    
  def sftp(self, filename, location):
    host = dbutils.secrets.get('sqa', 'sqa_sftp_url')
    username = dbutils.secrets.get('sqa', 'sqa_sftp_username')
    key = dbutils.secrets.get('sqa', 'sqa_sftp_key_location')
    path = dbutils.secrets.get('sqa', 'sqa_processing_location')
    
    
    csv_file = self.get_csv_name(filename)
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    
    try:
      with pysftp.Connection(host, username=username, private_key=key, cnopts=cnopts) as sftp:
        with sftp.cd('{}/'.format(location)):
          print(sftp.listdir())
          file = sftp.put('/dbfs/FileStore/sqa/processing/{}/{}'.format(filename, csv_file), filename,\
                          callback=lambda x,y: print("{} transfered out of {}".format(x,y)))
          print(sftp.listdir())
          return file
    except Exception as e:
      raise e

      
  def update_config(self, filename, name, table):
    if filename:
      run_time = float((filename.split('-')[-1])[:-4])     
      run_time_str = '{}'.format(dt.fromtimestamp(run_time/1000.0))
      timestamp = (spark.sql("select to_timestamp('{}') as tmp".format(run_time_str)).first()).tmp
      spark.sql("UPDATE {} set LAST_TIMESTAMP = '{}', PROCESSING = false where NAME = '{}'".format(table, timestamp, name))
    else:
      spark.sql("UPDATE {0} set PROCESSING = false where NAME = '{1}'".format(table, name))
      
      
  def move_csv_to_archive(self, filename, folder):
    path = dbutils.secrets.get('sqa', 'sqa_processing_location')
    file_path = '{}/{}'.format(path, filename)
    # Moving file from the "path" to archive_path and delta_path.
    archive_path = dbutils.secrets.get('sqa', 'sqa_archive_location') 
    file_archive = '{}/{}/{}'.format(archive_path,folder,filename)
    dbutils.fs.mv(file_path,file_archive, recurse=True)  
    
  def clean_up(self, filename):
    path = dbutils.secrets.get('sqa', 'sqa_processing_location') 
    file_path = '{}/{}'.format(path, filename)
    print('removing file from {}'.format(file_path))
    dbutils.fs.rm(file_path, recurse=True)
    
          
if __name__ == "__main__":
    Framework()
    