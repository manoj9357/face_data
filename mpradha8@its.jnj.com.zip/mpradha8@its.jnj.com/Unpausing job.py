# Databricks notebook source

import requests
import json

shard_url= "https://adb-6803967472078692.12.azuredatabricks.net"
access_token= "dapi0e3fb8104ddbfcd665c856e0e1781e23-2"
flag = 0

headers_auth = {
 'Authorization': f'Bearer {access_token}'
}
job_list_url=f"{shard_url}/api/2.1/jobs/list"

jobs_list = requests.request("GET", job_list_url, headers=headers_auth).json()
job_update_url=f"{shard_url}/api/2.1/jobs/update"

for job in jobs_list['jobs']:
    if "schedule" in job['settings']:
        if job['settings']['schedule']['pause_status'] == "PAUSED":
            flag += 1
            schedule = job['settings']['schedule']
            schedule['pause_status'] = "UNPAUSED"
            job_name = job['settings']['name']
            job_id = job['job_id']
            
            payload_pause_schedule = json.dumps({
             "job_id": job['job_id'],
             "new_settings": {
             "schedule": schedule
              }
              })


            response = requests.request("POST", job_update_url, headers = headers_auth, data = payload_pause_schedule)
            print("UnPausing job ",job_id)


if flag == 0:
    print("jobs to be paused")

# COMMAND ----------

