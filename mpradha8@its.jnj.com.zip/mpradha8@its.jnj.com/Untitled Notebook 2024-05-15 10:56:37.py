# Databricks notebook source
# MAGIC %fs
# MAGIC mounts

# COMMAND ----------

key = dbutils.secrets.get(scope = 'sqacdl_scope', key = 'sqacdl_L1_client')
print(key[0:2])
print(key[1:1000])

# COMMAND ----------

# MAGIC %sql
# MAGIC show schemas;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sys.jobs_runs

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table hive_metastore.default.Jobdb
# MAGIC {
# MAGIC   job_name varchar(50),
# MAGIC   job_id int,
# MAGIC   job_run_id int,
# MAGIC   start_time timestamp,
# MAGIC   end_time timestamp,
# MAGIC   duration timestamp,
# MAGIC   job_status varchar(50),
# MAGIC   job_run_log_path varchar(100)
# MAGIC };

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE or replace TABLE jobs (
# MAGIC     job_id LONG,
# MAGIC     job_name STRING,
# MAGIC     run_id LONG,
# MAGIC     start_time TIMESTAMP,
# MAGIC     end_time TIMESTAMP,
# MAGIC     status STRING,
# MAGIC     error_message STRING,
# MAGIC     html_file_path STRING
# MAGIC
# MAGIC );

# COMMAND ----------

# import requests
# from pyspark.sql import SparkSession

# # Initialize Spark session
# spark = SparkSession.builder.appName("DatabricksJobs").getOrCreate()

# # Databricks domain and token
# domain = 'https://adb-4933264770484963.3.azuredatabricks.net'
# token = 'dapi831b55c6d4663aa199d0204ce8636c44-2'

# # Set up the headers for HTTP request
# headers = {
#     'Authorization': f'Bearer {token}',
#     'Content-Type': 'application/json'
# }

# # Function to get the list of job runs
# def get_job_runs():
#     endpoint = f'{domain}/api/2.0/jobs/runs/list'
#     response = requests.get(endpoint, headers=headers)
#     if response.status_code == 200:
#         return response.json()['runs']
#     else:
#         raise Exception(f'Error fetching job runs: {response.content}')

# # Function to insert data into the jobs table
# def insert_data_into_table(job_runs):
#     # Convert job runs data to a DataFrame
#     job_runs_df = spark.createDataFrame(job_runs)
    
#     # Select and rename the necessary columns
#     job_runs_df = job_runs_df.selectExpr(
#         "job_id",
#         "run_name as job_name",
#         "run_id",
#         "start_time",
#         "end_time",
#         "state.life_cycle_state as status"
#     )
    
#     # Insert data into the jobs table
#     job_runs_df.write.mode('append').saveAsTable('jobs')

# # Get the job runs data
# job_runs = get_job_runs()

# # Insert the data into the jobs table
# insert_data_into_table(job_runs)


# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from spark_catalog.jobs

# COMMAND ----------

# MAGIC %sql
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC truncate table jobs

# COMMAND ----------

# import requests
# from pyspark.sql import SparkSession
# from pyspark.sql.functions import col

# # Initialize Spark session
# spark = SparkSession.builder.appName("DatabricksJobs").getOrCreate()

# # Databricks domain and token
# domain = 'https://adb-4933264770484963.3.azuredatabricks.net'
# token = 'dapi831b55c6d4663aa199d0204ce8636c44-2'

# # Set up the headers for HTTP request
# headers = {
#     'Authorization': f'Bearer {token}',
#     'Content-Type': 'application/json'
# }

# # Function to get the list of job runs
# def get_job_runs():
#     endpoint = f'{domain}/api/2.0/jobs/runs/list'
#     response = requests.get(endpoint, headers=headers)
#     if response.status_code == 200:
#         return response.json()['runs']
#     else:
#         raise Exception(f'Error fetching job runs: {response.content}')

# # Function to insert data into the jobs table
# def insert_data_into_table(job_runs):
#     # Convert job runs data to a DataFrame
#     job_runs_df = spark.createDataFrame(job_runs)
    
#     # Convert Unix timestamp (milliseconds) to TimestampType
#     job_runs_df = job_runs_df.withColumn('start_time', (col('start_time') / 1000).cast('timestamp'))
#     job_runs_df = job_runs_df.withColumn('end_time', (col('end_time') / 1000).cast('timestamp'))
    
#     # Select and rename the necessary columns
#     job_runs_df = job_runs_df.selectExpr(
#         "job_id",
#         "run_name as job_name",
#         "run_id",
#         "start_time",
#         "end_time",
#         "state.life_cycle_state as status"
#     )
    
#     # Insert data into the jobs table
#     job_runs_df.write.mode('append').saveAsTable('jobs')

# # Get the job runs data
# job_runs = get_job_runs()

# # Insert the data into the jobs table
# insert_data_into_table(job_runs)


# COMMAND ----------

# import requests
# from pyspark.sql import SparkSession
# from pyspark.sql.functions import col, from_utc_timestamp
# from datetime import timezone, timedelta

# # Initialize Spark session
# spark = SparkSession.builder.appName("DatabricksJobs").getOrCreate()

# # Databricks domain and token
# domain = 'https://adb-4933264770484963.3.azuredatabricks.net'
# token = 'dapi831b55c6d4663aa199d0204ce8636c44-2'

# # Set up the headers for HTTP request
# headers = {
#     'Authorization': f'Bearer {token}',
#     'Content-Type': 'application/json'
# }

# # Function to get the list of job runs
# def get_job_runs():
#     endpoint = f'{domain}/api/2.0/jobs/runs/list'
#     response = requests.get(endpoint, headers=headers)
#     if response.status_code == 200:
#         return response.json()['runs']
#     else:
#         raise Exception(f'Error fetching job runs: {response.content}')

# # Function to insert data into the jobs table
# def insert_data_into_table(job_runs):
#     # Convert job runs data to a DataFrame
#     job_runs_df = spark.createDataFrame(job_runs)
    
#     # Convert Unix timestamp (milliseconds) to TimestampType
#     job_runs_df = job_runs_df.withColumn('start_time', (col('start_time') / 1000).cast('timestamp'))
#     job_runs_df = job_runs_df.withColumn('end_time', (col('end_time') / 1000).cast('timestamp'))
    
#     # Convert to Indian Standard Time (IST)
#     ist_offset = timedelta(hours=5, minutes=30)
#     job_runs_df = job_runs_df.withColumn('start_time_ist', from_utc_timestamp(col('start_time'), 'Asia/Kolkata'))
#     job_runs_df = job_runs_df.withColumn('end_time_ist', from_utc_timestamp(col('end_time'), 'Asia/Kolkata'))
    
#     # Select and rename the necessary columns
#     job_runs_df = job_runs_df.selectExpr(
#         "job_id",
#         "run_name as job_name",
#         "run_id",
#         "start_time_ist as start_time",
#         "end_time_ist as end_time",
#         "state.life_cycle_state as status"
#     )
    
#     # Insert data into the jobs table
#     job_runs_df.write.mode('append').saveAsTable('jobs')

# # Get the job runs data
# job_runs = get_job_runs()

# # Insert the data into the jobs table
# insert_data_into_table(job_runs)


# COMMAND ----------

# import requests
# from pyspark.sql import SparkSession
# from pyspark.sql.functions import col, from_utc_timestamp, when

# # Initialize Spark session
# spark = SparkSession.builder.appName("DatabricksJobs").getOrCreate()

# # Databricks domain and token
# domain = 'https://adb-4933264770484963.3.azuredatabricks.net'
# token = 'dapi831b55c6d4663aa199d0204ce8636c44-2'

# # Set up the headers for HTTP request
# headers = {
#     'Authorization': f'Bearer {token}',
#     'Content-Type': 'application/json'
# }

# # Function to get the list of job runs
# def get_job_runs():
#     endpoint = f'{domain}/api/2.0/jobs/runs/list'
#     response = requests.get(endpoint, headers=headers)
#     if response.status_code == 200:
#         return response.json()['runs']
#     else:
#         raise Exception(f'Error fetching job runs: {response.content}')

# # Function to insert data into the jobs table
# def insert_data_into_table(job_runs):
#     # Convert job runs data to a DataFrame
#     job_runs_df = spark.createDataFrame(job_runs)
    
#     # Convert Unix timestamp (milliseconds) to TimestampType
#     job_runs_df = job_runs_df.withColumn('start_time', (col('start_time') / 1000).cast('timestamp'))
#     job_runs_df = job_runs_df.withColumn('end_time', (col('end_time') / 1000).cast('timestamp'))
    
#     # Convert to Indian Standard Time (IST)
#     job_runs_df = job_runs_df.withColumn('start_time_ist', from_utc_timestamp(col('start_time'), 'Asia/Kolkata'))
#     job_runs_df = job_runs_df.withColumn('end_time_ist', from_utc_timestamp(col('end_time'), 'Asia/Kolkata'))
    
#     # Map "terminated" status to "success" or "failure"
#     job_runs_df = job_runs_df.withColumn('status', 
#         when(col('state.result_state') == 'SUCCESS', 'success')
#         .when(col('state.result_state') == 'FAILED', 'failure')
#         # .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNull()), 'success')
#         # .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNotNull()), 'failure')
#         .otherwise(col('state.life_cycle_state'))
#     )
    
#     # Select and rename the necessary columns
#     job_runs_df = job_runs_df.selectExpr(
#         "job_id",
#         "run_name as job_name",
#         "run_id",
#         "start_time_ist as start_time",
#         "end_time_ist as end_time",
#         "status"
#     )
    
#     # Insert data into the jobs table
#     job_runs_df.write.mode('append').saveAsTable('jobs')

# # Get the job runs data
# job_runs = get_job_runs()

# # Insert the data into the jobs table
# insert_data_into_table(job_runs)


# COMMAND ----------



# COMMAND ----------

# import requests
# from pyspark.sql import SparkSession
# from pyspark.sql.functions import col, from_utc_timestamp, when

# # Initialize Spark session
# spark = SparkSession.builder.appName("DatabricksJobs").getOrCreate()

# # Databricks domain and token
# domain = 'https://adb-4933264770484963.3.azuredatabricks.net'
# token = 'dapi831b55c6d4663aa199d0204ce8636c44-2'

# # Set up the headers for HTTP request
# headers = {
#     'Authorization': f'Bearer {token}',
#     'Content-Type': 'application/json'
# }

# # Function to get the list of job runs
# def get_job_runs():
#     endpoint = f'{domain}/api/2.0/jobs/runs/list'
#     response = requests.get(endpoint, headers=headers)
#     if response.status_code == 200:
#         return response.json()['runs']
#     else:
#         raise Exception(f'Error fetching job runs: {response.content}')

# # Function to export and retrieve the HTML file path for a job run
# def get_html_file_path(run_id):
#     endpoint = f'{domain}/api/2.1/jobs/runs/export'
#     params = {
#         'run_id': run_id,
#         'views_to_export': 'ALL'  # Options: CODE, DASHBOARDS, ALL
#     }
#     response = requests.get(endpoint, headers=headers, params=params)
#     if response.status_code == 200:
#         # Assuming the HTML content is the first item in the views array
#         html_content = response.json()['views'][0]['content']
#         # Save the HTML content to a file and return the file path
#         html_file_path = f'/dbfs/Path/To/Save/HTML/Run_{run_id}.html'
#         with open(html_file_path, 'w') as file:
#             file.write(html_content)
#         return html_file_path
#     else:
#         raise Exception(f'Error exporting job run {run_id}: {response.content}')

# # Function to insert data into the jobs table
# def insert_data_into_table(job_runs):
#     # Convert job runs data to a DataFrame
#     job_runs_df = spark.createDataFrame(job_runs)
    
#     # Convert Unix timestamp (milliseconds) to TimestampType
#     job_runs_df = job_runs_df.withColumn('start_time', (col('start_time') / 1000).cast('timestamp'))
#     job_runs_df = job_runs_df.withColumn('end_time', (col('end_time') / 1000).cast('timestamp'))
    
#     # Convert to Indian Standard Time (IST)
#     job_runs_df = job_runs_df.withColumn('start_time_ist', from_utc_timestamp(col('start_time'), 'Asia/Kolkata'))
#     job_runs_df = job_runs_df.withColumn('end_time_ist', from_utc_timestamp(col('end_time'), 'Asia/Kolkata'))
    
#     # Map "terminated" status to "success" or "failure"
#     job_runs_df = job_runs_df.withColumn('status', 
#         when(col('state.result_state') == 'SUCCESS', 'success')
#         .when(col('state.result_state') == 'FAILED', 'failure')
#         .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNull()), 'success')
#         .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNotNull()), 'failure')
#         .otherwise(col('state.life_cycle_state'))
#     )
    
#     # Fetch and add the HTML file path for each job run
#     job_runs_df = job_runs_df.withColumn('html_file_path', get_html_file_path(col('run_id')))
    
#     # Select and rename the necessary columns
#     job_runs_df = job_runs_df.selectExpr(
#         "job_id",
#         "run_name as job_name",
#         "run_id",
#         "start_time_ist as start_time",
#         "end_time_ist as end_time",
#         "status",
#         "html_file_path"
#     )
    
#     # Insert data into the jobs table
#     job_runs_df.write.mode('append').saveAsTable('jobs')

# # Get the job runs data
# job_runs = get_job_runs()

# # Insert the data into the jobs table
# insert_data_into_table(job_runs)


# COMMAND ----------

dbutils.fs.ls('dbfs:/cluster-logs/')

# COMMAND ----------

import requests
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_utc_timestamp, when, udf
from pyspark.sql.types import StringType

# Initialize Spark session
spark = SparkSession.builder.appName("DatabricksJobs").getOrCreate()

# Databricks domain and token
domain = 'https://adb-4933264770484963.3.azuredatabricks.net'
token = 'dapi831b55c6d4663aa199d0204ce8636c44-2'

# Set up the headers for HTTP request
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
}

# Function to get the list of job runs
def get_job_runs():
    endpoint = f'{domain}/api/2.0/jobs/runs/list'
    response = requests.get(endpoint, headers=headers)
    if response.status_code == 200:
        return response.json()['runs']
    else:
        raise Exception(f'Error fetching job runs: {response.content}')

# Function to export and retrieve the HTML file path for a job run
def get_html_file_path(run_id):
    endpoint = f'{domain}/api/2.1/jobs/runs/export'
    params = {
        'run_id': run_id,
        'views_to_export': 'ALL'  # Options: CODE, DASHBOARDS, ALL
    }
    response = requests.get(endpoint, headers=headers, params=params)
    if response.status_code == 200:
        # Assuming the HTML content is the first item in the views array
        html_content = response.json()['views'][0]['content']
        # Save the HTML content to a file and return the file path
        html_file_path = f'/dbfs/cluster-logs/{run_id}.html'
        with open(html_file_path, 'w') as file:
            file.write(html_content)
        return html_file_path
    else:
        raise Exception(f'Error exporting job run {run_id}: {response.content}')

# Define the UDF for getting the HTML file path
get_html_file_path_udf = udf(get_html_file_path, StringType())

# Function to insert data into the jobs table
def insert_data_into_table(job_runs):
    # Convert job runs data to a DataFrame
    job_runs_df = spark.createDataFrame(job_runs)
    
    # Convert Unix timestamp (milliseconds) to TimestampType
    job_runs_df = job_runs_df.withColumn('start_time', (col('start_time') / 1000).cast('timestamp'))
    job_runs_df = job_runs_df.withColumn('end_time', (col('end_time') / 1000).cast('timestamp'))
    
    # Convert to Indian Standard Time (IST)
    job_runs_df = job_runs_df.withColumn('start_time_ist', from_utc_timestamp(col('start_time'), 'Asia/Kolkata'))
    job_runs_df = job_runs_df.withColumn('end_time_ist', from_utc_timestamp(col('end_time'), 'Asia/Kolkata'))
    
    # Map "terminated" status to "success" or "failure"
    job_runs_df = job_runs_df.withColumn('status', 
        when(col('state.result_state') == 'SUCCESS', 'success')
        .when(col('state.result_state') == 'FAILED', 'failure')
        .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNull()), 'success')
        .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNotNull()), 'failure')
        .otherwise(col('state.life_cycle_state'))
    )
    
    # Fetch and add the HTML file path for each job run using the UDF
    job_runs_df = job_runs_df.withColumn('html_file_path', get_html_file_path_udf(col('run_id')))
    
    # Select and rename the necessary columns
    job_runs_df = job_runs_df.selectExpr(
        "job_id",
        "run_name as job_name",
        "run_id",
        "start_time_ist as start_time",
        "end_time_ist as end_time",
        "status",
        "html_file_path"
    )
    
    # Insert data into the jobs table
    job_runs_df.write.mode('append').saveAsTable('jobs')

# Get the job runs data
job_runs = get_job_runs()

# Insert the data into the jobs table
insert_data_into_table(job_runs)


# COMMAND ----------

# Import the required libraries
from IPython.core.display import display, HTML

# Define the DBFS path to your HTML file
html_file_path = "/dbfs/cluster-logs/1142000692.html"

# Open the file in read mode and read its content
with open(html_file_path, 'r') as html_file:
    # html_content = html_file.read()
    print(html_file.read())

# Display the HTML content in the notebook
# display(HTML(html_content))


# COMMAND ----------

# Define the DBFS path to your file
file_path = "dbfs:/cluster-logs/1142000692.html"

# Get the file info
file_info = dbutils.fs.ls(file_path)[0]

# Get the file size
file_size = file_info.size

# Print the file size
print(f"The size of the file is {file_size} bytes.")


# COMMAND ----------

# Define the DBFS path to your file
file_path = "dbfs:/cluster-logs/1142000692.html"

# Get the file info
file_info = dbutils.fs.ls(file_path)[0]

# Get the file size in bytes
file_size_bytes = file_info.size

# Convert the file size to MB
file_size_mb = file_size_bytes / 1024 / 1024

# Print the file size
print(f"The size of the file is {file_size_mb} MB.")


# COMMAND ----------

df=spark.sql(f"select * from jobs")
display(df)

# COMMAND ----------

# Load the data from the jobs table
df = spark.sql("SELECT * FROM jobs")

# Create a new DataFrame that contains the latest status of each job
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, desc

window = Window.partitionBy("job_name").orderBy(desc("start_time"))
latest_jobs_df = df.withColumn("rn", row_number().over(window)).where("rn = 1").drop("rn")

# Display the DataFrame as a bar chart
display(latest_jobs_df.select("job_name", "status", "start_time", "end_time"))


# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC *
# MAGIC from
# MAGIC CDL_CONFIG.CDL_STORAGE_ACCOUNTS
# MAGIC

# COMMAND ----------

import requests
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_utc_timestamp, when, udf
from pyspark.sql.types import StringType

# Initialize Spark session
spark = SparkSession.builder.appName("DatabricksJobs").getOrCreate()

# Databricks domain and token
domain = 'https://adb-4933264770484963.3.azuredatabricks.net'
token = 'dapi831b55c6d4663aa199d0204ce8636c44-2'

# Set up the headers for HTTP request
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
}

# Function to get the list of job runs
def get_job_runs():
    endpoint = f'{domain}/api/2.0/jobs/runs/list'
    response = requests.get(endpoint, headers=headers)
    if response.status_code == 200:
        return response.json()['runs']
    else:
        raise Exception(f'Error fetching job runs: {response.content}')

# Function to export and retrieve the HTML file path for a job run
def get_html_file_path(run_id):
    endpoint = f'{domain}/api/2.1/jobs/runs/export'
    params = {
        'run_id': run_id,
        'views_to_export': 'ALL'  # Options: CODE, DASHBOARDS, ALL
    }
    response = requests.get(endpoint, headers=headers, params=params)
    if response.status_code == 200:
        # Assuming the HTML content is the first item in the views array
        html_content = response.json()['views'][0]['content']
        # Save the HTML content to a file and return the file path
        html_file_path = f'/dbfs/cluster-logs/{run_id}.html'
        with open(html_file_path, 'w') as file:
            file.write(html_content)
        return html_file_path
    else:
        raise Exception(f'Error exporting job run {run_id}: {response.content}')

# Define the UDF for getting the HTML file path
get_html_file_path_udf = udf(get_html_file_path, StringType())

# Function to insert data into the jobs table
def insert_data_into_table(job_runs):
    # Convert job runs data to a DataFrame
    job_runs_df = spark.createDataFrame(job_runs)
    
    # Convert Unix timestamp (milliseconds) to TimestampType
    job_runs_df = job_runs_df.withColumn('start_time', (col('start_time') / 1000).cast('timestamp'))
    job_runs_df = job_runs_df.withColumn('end_time', (col('end_time') / 1000).cast('timestamp'))
    
    # Convert to Indian Standard Time (IST)
    job_runs_df = job_runs_df.withColumn('start_time_ist', from_utc_timestamp(col('start_time'), 'Asia/Kolkata'))
    job_runs_df = job_runs_df.withColumn('end_time_ist', from_utc_timestamp(col('end_time'), 'Asia/Kolkata'))
    
    # Map "terminated" status to "success" or "failure" or "terminated"
    job_runs_df = job_runs_df.withColumn('status', 
        when(col('state.result_state') == 'SUCCESS', 'success')
        .when(col('state.result_state') == 'FAILED', 'failure')
        # .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNull()), 'success')
        # .when((col('state.life_cycle_state') == 'TERMINATED') & (col('state.error_message').isNotNull()), 'failure')
        .when(col('state.life_cycle_state') == 'TERMINATED', 'terminated')
        .otherwise(col('state.life_cycle_state'))
    )
    
    # Add a new column for the error message
    job_runs_df = job_runs_df.withColumn('error_message', col('state.error_message'))
    
    # Fetch and add the HTML file path for each job run using the UDF
    job_runs_df = job_runs_df.withColumn('html_file_path', get_html_file_path_udf(col('run_id')))
    
    # Select and rename the necessary columns
    job_runs_df = job_runs_df.selectExpr(
        "job_id",
        "run_name as job_name",
        "run_id",
        "start_time_ist as start_time",
        "end_time_ist as end_time",
        "status",
        "error_message",
        "html_file_path"
    )
    
    # Insert data into the jobs table
    job_runs_df.write.mode('append').saveAsTable('jobs')

# Get the job runs data
job_runs = get_job_runs()

# Insert the data into the jobs table
insert_data_into_table(job_runs)


# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from jobs

# COMMAND ----------

df=spark.sql("select * from jobs")
display(df)

# COMMAND ----------

if __name__=="__main__":
    print("manoj")

# COMMAND ----------

mount_point = dbutils.secrets.get('sqa', 'sqa_mount_point') 
for x in mount_point:
  print(x)

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

# MAGIC %sql
# MAGIC show create table sqa.atlas_batch_genealogy

# COMMAND ----------

# MAGIC %fs
# MAGIC
# MAGIC mounts

# COMMAND ----------

